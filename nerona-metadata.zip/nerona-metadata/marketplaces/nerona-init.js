(function () {
  try {
    globalThis.__NERONA_runSafe__ = function (label, fn) {
      try {
        fn();
      } catch (e) {
        console.warn("[Nerona marketplace] " + label + " gagal:", e);
      }
    };
  } catch (e) {
    console.warn("[Nerona] Inisialisasi runSafe gagal:", e);
    globalThis.__NERONA_runSafe__ = function () {};
  }

  globalThis.__NERONA_runSafe__("nerona-init", function () {
    globalThis.__NERONA_MX_SELECTORS__ = Object.create(null);
  });

  if (!globalThis.__NERONA_MX_SELECTORS__ || typeof globalThis.__NERONA_MX_SELECTORS__ !== "object") {
    globalThis.__NERONA_MX_SELECTORS__ = {};
  }
})();
