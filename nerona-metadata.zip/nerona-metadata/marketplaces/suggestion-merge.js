/**
 * Aturan anggaran keyword: saran marketplace dulu, keyword AI menyusul.
 *
 * MURNI dan tanpa DOM, dan itu bukan kebetulan. content.js adalah satu berkas
 * 377 KB tanpa export yang tidak bisa dimuat `node --test`; aturan anggaran yang
 * tinggal di sana tidak akan pernah punya bukti selain "sepertinya jalan".
 * Ditaruh di sini, ia bisa dibuktikan — lihat scripts/suggestion-merge.test.mjs.
 *
 * Sengaja TIDAK memakai __NERONA_runSafe__ seperti berkas marketplace lain:
 * pembungkus itu dipasang nerona-init.js, dan berkas tesnya memuat berkas ini
 * sendirian. Tanpa dependensi, satu `import` sudah cukup.
 */
(function () {
  /** Bagian plafon yang dijaga untuk keyword AI waktu saran melimpah. */
  const FLOOR_RATIO_DEFAULT = 0.4;

  /** Buang yang bukan teks, yang kosong, dan yang kembar (tanpa peduli huruf besar-kecil). */
  function bersihkan(list) {
    const out = [];
    const seen = new Set();
    for (const raw of Array.isArray(list) ? list : []) {
      if (typeof raw !== "string") continue;
      const s = raw.trim();
      if (!s) continue;
      const key = s.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(s);
    }
    return out;
  }

  /**
   * @param {object} opts
   * @param {string[]} opts.suggested  Saran marketplace, dalam urutan tampil situsnya.
   * @param {string[]} opts.generated  Keyword AI, dalam urutan keluaran AI.
   * @param {number}   opts.cap        Plafon situs — dari getMarketplaceKeywordMax.
   * @param {number}   [opts.floorRatio]
   * @returns {string[]}
   */
  globalThis.__NERONA_mergeSuggestedKeywords__ = function (opts) {
    const o = opts || {};
    const cap = Number.isFinite(o.cap) ? Math.max(0, Math.floor(o.cap)) : 0;
    if (cap <= 0) return [];

    const ratio = Number.isFinite(o.floorRatio) ? o.floorRatio : FLOOR_RATIO_DEFAULT;
    const saran = bersihkan(o.suggested);
    const ai = bersihkan(o.generated);

    // Lantai dijaga sebanyak keyword AI yang BENAR-BENAR ada, bukan sebanyak
    // porsinya. Kalau AI cuma mengembalikan 12 keyword di situs berplafon 50,
    // lantai 20 akan menyisakan 8 slot yang tidak ada isinya — plafon terisi 42
    // dari 50 tanpa satu pun alasan yang terlihat.
    const lantai = Math.min(Math.round(cap * ratio), ai.length);
    const saranMaks = Math.max(0, cap - lantai);

    const out = [];
    const seen = new Set();
    const push = (k) => {
      const key = k.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      out.push(k);
      return true;
    };

    for (const k of saran) {
      if (out.length >= saranMaks) break;
      push(k);
    }
    // Diisi sampai plafon, bukan sampai lantai: saran yang terbuang dedup
    // membebaskan slot, dan slot yang bebas milik keyword AI.
    for (const k of ai) {
      if (out.length >= cap) break;
      push(k);
    }

    return out;
  };
})();
