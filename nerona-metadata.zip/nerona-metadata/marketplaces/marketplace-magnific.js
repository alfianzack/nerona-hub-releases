globalThis.__NERONA_runSafe__("marketplace-magnific", function () {
  const uniq = (arr) =>
    [...new Set((arr || []).filter((s) => typeof s === "string" && s.trim()))];

  globalThis.__NERONA_MX_SELECTORS__.magnific = {
    /** Grid katalog — terpilih = .catalog__item.selected (bukan .error, ada di semua tile). */
    assetGrid: {
      item: '[data-cy="preitem"].catalog__item',
      itemSelected: '[data-cy="preitem"].catalog__item.selected',
      checkbox: 'label.checkbox input[type="checkbox"]',
      checkboxLabel: '[data-cy="preitemCheck"]',
      thumbnail: 'img[data-cy="preitemImg-grid"]'
    },
    title: uniq([
      'input[name*="title"]',
      'input[id*="title"]',
      '[placeholder*="Title" i]',
      '[data-cy*="title" i] input',
      '[data-cy*="title" i] textarea'
    ]),
    description: uniq([
      'textarea[name*="description"]',
      'textarea[id*="description"]',
      '[placeholder*="Description" i]',
      '[data-cy*="description" i] textarea'
    ]),
    keywords: uniq([
      '[data-cy*="tag" i] input',
      '[data-cy*="keyword" i] input',
      '.tags-input input',
      '[class*="tags-input" i] input',
      '[class*="tag-input" i] input',
      'input[name*="tag"]',
      'textarea[name*="keyword"]',
      'input[name*="keyword"]',
      '[placeholder*="Keyword" i]',
      '[placeholder*="Tag" i]',
      '[data-cy*="keyword" i] input',
      '[data-cy*="keyword" i] textarea',
      '[data-cy*="tag" i] input'
    ])
  };
});
