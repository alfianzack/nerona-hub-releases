globalThis.__NERONA_runSafe__("selectors-compile", function () {
  const s = globalThis.__NERONA_MX_SELECTORS__;
  globalThis.marketplaceSelectors =
    s && typeof s === "object" ? s : Object.create(null);
});

if (!globalThis.marketplaceSelectors || typeof globalThis.marketplaceSelectors !== "object") {
  globalThis.marketplaceSelectors = {};
}

var marketplaceSelectors = globalThis.marketplaceSelectors;
