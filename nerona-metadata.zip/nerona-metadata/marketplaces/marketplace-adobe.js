globalThis.__NERONA_runSafe__("marketplace-adobe", function () {
  globalThis.__NERONA_MX_SELECTORS__.adobe = {
    title: [
      '.upload-metadata input[name*="title" i]',
      '.upload-metadata textarea[name*="title" i]',
      '[class*="metadata" i] input[name*="title" i]',
      '[class*="Metadata" i] input[name*="title" i]',
      'input[name*="title"]',
      'input[name*="filename"]',
      'input[id*="title"]',
      'input[id*="filename"]',
      'textarea[name*="title"]',
      '[placeholder*="Title" i]',
      '[placeholder*="judul" i]',
      '[aria-label*="Title" i]:not([type="checkbox"])',
      '[aria-label*="filename" i]',
      '[data-testid*="title"] input:not([type="checkbox"])',
      '[data-testid*="Title"] input:not([type="checkbox"])'
    ],
    description: [
      'textarea[name*="description"]',
      'textarea[id*="description"]',
      '[placeholder*="Description" i]',
      '[aria-label*="Description" i]',
      '[data-testid*="description"] textarea',
      '[data-test-id*="description"] textarea'
    ],
    keywords: [
      '.upload-metadata textarea[placeholder*="Paste Keywords" i]',
      '.upload-metadata textarea[aria-label*="Keywords" i]',
      'textarea[placeholder*="Paste Keywords" i]',
      'textarea[placeholder*="Separate keywords" i]',
      'textarea[aria-label*="Keywords" i]',
      'textarea[name*="keyword"]',
      'textarea[id*="keyword"]',
      'input[name*="keyword"]',
      'input[id*="keyword"]',
      '[placeholder*="Keyword" i]',
      '[placeholder*="comma" i]',
      '[aria-label*="Keyword" i]',
      '[aria-label*="Keywords" i]',
      '[data-testid*="keyword"] textarea',
      '[data-test-id*="keyword"] textarea',
      '[data-testid*="Keywords"] textarea',
      '[data-test-id*="Keywords"] textarea'
    ]
  };
});
