globalThis.__NERONA_runSafe__("marketplace-stock-like", function () {
  globalThis.__NERONA_STOCK_LIKE_SELECTORS__ = {
    title: ['input[name*="title"]', 'input[id*="title"]', '[placeholder*="Title" i]'],
    description: [
      'textarea[name*="description"]',
      'textarea[id*="description"]',
      '[placeholder*="Description" i]'
    ],
    keywords: [
      'textarea[name*="keyword"]',
      'input[name*="keyword"]',
      'input[name*="tag"]',
      '[placeholder*="Keyword" i]',
      '[placeholder*="Tag" i]'
    ]
  };
});

if (!globalThis.__NERONA_STOCK_LIKE_SELECTORS__) {
  globalThis.__NERONA_STOCK_LIKE_SELECTORS__ = {
    title: [],
    description: [],
    keywords: []
  };
}
