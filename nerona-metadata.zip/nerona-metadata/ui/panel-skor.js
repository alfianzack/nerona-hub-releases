/**
 * Panel Skor Gambar (fitur D).
 *
 * Menggantikan dua tombol yang dulu terpisah, AI Scoring Agent dan Commercial
 * Intent Analyzer, dengan satu panggilan: keduanya menilai gambar yang sama dan
 * jawabannya tumpang tindih.
 *
 * Yang membedakan panel ini dari ketiga panel lama: keywordnya bisa diedit, dan
 * skornya bergerak seketika. Tanpa itu, ia cuma jadi panel saran yang keempat,
 * dan panel saran adalah masalah yang membuat fitur ini dipesan.
 *
 * Pembagian kerja yang disengaja, dan ini inti keputusannya:
 * - tiga bagian skor (keunikan, bentuk frasa, kepatuhan) dihitung DI SINI,
 *   lokal, nol poin, seketika;
 * - satu bagian (relevansi terhadap gambar) hanya bisa dijawab model yang
 *   melihat gambarnya.
 *
 * Maka keyword yang baru diketik tidak diberi angka relevansi karangan. Ia
 * ditandai "belum dinilai" dan tidak ikut rata-rata. Mengedit teks keyword juga
 * membuang nilai lamanya, termasuk untuk perbaikan salah ketik: angka itu
 * dinilai untuk kata yang lain.
 */
(function () {
  const ID = "nerona-panel-skor";

  let daftar = [];
  let tujuanKomersial = "";
  let aturan = null;
  let cfg = null;
  let pemicu = null;

  const el = (tag, gaya, teks) => {
    const n = document.createElement(tag);
    if (gaya) n.style.cssText = gaya;
    if (teks !== undefined) n.textContent = teks;
    return n;
  };

  // ---- baca dan tulis form ----

  function selektor() {
    return globalThis.marketplaceSelectors?.[cfg?.marketplaceKey] || null;
  }

  function bacaKeywordDariForm() {
    const kunci = cfg?.marketplaceKey || "";
    try {
      const tag = globalThis.getExistingTagsForMarketplace?.(kunci);
      if (tag && tag.size) return [...tag].map((x) => String(x).trim()).filter(Boolean);
    } catch (_e) {
      /* lanjut ke pembacaan field */
    }
    const sel = selektor();
    const medan = sel?.keywords ? globalThis.firstMatch?.(sel.keywords) : null;
    const teks = globalThis.readFormFieldKeywords?.(medan) || "";
    return teks
      .split(",")
      .map((x) => x.trim())
      .filter(Boolean);
  }

  function tulisKeywordKeForm() {
    const sel = selektor();
    if (!sel?.keywords) return false;
    const teks = daftar.map((x) => x.k).join(", ");
    return Boolean(globalThis.fillKeywordsField?.(teks, sel.keywords, cfg?.marketplaceKey));
  }

  // ---- gambar ----

  function skorSekarang() {
    return globalThis.__NERONA_guardSkor__({ keywords: daftar, aturan });
  }

  function label(n) {
    return n >= 70 ? "kuat" : n >= 45 ? "cukup" : "lemah";
  }

  function gambarPanel() {
    document.getElementById(ID)?.remove();

    const tirai = el(
      "div",
      "position:fixed;inset:0;z-index:2147483600;background:rgba(10,16,28,.55);display:flex;align-items:center;justify-content:center;padding:16px"
    );
    tirai.id = ID;
    tirai.setAttribute("data-nerona-overlay", "1");

    const kotak = el(
      "div",
      "background:#fff;color:#0F1724;border-radius:12px;width:100%;max-width:640px;max-height:86vh;display:flex;flex-direction:column;font:14px/1.5 Inter,system-ui,sans-serif"
    );

    // kepala
    const kepala = el(
      "div",
      "background:#16233D;color:#fff;padding:12px 16px;border-radius:12px 12px 0 0;display:flex;justify-content:space-between;align-items:center;gap:12px"
    );
    kepala.appendChild(el("strong", "font-size:15px", "Skor Gambar"));
    const tutup = el(
      "button",
      "background:transparent;color:#fff;border:1px solid rgba(255,255,255,.45);border-radius:8px;padding:5px 10px;font:inherit;font-size:13px;cursor:pointer",
      "Tutup"
    );
    tutup.type = "button";
    tutup.addEventListener("click", tutupPanel);
    kepala.appendChild(tutup);

    // badan
    const badan = el("div", "padding:16px;overflow:auto;display:flex;flex-direction:column;gap:14px");
    const s = skorSekarang();

    const atas = el("div", "display:flex;gap:18px;flex-wrap:wrap;align-items:flex-start");
    const angka = el("div", "min-width:120px");
    angka.appendChild(el("div", "font:11px/1 'IBM Plex Mono',monospace;letter-spacing:.085em;text-transform:uppercase;color:#5A6473", "Skor total"));
    const barisAngka = el("div", "display:flex;align-items:baseline;gap:8px;margin-top:6px");
    const nilaiEl = el("span", "font:600 40px/1 'IBM Plex Mono',monospace;font-variant-numeric:tabular-nums", String(s.total));
    nilaiEl.id = "nerona-skor-nilai";
    const labelEl = el("span", "color:#5A6473", label(s.total));
    labelEl.id = "nerona-skor-label";
    barisAngka.appendChild(nilaiEl);
    barisAngka.appendChild(labelEl);
    angka.appendChild(barisAngka);
    atas.appendChild(angka);

    const bagian = el("div", "flex:1;min-width:220px;display:flex;flex-direction:column;gap:7px");
    bagian.id = "nerona-skor-bagian";
    atas.appendChild(bagian);
    badan.appendChild(atas);

    const catatan = el("div", "");
    catatan.id = "nerona-skor-catatan";
    badan.appendChild(catatan);

    if (tujuanKomersial) {
      const blok = el("div", "");
      blok.appendChild(el("div", "font:11px/1 'IBM Plex Mono',monospace;letter-spacing:.085em;text-transform:uppercase;color:#5A6473", "Tujuan komersial"));
      blok.appendChild(el("p", "margin:6px 0 0", tujuanKomersial));
      badan.appendChild(blok);
    }

    badan.appendChild(el("div", "height:1px;background:#E2E7EE"));

    const kepalaKw = el("div", "display:flex;justify-content:space-between;align-items:baseline;gap:10px");
    kepalaKw.appendChild(el("div", "font:11px/1 'IBM Plex Mono',monospace;letter-spacing:.085em;text-transform:uppercase;color:#5A6473", "Keyword"));
    const hitung = el("div", "font:11px/1 'IBM Plex Mono',monospace;color:#5A6473", daftar.length + " keyword");
    hitung.id = "nerona-skor-hitung";
    kepalaKw.appendChild(hitung);
    badan.appendChild(kepalaKw);

    const daftarEl = el("div", "display:flex;flex-direction:column;gap:6px");
    daftarEl.id = "nerona-skor-daftar";
    badan.appendChild(daftarEl);

    const tambah = el("div", "display:flex;gap:8px");
    const kotakBaru = el(
      "input",
      "flex:1;min-width:0;font:inherit;font-size:13px;background:#F5F7FA;color:#0F1724;border:1px solid #C9D2DF;border-radius:8px;padding:7px 9px"
    );
    kotakBaru.type = "text";
    kotakBaru.placeholder = "tulis keyword baru, lalu Enter";
    kotakBaru.setAttribute("aria-label", "Keyword baru");
    const tombolTambah = el(
      "button",
      "font:inherit;font-size:13px;border:1px solid #C9D2DF;border-radius:8px;background:#fff;padding:7px 12px;cursor:pointer",
      "Tambah"
    );
    tombolTambah.type = "button";
    const tambahkan = () => {
      const teks = kotakBaru.value.trim();
      if (!teks) return;
      daftar.push({ k: teks, rel: null });
      kotakBaru.value = "";
      gambarDaftar();
      gambarRingkas();
      kotakBaru.focus();
    };
    tombolTambah.addEventListener("click", tambahkan);
    kotakBaru.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") {
        ev.preventDefault();
        tambahkan();
      }
    });
    tambah.appendChild(kotakBaru);
    tambah.appendChild(tombolTambah);
    badan.appendChild(tambah);

    // kaki
    const kaki = el(
      "div",
      "padding:12px 16px;border-top:1px solid #E2E7EE;background:#F5F7FA;border-radius:0 0 12px 12px;display:flex;flex-wrap:wrap;gap:8px;justify-content:space-between;align-items:center"
    );
    const tombolAi = el(
      "button",
      "font:inherit;font-size:13px;border:1px solid #C9D2DF;border-radius:8px;background:#fff;padding:7px 12px;cursor:pointer",
      "Hitung ulang dengan AI"
    );
    tombolAi.type = "button";
    tombolAi.id = "nerona-skor-ai";
    tombolAi.addEventListener("click", () => void hitungUlangAi(tombolAi));
    const tombolTulis = el(
      "button",
      "font:inherit;font-size:13px;font-weight:600;border:1px solid #16233D;border-radius:8px;background:#16233D;color:#fff;padding:7px 12px;cursor:pointer",
      "Tulis ke form"
    );
    tombolTulis.type = "button";
    tombolTulis.addEventListener("click", () => {
      const ok = tulisKeywordKeForm();
      globalThis.showNeronaToast?.(
        ok ? daftar.length + " keyword ditulis ke form." : "Gagal menulis ke form, kolom keyword tidak ditemukan."
      );
      if (ok) tutupPanel();
    });
    kaki.appendChild(tombolAi);
    kaki.appendChild(tombolTulis);

    kotak.appendChild(kepala);
    kotak.appendChild(badan);
    kotak.appendChild(kaki);
    tirai.appendChild(kotak);
    tirai.addEventListener("click", (ev) => {
      if (ev.target === tirai) tutupPanel();
    });
    document.body.appendChild(tirai);

    gambarDaftar();
    gambarRingkas();
    tutup.focus();
    document.addEventListener("keydown", tutupDenganEsc);
  }

  function tutupDenganEsc(ev) {
    if (ev.key !== "Escape") return;
    tutupPanel();
  }

  function tutupPanel() {
    document.getElementById(ID)?.remove();
    document.removeEventListener("keydown", tutupDenganEsc);
    pemicu?.focus();
  }

  /**
   * Satu tempat yang memutuskan bagaimana nilai per keyword terlihat, dipakai
   * baik waktu daftar dibangun maupun waktu angkanya disegarkan tiap ketikan.
   * Dua salinan aturan tampilan yang sama adalah cara paling mudah membuat
   * baris dan totalnya menceritakan hal yang berbeda.
   */
  function lukisNilaiKeyword(span, rel) {
    if (rel === null || rel === undefined) {
      span.textContent = "belum";
      span.style.color = "#5A6473";
      span.style.fontSize = "10px";
      span.style.borderColor = "#E2E7EE";
      return;
    }
    span.textContent = String(rel);
    span.style.fontSize = "12px";
    span.style.color = rel < 50 ? "#B45309" : "#047857";
    span.style.borderColor = rel < 50 ? "#B45309" : "#047857";
  }

  /**
   * Daftar keyword dibangun ulang HANYA di sini, bukan tiap ketikan. Membangun
   * ulang tiap ketikan akan melempar kursor keluar dari kotak yang sedang
   * diketik, dan mengetik jadi mustahil.
   */
  function gambarDaftar() {
    const wadah = document.getElementById("nerona-skor-daftar");
    if (!wadah) return;
    const s = skorSekarang();
    wadah.textContent = "";

    daftar.forEach((item, i) => {
      const baris = el("div", "display:grid;grid-template-columns:minmax(0,1fr) 64px 32px;gap:8px;align-items:center");

      const input = el(
        "input",
        "font:inherit;font-size:13px;background:#F5F7FA;color:#0F1724;border:1px solid #C9D2DF;border-radius:8px;padding:6px 9px;width:100%"
      );
      input.type = "text";
      input.value = item.k;
      input.setAttribute("aria-label", "Keyword " + (i + 1));
      input.addEventListener("input", function () {
        // Teks berubah berarti nilai AI lama sudah tidak berlaku: ia dinilai
        // untuk kata yang lain.
        if (item.k.trim() !== this.value.trim()) item.rel = null;
        item.k = this.value;
        gambarRingkas();
      });
      input.addEventListener("blur", () => {
        gambarDaftar();
        gambarRingkas();
      });

      const nilai = el(
        "span",
        "font:12px/1 'IBM Plex Mono',monospace;text-align:center;border:1px solid #E2E7EE;border-radius:6px;padding:5px 0;font-variant-numeric:tabular-nums"
      );
      nilai.setAttribute("data-nerona-kwnilai", String(i));
      lukisNilaiKeyword(nilai, item.rel);

      const buang = el(
        "button",
        "font:inherit;font-size:13px;border:1px solid #C9D2DF;border-radius:8px;background:#fff;padding:6px 0;cursor:pointer",
        "x"
      );
      buang.type = "button";
      buang.setAttribute("aria-label", "Buang keyword " + item.k);
      buang.addEventListener("click", () => {
        daftar.splice(i, 1);
        gambarDaftar();
        gambarRingkas();
      });

      baris.appendChild(input);
      baris.appendChild(nilai);
      baris.appendChild(buang);

      const sebab = s.perKeyword[i]?.sebab || [];
      if (sebab.length) {
        const ket = el("div", "grid-column:1/-1;font-size:11.5px;color:#5A6473;margin-top:-2px", sebab.join(" · "));
        baris.appendChild(ket);
      }
      wadah.appendChild(baris);
    });
  }

  /** Dipanggil tiap ketikan: hanya angka dan catatan yang bergerak. */
  function gambarRingkas() {
    const s = skorSekarang();
    const nilai = document.getElementById("nerona-skor-nilai");
    const labelEl = document.getElementById("nerona-skor-label");
    if (nilai) nilai.textContent = String(s.total);
    if (labelEl) labelEl.textContent = label(s.total);

    const hitung = document.getElementById("nerona-skor-hitung");
    if (hitung) hitung.textContent = daftar.length + " keyword";

    const bagian = document.getElementById("nerona-skor-bagian");
    if (bagian) {
      bagian.textContent = "";
      const rows = [
        ["Relevansi", s.relevansi, "AI"],
        ["Keunikan", s.keunikan, "lokal"],
        ["Bentuk frasa", s.bentuk, "lokal"],
        ["Kepatuhan", s.kepatuhan, "lokal"]
      ];
      for (const [nama, n] of rows) {
        const baris = el("div", "display:grid;grid-template-columns:96px 1fr 38px;gap:8px;align-items:center;font-size:12px");
        baris.appendChild(el("span", "", nama));
        const meter = el("span", "height:6px;background:#F5F7FA;border:1px solid #E2E7EE;border-radius:999px;overflow:hidden");
        const isi = el("i", "display:block;height:100%;background:#3B65C4;width:" + (n === null ? 0 : n) + "%");
        meter.appendChild(isi);
        baris.appendChild(meter);
        baris.appendChild(
          el("span", "font:12px/1 'IBM Plex Mono',monospace;text-align:right;font-variant-numeric:tabular-nums", n === null ? "n/a" : String(n))
        );
        bagian.appendChild(baris);
      }
    }

    const catatan = document.getElementById("nerona-skor-catatan");
    if (catatan) {
      catatan.textContent = "";
      if (s.belum > 0) {
        const kotak = el(
          "div",
          "background:#F5F7FA;border:1px solid #E2E7EE;border-radius:8px;padding:9px 10px;font-size:12.5px"
        );
        kotak.textContent =
          s.belum +
          " keyword belum dinilai. Rumus lokal tidak melihat gambar, jadi ia tidak bisa tahu keyword baru itu benar benar ada di sana. Angkanya dikosongkan, bukan ditebak.";
        catatan.appendChild(kotak);
      }
    }

    // Angka per baris ikut disegarkan, tanpa membangun ulang daftarnya. Tanpa
    // ini, baris yang baru diedit tetap memamerkan nilai AI lamanya sampai
    // kursor pindah, sementara total skor sudah bergerak: dua angka di satu
    // layar yang menceritakan hal berbeda.
    const wadah = document.getElementById("nerona-skor-daftar");
    if (wadah) {
      for (const span of wadah.querySelectorAll("[data-nerona-kwnilai]")) {
        const i = Number(span.getAttribute("data-nerona-kwnilai"));
        if (daftar[i]) lukisNilaiKeyword(span, daftar[i].rel);
      }
    }

    const tombolAi = document.getElementById("nerona-skor-ai");
    if (tombolAi && !tombolAi.disabled) {
      tombolAi.textContent = s.belum
        ? "Hitung ulang dengan AI (" + s.belum + " menunggu)"
        : "Hitung ulang dengan AI";
    }
  }

  // ---- AI ----

  async function panggilAi() {
    const gambar = globalThis.getContributorSelectionImagesOrFallback?.() || [];
    if (!gambar.length) throw new Error("Pilih atau centang gambar dulu untuk Skor Gambar.");
    const inline = await globalThis.imageElementToInlineData(gambar[0]);
    const balasan = await globalThis.callGenerate({
      feature: "skor",
      marketplace: cfg?.aiLabel || cfg?.marketplaceKey || "stock",
      keywords: daftar.map((x) => x.k),
      image: { mime: inline.mimeType, dataBase64: inline.data }
    });
    return globalThis.__NERONA_guardSkorBaca__(balasan.text || "", daftar.map((x) => x.k));
  }

  async function hitungUlangAi(tombol) {
    tombol.disabled = true;
    tombol.textContent = "Memanggil AI...";
    try {
      const hasil = await panggilAi();
      if (hasil.galat) {
        globalThis.showNeronaToast?.("Skor Gambar: " + hasil.galat);
      } else {
        tujuanKomersial = hasil.tujuanKomersial || tujuanKomersial;
        for (const item of daftar) {
          if (Object.prototype.hasOwnProperty.call(hasil.rel, item.k)) item.rel = hasil.rel[item.k];
        }
      }
    } catch (error) {
      globalThis.showNeronaToast?.(String(error?.message || "Gagal memanggil AI."));
    }
    tombol.disabled = false;
    // Digambar ulang seluruhnya: tujuan komersial baru ikut muncul.
    gambarPanel();
  }

  async function buka(konfigurasi, tombolPemicu) {
    cfg = konfigurasi;
    pemicu = tombolPemicu || null;
    aturan = await globalThis.__NERONA_guardJembatan__.aturanUntuk(cfg?.marketplaceKey || "");
    daftar = bacaKeywordDariForm().map((k) => ({ k, rel: null }));
    tujuanKomersial = "";
    gambarPanel();

    // Panggilan AI langsung jalan begitu panel terbuka: tanpa relevansi, tiga
    // dari empat bagian skor memang bisa dihitung, tapi yang paling dicari
    // kontributor justru yang keempat.
    const tombolAi = document.getElementById("nerona-skor-ai");
    if (tombolAi && daftar.length) await hitungUlangAi(tombolAi);
  }

  globalThis.__NERONA_panelSkor__ = { buka };
})();
