/**
 * Badge risiko pra-kirim (fitur C).
 *
 * Menempel di kanan bawah tiap gambar di halaman kontributor, dan berjalan
 * OTOMATIS begitu gambarnya masuk layar. Itu keputusan owner yang diambil
 * setelah ongkosnya disebutkan, jadi yang jadi tugas berkas ini bukan menawar
 * ulang keputusan itu, melainkan memasang remnya:
 *
 * 1. Pemicunya IntersectionObserver, bukan sapuan halaman. Gambar yang tidak
 *    pernah digulir tidak pernah dibayar.
 * 2. Hasilnya disimpan per SIDIK gambar, bukan per elemen. Buka ulang halaman
 *    besok tidak membayar lagi, dan gambar yang sama di dua tempat cuma sekali.
 * 3. Antreannya satu per satu (guard/antrean.js). Lima puluh gambar terlihat
 *    sekaligus tidak jadi lima puluh panggilan serentak.
 * 4. Berhenti sendiri waktu poin menipis, supaya saldo yang tersisa tetap cukup
 *    untuk Generate Metadata, yang memang pekerjaan utamanya.
 * 5. Bisa dimatikan dari popup. Fitur yang membelanjakan uang orang secara
 *    otomatis harus punya saklar yang tidak menuntut mencopot ekstensi.
 *
 * Keputusan tampilan yang disengaja: enam keadaan badge dibedakan IKON DAN KATA,
 * bukan warna saja. Membedakan hijau dari merah bukan kemampuan semua orang,
 * jadi warna cuma lapisan kedua.
 */
(function () {
  const KUNCI_SAKLAR = "neronaRisikoOtomatis";
  const KUNCI_CACHE = "neronaRisikoCache";

  /** Ukuran cache. Melewati ini, yang tertua dibuang; riwayat lama tidak sepadan dengan kuota storage. */
  const CACHE_MAKS = 500;

  const TAMPILAN = {
    menunggu: { tanda: "..", teks: "menunggu", warna: "#4B5563" },
    jalan: { tanda: "..", teks: "memeriksa", warna: "#4B5563" },
    jeda: { tanda: "!!", teks: "dijeda, poin menipis", warna: "#4B5563" },
    galat: { tanda: "!", teks: "gagal, klik untuk ulang", warna: "#7C2D12" },
    aman: { tanda: "OK", teks: "aman", warna: "#047857" },
    lihat: { tanda: "!", teks: "perlu dilihat", warna: "#B45309" },
    risiko: { tanda: "X", teks: "berisiko", warna: "#BE123C" }
  };

  let observer = null;
  let antre = null;
  let aturan = null;
  let nyala = true;
  /** Benar selama batch generate berjalan. Lihat jedaUntukBatch. */
  let dijedaBatch = false;
  const keadaan = new Map();

  function storage() {
    try {
      if (typeof chrome !== "undefined" && chrome.storage?.local) return chrome.storage.local;
    } catch (_e) {
      /* ignore */
    }
    return null;
  }

  async function bacaCache() {
    try {
      const s = storage();
      if (!s) return {};
      const data = await s.get([KUNCI_CACHE]);
      const isi = data[KUNCI_CACHE];
      return isi && typeof isi === "object" ? isi : {};
    } catch (_e) {
      return {};
    }
  }

  async function simpanCache(sidik, hasil) {
    try {
      const s = storage();
      if (!s || !sidik) return;
      const isi = await bacaCache();
      isi[sidik] = { hasil, versiAturan: aturan?.versi || "", pada: Date.now() };

      const kunci = Object.keys(isi);
      if (kunci.length > CACHE_MAKS) {
        kunci
          .sort((a, b) => (isi[a].pada || 0) - (isi[b].pada || 0))
          .slice(0, kunci.length - CACHE_MAKS)
          .forEach((k) => delete isi[k]);
      }
      await s.set({ [KUNCI_CACHE]: isi });
    } catch (_e) {
      /* cache yang gagal cuma berarti bayar lagi nanti, bukan fitur mati */
    }
  }

  async function saklarNyala() {
    try {
      const s = storage();
      if (!s) return true;
      const data = await s.get([KUNCI_SAKLAR]);
      // Belum pernah disetel berarti nyala: fitur ini memang dipesan otomatis.
      return data[KUNCI_SAKLAR] !== false;
    } catch (_e) {
      return true;
    }
  }

  function poinMenipis() {
    const sisa = globalThis.neronaLastKnownPoints;
    const ambang = aturan?.ambangPoinJeda;
    if (!Number.isFinite(sisa) || !Number.isFinite(ambang)) return false;
    return sisa <= ambang;
  }

  // ---- badge ----

  function badgeUntuk(img) {
    const induk = img.parentElement;
    if (!induk) return null;
    let badge = induk.querySelector('[data-nerona-risiko="1"]');
    if (badge) return badge;

    if (window.getComputedStyle(induk).position === "static") {
      induk.style.position = "relative";
    }

    badge = document.createElement("button");
    badge.type = "button";
    badge.setAttribute("data-nerona-risiko", "1");
    badge.setAttribute("data-nerona-overlay", "1");
    badge.style.position = "absolute";
    badge.style.right = "6px";
    badge.style.bottom = "6px";
    badge.style.zIndex = "80";
    badge.style.display = "inline-flex";
    badge.style.alignItems = "center";
    badge.style.gap = "5px";
    badge.style.maxWidth = "calc(100% - 12px)";
    badge.style.padding = "5px 8px";
    badge.style.borderRadius = "6px";
    badge.style.border = "1px solid rgba(255,255,255,0.35)";
    badge.style.color = "#fff";
    badge.style.font = "600 11px/1.2 Inter, system-ui, sans-serif";
    badge.style.cursor = "pointer";
    badge.style.textAlign = "left";

    badge.addEventListener("click", (ev) => {
      // Badge menumpang di area klik milik marketplace. Kliknya berhenti di
      // sini, tidak diteruskan ke gambar di bawahnya.
      ev.preventDefault();
      ev.stopPropagation();
      const k = keadaan.get(badge);
      if (k?.tingkat === "galat") {
        antre?.tambah(img);
        return;
      }
      if (k?.hasil) bukaRincian(k.hasil, k.sidik);
    });

    induk.appendChild(badge);
    return badge;
  }

  function lukis(img, tingkat, hasil, sidik) {
    const badge = badgeUntuk(img);
    if (!badge) return;
    const t = TAMPILAN[tingkat] || TAMPILAN.menunggu;

    let teks = t.teks;
    if (tingkat === "lihat" || tingkat === "risiko") {
      const n = hasil?.alasan?.length || 0;
      teks = n + " " + (tingkat === "risiko" ? "risiko" : "perlu dilihat");
    }

    badge.style.background = t.warna;
    badge.textContent = "";
    const tanda = document.createElement("span");
    tanda.textContent = t.tanda;
    tanda.setAttribute("aria-hidden", "true");
    tanda.style.fontFamily = '"IBM Plex Mono", ui-monospace, monospace';
    const label = document.createElement("span");
    label.textContent = teks;
    badge.appendChild(tanda);
    badge.appendChild(label);
    badge.setAttribute("aria-label", "Pemeriksaan risiko: " + teks);
    badge.title = teks;

    keadaan.set(badge, { tingkat, hasil, sidik });
  }

  function bukaRincian(hasil, sidik) {
    document.getElementById("nerona-risiko-rincian")?.remove();

    const tirai = document.createElement("div");
    tirai.id = "nerona-risiko-rincian";
    tirai.setAttribute("data-nerona-overlay", "1");
    tirai.style.cssText =
      "position:fixed;inset:0;z-index:2147483600;background:rgba(10,16,28,.55);display:flex;align-items:center;justify-content:center;padding:16px";

    const kotak = document.createElement("div");
    kotak.style.cssText =
      "background:#fff;color:#0F1724;border-radius:12px;max-width:520px;width:100%;max-height:80vh;overflow:auto;font:14px/1.5 Inter,system-ui,sans-serif";

    const kepala = document.createElement("div");
    kepala.style.cssText =
      "background:#16233D;color:#fff;padding:12px 16px;border-radius:12px 12px 0 0;display:flex;justify-content:space-between;align-items:center;gap:12px";
    const judul = document.createElement("strong");
    judul.textContent = "Pemeriksaan risiko";
    const tutup = document.createElement("button");
    tutup.type = "button";
    tutup.textContent = "Tutup";
    tutup.style.cssText =
      "background:transparent;color:#fff;border:1px solid rgba(255,255,255,.45);border-radius:8px;padding:5px 10px;font:inherit;font-size:13px;cursor:pointer";
    tutup.addEventListener("click", () => tirai.remove());
    kepala.appendChild(judul);
    kepala.appendChild(tutup);

    const badan = document.createElement("div");
    badan.style.cssText = "padding:16px;display:flex;flex-direction:column;gap:12px";

    if (hasil.butuhRelease) {
      const rilis = document.createElement("p");
      rilis.style.margin = "0";
      rilis.innerHTML = "<strong>Butuh release.</strong> Ada orang atau properti yang bisa dikenali.";
      badan.appendChild(rilis);
    }

    if (!hasil.alasan.length) {
      const kosong = document.createElement("p");
      kosong.style.margin = "0";
      kosong.textContent =
        "Tidak ditemukan alasan penolakan yang menonjol. Ini perkiraan, bukan keputusan marketplace.";
      badan.appendChild(kosong);
    } else {
      for (const a of hasil.alasan) {
        const baris = document.createElement("div");
        baris.style.cssText = "border-left:3px solid #B45309;padding-left:10px";
        const sebab = document.createElement("p");
        sebab.style.margin = "0 0 4px";
        sebab.textContent = a.sebab;
        const meta = document.createElement("p");
        meta.style.cssText = "margin:0;font-size:12.5px;color:#5A6473";
        meta.textContent = "Yakin " + a.yakin + (a.tindakan ? ". Tindakan: " + a.tindakan : "");
        baris.appendChild(sebab);
        baris.appendChild(meta);
        badan.appendChild(baris);
      }
    }

    const kaki = document.createElement("p");
    kaki.style.cssText = "margin:0;font-size:12px;color:#5A6473";
    kaki.textContent = "Sidik gambar: " + (sidik || "tidak terhitung") + ". Aturan: " + (aturan?.versi || "bawaan") + ".";
    badan.appendChild(kaki);

    kotak.appendChild(kepala);
    kotak.appendChild(badan);
    tirai.appendChild(kotak);
    tirai.addEventListener("click", (ev) => {
      if (ev.target === tirai) tirai.remove();
    });
    document.addEventListener(
      "keydown",
      function tutupDenganEsc(ev) {
        if (ev.key !== "Escape") return;
        tirai.remove();
        document.removeEventListener("keydown", tutupDenganEsc);
      },
      { once: false }
    );
    document.body.appendChild(tirai);
    tutup.focus();
  }

  // ---- pemeriksaan ----

  async function periksa(img) {
    if (!nyala) return;
    // Penjaganya ada DI SINI, bukan cuma di antrean. Antrean menahan yang masuk
    // lewat observer, tapi `periksa` juga dipanggil langsung oleh jalur
    // ulang-coba, dan jalur itu membelanjakan poin yang sama.
    if (dijedaBatch) return;
    if (poinMenipis()) {
      lukis(img, "jeda", null, null);
      antre?.jeda();
      return;
    }

    lukis(img, "jalan", null, null);

    const jembatan = globalThis.__NERONA_guardJembatan__;
    const bacaRisiko = globalThis.__NERONA_guardRisiko__;
    const panggil = globalThis.callGenerate;
    const ambilGambar = globalThis.imageElementToInlineData;
    if (!jembatan || !bacaRisiko || !panggil || !ambilGambar) return;

    let inline = null;
    try {
      inline = await ambilGambar(img);
    } catch (_e) {
      lukis(img, "galat", { alasan: [], butuhRelease: false }, null);
      return;
    }

    const sidik = await jembatan.sidikDariInlineData(inline);

    // Cache dibaca SESUDAH gambar diambil, karena sidiknya baru ada di situ.
    // Yang dihemat tetap bagian yang mahal: panggilan AI-nya.
    if (sidik) {
      const cache = await bacaCache();
      const simpanan = cache[sidik];
      if (simpanan && simpanan.versiAturan === (aturan?.versi || "")) {
        lukis(img, simpanan.hasil.tingkat, simpanan.hasil, sidik);
        return;
      }
    }

    let hasil;
    try {
      const balasan = await panggil({
        feature: "risiko",
        marketplace: aturan?.marketplaceKey || "",
        image: { mime: inline.mimeType, dataBase64: inline.data }
      });
      hasil = bacaRisiko(balasan.text || "");
    } catch (error) {
      // Poin habis di tengah: hentikan sisanya, jangan habiskan saldo pada
      // pemeriksaan yang tidak diminta siapa pun.
      if (String(error?.neronaCode || "") === "no_points") {
        antre?.jeda();
        lukis(img, "jeda", null, sidik);
        return;
      }
      lukis(img, "galat", { alasan: [], butuhRelease: false }, sidik);
      return;
    }

    if (hasil.galat) {
      lukis(img, "galat", hasil, sidik);
      return;
    }

    lukis(img, hasil.tingkat, hasil, sidik);
    await simpanCache(sidik, hasil);
  }

  // ---- sapuan halaman ----

  function kandidat() {
    const keluar = [];
    const terlihat = new Set();
    for (const img of document.querySelectorAll("img[src]")) {
      if (globalThis.isInsideNeronaOverlay?.(img)) continue;
      if (!globalThis.isElementVisible?.(img)) continue;
      const src = String(img.currentSrc || img.src || "").trim();
      if (!src || src.startsWith("data:")) continue;
      const r = img.getBoundingClientRect();
      if (r.width < 40 || r.height < 40) continue;
      if (r.width > 920 || r.height > 920) continue;

      const scope = globalThis.findContributorAssetScopeForImage?.(img);
      if (!scope || !scope.contains(img)) continue;
      // Aset yang memang SUDAH ditolak bukan urusan badge ini: di sana Reject
      // Analyzer yang menjawab, dan menumpuk dua tombol cuma membingungkan.
      if (globalThis.scopeEligibleForRejectAnalyzer?.(scope)) continue;

      const k = globalThis.imgDomDedupeKey?.(img);
      if (!k || terlihat.has(k)) continue;
      terlihat.add(k);
      keluar.push(img);
    }
    return keluar;
  }

  function amati() {
    if (!observer) {
      observer = new IntersectionObserver(
        (entri) => {
          for (const e of entri) {
            if (e.isIntersecting) antre?.tambah(e.target);
          }
        },
        { rootMargin: "100px" }
      );
    }
    for (const img of kandidat()) {
      lukis(img, "menunggu", null, null);
      observer.observe(img);
    }
  }

  async function mulai(cfg) {
    nyala = await saklarNyala();
    if (!nyala) return;

    const jembatan = globalThis.__NERONA_guardJembatan__;
    aturan = await jembatan.aturanUntuk(cfg?.marketplaceKey || "");
    if (!antre) antre = globalThis.__NERONA_guardAntrean__(periksa);
    amati();
  }

  function hentikan() {
    observer?.disconnect();
    observer = null;
    antre?.kosongkan();
    for (const badge of document.querySelectorAll('[data-nerona-risiko="1"]')) badge.remove();
    keadaan.clear();
  }

  // `periksa` ikut diekspor bukan untuk harness: itu operasi "periksa ulang
  // gambar ini", yang dipakai badge galat waktu diklik dan akan dipakai tombol
  // periksa-ulang kalau nanti ada.
  /**
   * Dijeda selama batch generate berjalan, lalu dilanjutkan.
   *
   * Tanpa ini, gambar yang digulir kontributor sambil menunggu batch ikut
   * mengantre panggilan AI di jalur yang sama, dan batch yang memang diminta
   * jadi menunggu pekerjaan latar yang tidak diminta siapa pun.
   *
   * Yang sudah terlanjur berjalan dibiarkan selesai; yang belum tidak dimulai.
   */
  function jedaUntukBatch() {
    dijedaBatch = true;
    if (!antre) return;
    antre.jeda();
    for (const badge of document.querySelectorAll('[data-nerona-risiko="1"]')) {
      const k = keadaan.get(badge);
      if (!k || (k.tingkat !== "menunggu" && k.tingkat !== "jeda")) continue;
      badge.textContent = "";
      badge.style.background = TAMPILAN.jeda.warna;
      const tanda = document.createElement("span");
      tanda.textContent = "..";
      tanda.setAttribute("aria-hidden", "true");
      const label = document.createElement("span");
      label.textContent = "menunggu batch selesai";
      badge.appendChild(tanda);
      badge.appendChild(label);
      badge.setAttribute("aria-label", "Pemeriksaan risiko: menunggu batch selesai");
      keadaan.set(badge, { tingkat: "jeda", hasil: null, sidik: k.sidik });
    }
  }

  function lanjutSesudahBatch() {
    dijedaBatch = false;
    antre?.lanjut();
  }

  globalThis.__NERONA_badgeRisiko__ = {
    mulai,
    hentikan,
    amati,
    periksa,
    jedaUntukBatch,
    lanjutSesudahBatch
  };
})();
