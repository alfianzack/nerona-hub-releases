function setNativeValue(element, value) {
  if (!element) return false;

  const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype,
    "value"
  )?.set;
  const nativeTextAreaValueSetter = Object.getOwnPropertyDescriptor(
    window.HTMLTextAreaElement.prototype,
    "value"
  )?.set;

  if (element.tagName === "TEXTAREA" && nativeTextAreaValueSetter) {
    nativeTextAreaValueSetter.call(element, value);
  } else if (nativeInputValueSetter) {
    nativeInputValueSetter.call(element, value);
  } else {
    element.value = value;
  }

  element.dispatchEvent(new Event("input", { bubbles: true }));
  element.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function normalizeKeywordArray(value, max = 50, marketplace = "") {
  return sanitizeKeywordListForMarketplace(value, marketplace, { max });
}

function normalizeKeywordsCommaList(value, max = 50, marketplace = "") {
  return normalizeKeywordArray(value, max, marketplace).join(", ");
}

function formatKeywordsForStockInput(value, marketplace) {
  const list = normalizeKeywordArray(value, getMarketplaceKeywordMax(marketplace), marketplace);
  if (!list.length) return "";
  return list.join(", ");
}

function formatKeywordsProgressSnippet(keywords, limit = 18, marketplace = "") {
  const arr = normalizeKeywordArray(keywords, getMarketplaceKeywordMax(marketplace), marketplace);
  if (!arr.length) return "";
  const shown = arr.slice(0, limit).join(", ");
  return arr.length > limit ? `${shown}, … (${arr.length} total)` : shown;
}

function splitKeywords(value, max, marketplace = "") {
  const cap = Number.isFinite(max) ? max : getMarketplaceKeywordMax(marketplace);
  return normalizeKeywordsCommaList(value, cap, marketplace);
}

function firstMatch(selectors) {
  for (const selector of selectors) {
    let matches;
    try {
      matches = Array.from(document.querySelectorAll(selector));
    } catch (_e) {
      continue;
    }
    const visible = matches.find((el) => {
      const style = window.getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      const hidden =
        style.display === "none" ||
        style.visibility === "hidden" ||
        rect.width === 0 ||
        rect.height === 0;
      return !hidden && !el.disabled;
    });
    if (visible) return visible;
    if (matches[0]) return matches[0];
  }
  return null;
}

function fillTextField(value, selectors) {
  if (!value) return false;
  const el = firstMatch(selectors);
  if (el?.isContentEditable) {
    el.textContent = value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  return setNativeValue(el, value);
}

/** Kosongkan field teks (fillTextField tidak mengisi string kosong). */
function clearTextField(selectors) {
  const el = firstMetadataField(selectors) || firstMatch(selectors);
  if (!el || isLikelyNoiseMetadataField(el)) return false;
  if (el.isContentEditable) {
    el.textContent = "";
    dispatchTypingEvents(el);
    return true;
  }
  const ok = setNativeValue(el, "");
  if (ok) flushNativeFieldValueCommitted(el);
  return ok;
}

function dispatchTypingEvents(el) {
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  el.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
  el.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", bubbles: true }));
  el.dispatchEvent(new Event("blur", { bubbles: true }));
}

function fillVecteezyKeywordTags(value) {
  const keywords = expandVecteezyKeywordsToChipList(value);
  if (!keywords.length) return false;

  for (const tag of findVecteezyMergedCommaTagElements()) {
    clickVecteezyTagRemoveButton(tag);
  }

  const input = findVecteezyKeywordTagInput();
  if (!input) return false;

  let inserted = 0;
  for (const keyword of keywords) {
    if (getVecteezyExistingTags().size >= VECTEEZY_KEYWORD_MAX) break;
    if (getVecteezyExistingTags().has(keyword.toLowerCase())) continue;
    setVecteezyTagInputValue(input, keyword);
    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    input.dispatchEvent(new KeyboardEvent("keypress", { key: "Enter", bubbles: true }));
    input.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    inserted += 1;
  }

  return inserted > 0 || getVecteezyExistingTags().size >= 5;
}

function sleep(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function isFormFieldVisible(el) {
  if (!el) return false;
  const style = window.getComputedStyle(el);
  if (style.display === "none" || style.visibility === "hidden") return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0 && !el.disabled;
}

/** Hindari kolom Search / filter situs contributor yang lebih dulu tertangkap firstMatch umum */
function isLikelyNoiseMetadataField(el) {
  if (!(el instanceof HTMLElement)) return true;
  const type = String(el.type || "").toLowerCase();
  if (["search", "hidden", "radio", "checkbox", "submit", "button", "file"].includes(type)) return true;
  const role = String(el.getAttribute("role") || "").toLowerCase();
  if (role.includes("search")) return true;
  const nm = `${el.name || ""} ${el.id || ""} ${el.placeholder || ""} ${el.getAttribute("aria-label") || ""}`.toLowerCase();
  if (/\bsearch\b|\bfilter\b|\b(find|browse)\s+assets\b/.test(nm)) return true;
  return false;
}

function hintOf(el) {
  return `${el.name || ""} ${el.id || ""} ${el.placeholder || ""} ${el.getAttribute("aria-label") || ""}`.toLowerCase();
}

/**
 * Cocok untuk title/desc/keywords di area konten utama, bukan search bar atas.
 */
function firstMetadataField(selectors, root = document) {
  const bases =
    root === document || !root?.querySelectorAll
      ? [document.querySelector("main"), document.querySelector('[role="main"]'), document.body].filter(Boolean)
      : [root];

  for (const base of bases) {
    if (!base) continue;
    for (const selector of selectors) {
      let list;
      try {
        list = Array.from(base.querySelectorAll(selector));
      } catch (_e) {
        continue;
      }
      const hit = list.find(
        (el) => !isInsideNeronaOverlay(el) && isFormFieldVisible(el) && !isLikelyNoiseMetadataField(el)
      );
      if (hit) return hit;
    }
  }
  return null;
}

function flushNativeFieldValueCommitted(el, emptyHint = true) {
  if (!(el instanceof HTMLElement)) return;
  try {
    el.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        inputType: emptyHint ? "deleteContentBackward" : "insertText",
        data: null
      })
    );
  } catch (_e) {
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

function vecteezyHasChipKeywordUi(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  if (root.querySelector('ul[data-testid="tags-list"]')) return true;
  return Boolean(findVecteezyKeywordTagInput(root));
}

function getVecteezyTagChipLabel(tagEl) {
  if (!(tagEl instanceof HTMLElement)) return "";
  const labelNode =
    tagEl.querySelector("p, span") ||
    Array.from(tagEl.childNodes).find((n) => n.nodeType === Node.TEXT_NODE);
  const raw =
    labelNode instanceof HTMLElement
      ? labelNode.textContent
      : labelNode?.textContent || tagEl.textContent;
  return String(raw || "")
    .replace(/\s+/g, " ")
    .trim();
}

function findVecteezyMergedCommaTagElements(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  const out = [];
  const seen = new Set();
  const tagContainers = root.querySelectorAll(
    [
      'ul[data-testid="tags-list"] [data-testid="tag"]',
      '[data-testid*="tags" i] [data-testid*="tag" i]',
      '[class*="tag" i][class*="chip" i]',
      ".MuiChip-root"
    ].join(", ")
  );
  tagContainers.forEach((el) => {
    if (!(el instanceof HTMLElement) || isInsideNeronaOverlay(el)) return;
    const label = getVecteezyTagChipLabel(el);
    if (!label) return;
    if (!/[,;]/.test(label) && !isStandaloneKeywordStopword(label)) return;
    if (seen.has(el)) return;
    seen.add(el);
    out.push(el);
  });
  return out;
}

function clickVecteezyTagRemoveButton(tagEl) {
  if (!(tagEl instanceof HTMLElement)) return false;
  const candidates = Array.from(
    tagEl.querySelectorAll(
      [
        'button[aria-label*="remove" i]',
        'button[aria-label*="delete" i]',
        'button[aria-label*="close" i]',
        'button[title*="remove" i]',
        'button[title*="delete" i]',
        'button[title*="close" i]',
        '[data-testid*="remove" i]',
        "button.MuiChip-deleteIcon",
        ".MuiChip-root button"
      ].join(", ")
    )
  ).filter((el) => el instanceof HTMLElement && isFormFieldVisible(el) && !isInsideNeronaOverlay(el));
  if (candidates.length) {
    candidates.sort((a, b) => a.getBoundingClientRect().width - b.getBoundingClientRect().width);
    candidates[0].click();
    return true;
  }
  const btns = Array.from(tagEl.querySelectorAll("button")).filter(
    (b) => b instanceof HTMLElement && isFormFieldVisible(b) && !isInsideNeronaOverlay(b)
  );
  btns.sort((a, b) => a.getBoundingClientRect().width - b.getBoundingClientRect().width);
  const small = btns.find((b) => {
    const r = b.getBoundingClientRect();
    return r.width > 0 && r.width <= 36 && r.height > 0 && r.height <= 36;
  });
  if (small) {
    small.click();
    return true;
  }
  return false;
}

async function removeVecteezyMergedCommaTagsAsync(scopeRoot) {
  for (let round = 0; round < 32; round += 1) {
    const merged = findVecteezyMergedCommaTagElements(scopeRoot);
    if (!merged.length) break;
    let removed = false;
    for (const tag of merged) {
      if (clickVecteezyTagRemoveButton(tag)) {
        removed = true;
        await sleep(55);
      }
    }
    if (!removed) break;
  }
}

function getVecteezyExistingTags() {
  const tags = new Set();
  const nodes = document.querySelectorAll([
    // Pola utama (yang kita gunakan juga saat insert).
    'ul[data-testid="tags-list"] [data-testid="tag"] p',
    'ul[data-testid="tags-list"] [data-testid="tag"] span',
    'ul[data-testid="tags-list"] p',
    // Fallback: beberapa halaman Vecteezy memakai struktur berbeda.
    '[data-testid*="tags" i] [data-testid*="tag" i] p',
    '[data-testid*="tags" i] [data-testid*="tag" i] span',
    '[class*="tag" i] p',
    '[class*="tag" i] span'
  ].join(", "));
  nodes.forEach((el) => {
    const t = (el.textContent || "").trim().toLowerCase();
    if (t && !/^\d+$/.test(t)) tags.add(t);
  });
  return tags;
}

/** scopeRoot: batasi pencarian ke satu kartu/baris (upload multi-aset). Default: seluruh dokumen */
function findVecteezyKeywordTagInput(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;

  const badPlaceholder = (el) => {
    const ph = (el.getAttribute("placeholder") || "").toLowerCase();
    const al = (el.getAttribute("aria-label") || "").toLowerCase();
    const nm = (el.getAttribute("name") || "").toLowerCase();
    if (ph.includes("min 3 words") || ph.includes("title")) return true;
    if (al.includes("title") && !al.includes("keyword")) return true;
    if (nm.includes("title") && !nm.includes("keyword")) return true;
    return false;
  };

  const scoreInput = (el) => {
    let score = 0;
    const ph = (el.getAttribute("placeholder") || "").toLowerCase();
    const al = (el.getAttribute("aria-label") || "").toLowerCase();
    const id = (el.getAttribute("id") || "").toLowerCase();
    if (ph.includes("keyword") || al.includes("keyword")) score += 50;
    if (ph.includes("comma") || ph.includes("tag")) score += 40;
    if (id.includes("keyword") || id.includes("tag")) score += 30;
    if (!badPlaceholder(el)) score += 5;
    return score;
  };

  const collectInputs = (root) => {
    if (!root) return [];
    return [
      ...root.querySelectorAll(
        'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="file"]):not([type="submit"]):not([type="button"])'
      ),
      ...root.querySelectorAll("textarea"),
      ...root.querySelectorAll('[contenteditable="true"]')
    ].filter(isFormFieldVisible);
  };

  const lists = Array.from(root.querySelectorAll('ul[data-testid="tags-list"]'));
  for (const list of lists) {
    const ls = window.getComputedStyle(list);
    if (ls.display === "none" || ls.visibility === "hidden") continue;

    let root = list.parentElement;
    for (let d = 0; d < 18 && root; d++) {
      const inputs = collectInputs(root);
      const scored = inputs
        .filter((el) => !badPlaceholder(el))
        .map((el) => ({ el, s: scoreInput(el) }))
        .sort((a, b) => b.s - a.s);
      if (scored[0]?.el) return scored[0].el;
      root = root.parentElement;
    }

    let sib = list.nextElementSibling;
    for (let i = 0; i < 6 && sib; i++) {
      const inputs = collectInputs(sib);
      const best = inputs.filter((el) => !badPlaceholder(el)).sort((a, b) => scoreInput(b) - scoreInput(a))[0];
      if (best) return best;
      sib = sib.nextElementSibling;
    }

    let prev = list.previousElementSibling;
    for (let i = 0; i < 6 && prev; i++) {
      const inputs = collectInputs(prev);
      const best = inputs.filter((el) => !badPlaceholder(el)).sort((a, b) => scoreInput(b) - scoreInput(a))[0];
      if (best) return best;
      prev = prev.previousElementSibling;
    }
  }

  const labelNodes = Array.from(
    root.querySelectorAll("label, span, p, div, h2, h3, h4")
  );
  for (const node of labelNodes) {
    const raw = (node.textContent || "").trim();
    if (!/^keywords?\s*\*?/i.test(raw) && raw.toLowerCase().indexOf("keywords") !== 0) continue;

    let scope = node.closest("section") || node.closest("form") || node.parentElement;
    for (let i = 0; i < 22 && scope; i++) {
      const inputs = collectInputs(scope)
        .filter((el) => !badPlaceholder(el))
        .sort((a, b) => scoreInput(b) - scoreInput(a));
      if (inputs[0]) return inputs[0];
      scope = scope.parentElement;
    }
  }

  const muiInputs = Array.from(
    root.querySelectorAll(
      'input.MuiOutlinedInput-input, input.MuiInputBase-input, input[class*="Input"][type="text"], input[type="text"]'
    )
  )
    .filter(isFormFieldVisible)
    .filter((el) => !badPlaceholder(el));
  if (muiInputs.length >= 2) {
    muiInputs.sort(
      (a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top
    );
    return muiInputs[1];
  }
  if (muiInputs.length === 1) {
    return muiInputs[0];
  }

  return null;
}

const VECTEEZY_PROHIBITED_KEYWORDS = new Set([
  "vector",
  "vectors",
  "photo",
  "photos",
  "video",
  "videos",
  "ai",
  "generated"
]);

/** Token hash di judul (bukan keyword) — pola lama u…k9 + pola baru ref…. */
const MARKETPLACE_TITLE_UNIQUE_TOKEN_RE = /^(?:u[a-z0-9]{3,7}|ref[a-z0-9]{3,8})$/i;

const MARKETPLACE_OFFENSIVE_FRAGMENTS = [
  "fuck",
  "shit",
  "bitch",
  "cunt",
  "nazi",
  "porn",
  "xxx",
  "sex"
];

const MARKETPLACE_PLACEHOLDER_KEYWORD_RE = /^keyword\d+$/i;

/** Konjungsi/preposisi — dibuang jika jadi keyword sendirian (frasa multi-kata tetap OK). */
const KEYWORD_STANDALONE_STOPWORDS = new Set([
  "a",
  "an",
  "the",
  "and",
  "or",
  "but",
  "nor",
  "for",
  "to",
  "at",
  "in",
  "on",
  "of",
  "by",
  "as",
  "with",
  "from",
  "into",
  "via",
  "vs"
]);

function isStandaloneKeywordStopword(word) {
  const s = cleanRawKeywordPiece(word).toLowerCase();
  if (!s || /\s/.test(s)) return false;
  const token = s.replace(/[^a-z]/g, "");
  return Boolean(token && KEYWORD_STANDALONE_STOPWORDS.has(token));
}

const MARKETPLACE_JSON_ARTIFACT_RE =
  /^(?:null|undefined|true|false|\[object object\]|\[object array\])$/i;

const VECTEEZY_KEYWORD_FILLER = [
  "illustration",
  "design",
  "graphic",
  "colorful",
  "background",
  "creative",
  "art",
  "style"
];

const VECTEEZY_TITLE_MIN_WORDS = 6;
const VECTEEZY_TITLE_MAX_WORDS = 16;
const VECTEEZY_TITLE_MAX_CHARS = 200;
const VECTEEZY_KEYWORD_MAX = 50;
const MAGNIFIC_KEYWORD_MAX = 50;
const MIRICANVAS_KEYWORD_MAX = 25;
const SHUTTERSTOCK_KEYWORD_MAX = 50;

function getMarketplaceKeywordMax(marketplace) {
  const mp = String(marketplace || "").toLowerCase();
  if (mp === "miricanvas") return MIRICANVAS_KEYWORD_MAX;
  if (mp === "vecteezy") return VECTEEZY_KEYWORD_MAX;
  if (mp === "magnific") return MAGNIFIC_KEYWORD_MAX;
  if (mp === "shutterstock") return SHUTTERSTOCK_KEYWORD_MAX;
  return 50;
}

/** Chip keyword contributor Vecteezy: hanya a-z dan 0-9 (tanpa koma/simbol/spasi — “no special characters”). */
function normalizeVecteezyKeywordLettersOnly(raw) {
  return String(raw || "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]/g, "");
}

function isMarketplaceTitleUniqueToken(word) {
  const compact = String(word || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
  return Boolean(compact && MARKETPLACE_TITLE_UNIQUE_TOKEN_RE.test(compact));
}

function hasMarketplaceOffensiveFragment(word) {
  const w = String(word || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  if (!w) return false;
  return MARKETPLACE_OFFENSIVE_FRAGMENTS.some((frag) => w.includes(frag));
}

function isVecteezyTitleUniqueToken(word) {
  const w = normalizeVecteezyKeywordLettersOnly(word);
  return Boolean(w && MARKETPLACE_TITLE_UNIQUE_TOKEN_RE.test(w));
}

function hasVecteezyOffensiveFragment(word) {
  return hasMarketplaceOffensiveFragment(word);
}

/** Tag harus terbaca (bukan hash judul / gibberish / placeholder keyword1). */
function isReadableVecteezyKeyword(word) {
  const w = normalizeVecteezyKeywordLettersOnly(word);
  if (!w || w.length < 2 || w.length > 32) return false;
  if (KEYWORD_STANDALONE_STOPWORDS.has(w)) return false;
  if (VECTEEZY_PROHIBITED_KEYWORDS.has(w)) return false;
  if (isVecteezyTitleUniqueToken(w)) return false;
  if (hasVecteezyOffensiveFragment(w)) return false;
  if (/^keyword\d+$/i.test(w)) return false;
  if (/^\d+$/.test(w)) return false;

  const digitRatio = (w.match(/\d/g) || []).length / w.length;
  if (digitRatio > 0.35) return false;

  if (w.length >= 4) {
    if (!/[aeiouy]/.test(w)) return false;
    if (/[bcdfghjklmnpqrstvwxz]{5,}/i.test(w)) return false;
  }

  return true;
}

function expandVecteezyKeywordsToChipList(text) {
  const out = [];
  const seen = new Set();
  const pieces = String(text || "")
    .split(/[,;\n\r]+/g)
    .flatMap((chunk) => {
      const c = cleanRawKeywordPiece(chunk);
      if (!c) return [];
      return c.split(/\s+/).map((x) => x.trim()).filter(Boolean);
    });
  for (const p of pieces) {
    const w = normalizeVecteezyKeywordLettersOnly(p);
    if (!w || !isReadableVecteezyKeyword(w)) continue;
    if (seen.has(w)) continue;
    seen.add(w);
    out.push(w);
    if (out.length >= VECTEEZY_KEYWORD_MAX) break;
  }
  return out;
}

function scrubVecteezyKeywordComma(value) {
  return expandVecteezyKeywordsToChipList(value).join(", ");
}

function expandMagnificKeywordsToChipList(text) {
  return sanitizeKeywordListForMarketplace(text, "magnific", { max: MAGNIFIC_KEYWORD_MAX });
}

function resolveMarketplaceKeyFromLabel(label) {
  const s = String(label || "").toLowerCase();
  if (s.includes("vecteezy")) return "vecteezy";
  if (s.includes("adobe")) return "adobe";
  if (s.includes("magnific")) return "magnific";
  if (s.includes("shutterstock")) return "shutterstock";
  if (s.includes("canva")) return "canva";
  if (s.includes("miricanvas")) return "miricanvas";
  if (s.includes("dreamstime")) return "dreamstime";
  if (s.includes("design bundle") || s.includes("designbundle")) return "designbundle";
  return s.replace(/\s+/g, "") || "";
}

function cleanRawKeywordPiece(piece) {
  let s = String(piece || "")
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .replace(/^["'`]+|["'`]+$/g, "")
    .trim();
  if (!s) return "";
  if (/^https?:\/\//i.test(s) || /^www\./i.test(s) || /^\/\//.test(s)) return "";
  if (/^[\[{]/.test(s) && /[\}\]]$/.test(s)) return "";
  s = s.replace(/^#+/, "").replace(/\s+/g, " ").trim();
  return s;
}

function isBlockedMarketplaceKeyword(word, marketplace) {
  const raw = cleanRawKeywordPiece(word);
  if (!raw) return true;
  if (isStandaloneKeywordStopword(raw)) return true;
  const compact = raw.toLowerCase().replace(/[^a-z0-9]/g, "");
  if (!compact || compact.length < 2) return true;
  if (MARKETPLACE_PLACEHOLDER_KEYWORD_RE.test(compact)) return true;
  if (MARKETPLACE_JSON_ARTIFACT_RE.test(compact)) return true;
  if (isMarketplaceTitleUniqueToken(compact)) return true;
  if (hasMarketplaceOffensiveFragment(compact)) return true;
  return false;
}

/** Keyword terbaca untuk comma-list marketplaces (Adobe, Magnific, Shutterstock, Canva, dll.). */
function isReadableStockKeyword(word, marketplace) {
  if (isBlockedMarketplaceKeyword(word, marketplace)) return false;
  const s = cleanRawKeywordPiece(word);
  if (!s || s.length > 80) return false;

  const mp = String(marketplace || "").toLowerCase();
  if (mp === "vecteezy") {
    const w = normalizeVecteezyKeywordLettersOnly(s);
    return isReadableVecteezyKeyword(w);
  }

  if (/^\d+$/.test(s.replace(/[^a-z0-9]/gi, ""))) return false;
  const digitRatio = (s.match(/\d/g) || []).length / s.length;
  if (digitRatio > 0.45) return false;

  const lettersOnly = s.replace(/[^a-z]/gi, "");
  if (lettersOnly.length >= 5 && !/\s/.test(s)) {
    if (!/[aeiouy]/i.test(lettersOnly)) return false;
    if (/[bcdfghjklmnpqrstvwxz]{5,}/i.test(lettersOnly)) return false;
  }

  return true;
}

function formatKeywordTokenForMarketplace(word, marketplace) {
  const mp = String(marketplace || "").toLowerCase();
  if (mp === "vecteezy") {
    const w = normalizeVecteezyKeywordLettersOnly(word);
    return isReadableVecteezyKeyword(w) ? w : "";
  }
  const s = cleanRawKeywordPiece(word);
  if (!s || !isReadableStockKeyword(s, mp)) return "";
  if (mp === "miricanvas") {
    const one = s.replace(/[,;]+/g, " ").replace(/\s+/g, " ").trim();
    return one.length <= 80 ? one : one.slice(0, 80).trim();
  }
  return s.slice(0, 80);
}

function splitKeywordInputPieces(value, marketplace) {
  const mp = String(marketplace || "").toLowerCase();
  const chipLike = mp === "vecteezy" || mp === "miricanvas";
  const pieces = [];
  for (const chunk of String(value || "").split(/[,;\n\r]+/)) {
    const c = cleanRawKeywordPiece(chunk);
    if (!c) continue;
    if (chipLike) {
      for (const part of c.split(/\s+/).map((x) => x.trim()).filter(Boolean)) {
        pieces.push(part);
      }
    } else {
      pieces.push(c);
    }
  }
  return pieces;
}

function sanitizeKeywordListForMarketplace(value, marketplace, options = {}) {
  const max = Number.isFinite(options.max) ? options.max : 50;
  const mp = String(marketplace || "").toLowerCase();
  const out = [];
  const seen = new Set();

  const push = (piece) => {
    const formatted = formatKeywordTokenForMarketplace(piece, mp);
    if (!formatted) return;
    const key = formatted.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    out.push(formatted);
  };

  const input =
    Array.isArray(value) ? value.join(", ") : String(value || "");
  for (const piece of splitKeywordInputPieces(input, mp)) {
    push(piece);
    if (out.length >= max) break;
  }

  if (options.fallbackTitle && options.augmentFromTitle !== false) {
    for (const tw of String(options.fallbackTitle).split(/[\s,.-]+/)) {
      push(tw);
      if (out.length >= max) break;
    }
  }

  return out.slice(0, max);
}

function sanitizeMarketplaceKeywordsComma(value, marketplace, options = {}) {
  return sanitizeKeywordListForMarketplace(value, marketplace, options).join(", ");
}

function setVecteezyTagInputValue(el, text) {
  if (!el) return false;
  el.focus();
  if (el.isContentEditable) {
    try {
      document.execCommand("selectAll", false, undefined);
      document.execCommand("delete", false, undefined);
      const ok = document.execCommand("insertText", false, text);
      if (ok) {
        el.dispatchEvent(
          new InputEvent("input", { bubbles: true, inputType: "insertText", data: text })
        );
        return true;
      }
    } catch (_e) {
      // fall through
    }
    el.textContent = text;
    el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    return true;
  }
  setNativeValue(el, text);
  el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
  return true;
}

async function fillVecteezyKeywordTagsAsync(value, options = {}) {
  const scopeRoot = options.scopeRoot;

  const keywords = expandVecteezyKeywordsToChipList(value);
  if (!keywords.length) return false;

  await removeVecteezyMergedCommaTagsAsync(scopeRoot ?? document);

  const resolveInput = () => {
    let el = findVecteezyKeywordTagInput(scopeRoot ?? document);
    if (!el && scopeRoot && scopeRoot !== document) {
      el = findVecteezyKeywordTagInput(document);
    }
    return el;
  };

  if (!resolveInput()) {
    return false;
  }

  const findPlusNear = (inp) => {
    let root = inp?.parentElement;
    for (let d = 0; d < 12 && root; d++) {
      const btn =
        root.querySelector('button[aria-label*="add" i]') ||
        root.querySelector('button[data-testid*="add" i]') ||
        root.querySelector('svg[data-testid*="add" i]')?.closest("button");
      if (btn instanceof HTMLElement) return btn;
      root = root.parentElement;
    }
    return null;
  };

  let inserted = 0;
  const tryCommit = async (keyword) => {
    const input = resolveInput();
    if (!input) return false;

    const existingBefore = getVecteezyExistingTags();
    if (existingBefore.has(keyword.toLowerCase())) {
      return true;
    }

    const plusBtn = findPlusNear(input);

    setVecteezyTagInputValue(input, keyword);
    await sleep(40);

    const enterEvent = {
      key: "Enter",
      code: "Enter",
      keyCode: 13,
      which: 13,
      bubbles: true
    };
    input.dispatchEvent(new KeyboardEvent("keydown", enterEvent));
    input.dispatchEvent(new KeyboardEvent("keypress", enterEvent));
    input.dispatchEvent(new KeyboardEvent("keyup", enterEvent));
    await sleep(90);

    let existingAfter = getVecteezyExistingTags();
    if (existingAfter.has(keyword.toLowerCase())) return true;

    if (plusBtn instanceof HTMLElement) {
      plusBtn.click();
      await sleep(90);
      existingAfter = getVecteezyExistingTags();
      if (existingAfter.has(keyword.toLowerCase())) return true;
    }

    return false;
  };

  for (const keyword of keywords) {
    if (getVecteezyExistingTags().size >= VECTEEZY_KEYWORD_MAX) break;
    if (getVecteezyExistingTags().has(keyword.toLowerCase())) continue;
    const committed = await tryCommit(keyword);
    if (committed) {
      inserted += 1;
    }
  }

  return inserted > 0 || getVecteezyExistingTags().size >= 5;
}

/** Magnific contributor: keyword = chip/tag (Enter per kata), bukan string berkoma sekaligus. */
function findMagnificKeywordTagInput(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;

  const direct = [
    '[data-cy*="tag" i] input[type="text"]',
    '[data-cy*="tag" i] input:not([type])',
    '[data-cy*="keyword" i] input[type="text"]',
    '[data-cy*="keyword" i] input:not([type])',
    '.tags-input input[type="text"]',
    '.tags-input input:not([type])',
    '[class*="tags-input" i] input[type="text"]',
    '[class*="tags-input" i] input:not([type])',
    '[class*="tag-input" i] input[type="text"]',
    '[class*="tag-input" i] input:not([type])'
  ];

  for (const sel of direct) {
    const el = root.querySelector(sel);
    if (el instanceof HTMLElement && isFormFieldVisible(el) && !isLikelyNoiseMetadataField(el)) {
      return el;
    }
  }

  return findVecteezyKeywordTagInput(root);
}

function magnificHasChipKeywordUi(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  if (
    root.querySelector(
      [
        '[data-cy*="tag" i]:not(input):not(button)',
        '[class*="tags-list" i]',
        '[class*="tag-list" i]',
        '[class*="tags-input" i]',
        ".MuiChip-root"
      ].join(", ")
    )
  ) {
    return Boolean(findMagnificKeywordTagInput(root));
  }
  return Boolean(findMagnificKeywordTagInput(root));
}

function getMagnificExistingTags(scopeRoot = document) {
  const tags = new Set();
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  const nodes = root.querySelectorAll(
    [
      '[data-cy*="tag" i]:not(input):not(button) span',
      '[data-cy*="tag" i]:not(input):not(button) p',
      '[class*="tags-list" i] [class*="tag" i]:not(input):not(button)',
      '[class*="tag-list" i] [class*="tag" i]:not(input):not(button)',
      '[class*="tags-input" i] [class*="tag" i]:not(input):not(button)',
      ".MuiChip-root .MuiChip-label",
      '[class*="tag" i][class*="chip" i] p',
      '[class*="tag" i][class*="chip" i] span'
    ].join(", ")
  );
  nodes.forEach((el) => {
    const t = String(el.textContent || "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
    if (t && !/^\d+$/.test(t)) tags.add(t);
  });
  return tags;
}

function fillMagnificKeywordTags(value, scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  const keywords = expandMagnificKeywordsToChipList(value);
  if (!keywords.length) return false;

  for (const tag of findVecteezyMergedCommaTagElements(root)) {
    clickVecteezyTagRemoveButton(tag);
  }

  const input = findMagnificKeywordTagInput(root);
  if (!input) return false;

  let inserted = 0;
  for (const keyword of keywords) {
    if (getMagnificExistingTags(root).size >= MAGNIFIC_KEYWORD_MAX) break;
    const existing = getMagnificExistingTags(root);
    if (existing.has(keyword.toLowerCase())) continue;
    setVecteezyTagInputValue(input, keyword);
    input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    input.dispatchEvent(new KeyboardEvent("keypress", { key: "Enter", bubbles: true }));
    input.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    inserted += 1;
  }

  return inserted > 0 || getMagnificExistingTags(root).size >= 5;
}

async function fillMagnificKeywordTagsAsync(value, options = {}) {
  const scopeRoot = options.scopeRoot;
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  const keywords = expandMagnificKeywordsToChipList(value);
  if (!keywords.length) return false;

  await removeVecteezyMergedCommaTagsAsync(root);

  const resolveInput = () => {
    let el = findMagnificKeywordTagInput(root);
    if (!el && scopeRoot && scopeRoot !== document) {
      el = findMagnificKeywordTagInput(document);
    }
    return el;
  };

  if (!resolveInput()) return false;

  const findPlusNear = (inp) => {
    let parent = inp?.parentElement;
    for (let d = 0; d < 12 && parent; d += 1) {
      const btn =
        parent.querySelector('button[aria-label*="add" i]') ||
        parent.querySelector('button[data-cy*="add" i]') ||
        parent.querySelector('button[data-testid*="add" i]') ||
        parent.querySelector('svg[data-cy*="add" i]')?.closest("button");
      if (btn instanceof HTMLElement) return btn;
      parent = parent.parentElement;
    }
    return null;
  };

  let inserted = 0;
  const tryCommit = async (keyword) => {
    const input = resolveInput();
    if (!input) return false;

    const existingBefore = getMagnificExistingTags(root);
    if (existingBefore.has(keyword.toLowerCase())) return true;

    const plusBtn = findPlusNear(input);
    setVecteezyTagInputValue(input, keyword);
    await sleep(40);

    const enterEvent = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true };
    input.dispatchEvent(new KeyboardEvent("keydown", enterEvent));
    input.dispatchEvent(new KeyboardEvent("keypress", enterEvent));
    input.dispatchEvent(new KeyboardEvent("keyup", enterEvent));
    await sleep(90);

    if (getMagnificExistingTags(root).has(keyword.toLowerCase())) return true;

    if (plusBtn instanceof HTMLElement) {
      plusBtn.click();
      await sleep(90);
      if (getMagnificExistingTags(root).has(keyword.toLowerCase())) return true;
    }

    return false;
  };

  for (const keyword of keywords) {
    if (getMagnificExistingTags(root).size >= MAGNIFIC_KEYWORD_MAX) break;
    if (getMagnificExistingTags(root).has(keyword.toLowerCase())) continue;
    if (await tryCommit(keyword)) inserted += 1;
  }

  return inserted > 0 || getMagnificExistingTags(root).size >= 5;
}

async function applyMagnificTagsAfterMetadata(metadata, scopeEl) {
  const norm = normalizeMetadataForMarketplace(metadata, "magnific");
  if (!norm?.keywords) return false;
  return fillMagnificKeywordTagsAsync(norm.keywords, { scopeRoot: scopeEl || document });
}

/** Miricanvas: chip IF-add5 / IK-859d (Enter per kata) atau textarea Multiple keywords. */
function sortElementsDomOrder(els) {
  return [...els].sort((a, b) => {
    const ra = a.getBoundingClientRect();
    const rb = b.getBoundingClientRect();
    if (Math.abs(ra.top - rb.top) > 10) return ra.top - rb.top;
    return ra.left - rb.left;
  });
}

function getMiricanvasPanelKeywordBlocks(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  let blocks = Array.from(root.querySelectorAll('[data-f="IK-859d"]')).filter(
    (el) => !isInsideNeronaOverlay(el)
  );
  if (!blocks.length) {
    blocks = Array.from(root.querySelectorAll('form[data-f="IF-96d1"]')).filter(
      (el) => !isInsideNeronaOverlay(el) && !el.closest('[data-f="IK-859d"]')
    );
  }
  return sortElementsDomOrder(blocks);
}

function readMiricanvasGridRowImageKey(row) {
  if (!row) return "";
  const thumb = row.querySelector?.(`${MIRICANVAS_ASSET_THUMB_SEL}[src], img[src]`);
  if (!thumb) return "";
  return normalizeMiricanvasFileUrlKey(
    upgradeMiricanvasContributorImageUrl(resolveBestImageUrlFromElement(thumb))
  );
}

function findMiricanvasKeywordBlockInRow(row) {
  if (!row?.isConnected) return null;
  const hit =
    row.querySelector('[data-f="IK-859d"]') ||
    row.querySelector('form[data-f="IF-96d1"]') ||
    row.querySelector('[data-f="IF-add5"]');
  if (!hit) return null;
  return hit.closest('[data-f="IK-859d"]') || hit;
}

function findMiricanvasKeywordBlockForGridRow(gridRow, blocks = null) {
  if (!gridRow?.isConnected) return null;

  const inRow = findMiricanvasKeywordBlockInRow(gridRow);
  if (inRow) return inRow;

  const list = blocks || getMiricanvasPanelKeywordBlocks();
  if (!list.length) return null;

  const rowKey = readMiricanvasGridRowImageKey(gridRow);
  if (rowKey) {
    for (const block of list) {
      if (readMiricanvasPanelBlockImageKey(block) === rowKey) return block;
    }
  }

  const rowRect = gridRow.getBoundingClientRect();
  let best = null;
  let bestScore = Infinity;
  for (const block of list) {
    const br = block.getBoundingClientRect();
    const score = Math.abs(br.top - rowRect.top) + Math.abs(br.left - rowRect.left) * 0.15;
    if (score < bestScore) {
      bestScore = score;
      best = block;
    }
  }
  return best;
}

function readMiricanvasPanelBlockImageKey(block) {
  if (!block) return "";
  for (const img of block.querySelectorAll?.("img[src]") || []) {
    const src = upgradeMiricanvasContributorImageUrl(resolveBestImageUrlFromElement(img));
    const key = normalizeMiricanvasFileUrlKey(src);
    if (key) return key;
  }
  const tile = block.closest?.(MIRICANVAS_ASSET_TILE_SEL);
  if (tile) return readMiricanvasGridRowImageKey(tile);
  return "";
}

/** Scope panel keyword ke baris yang cocok dengan tile terpilih (hindari tertukar dengan tetangga). */
function findMiricanvasKeywordScopeForJob(job, gridRow = null) {
  const targetRow =
    gridRow ||
    (job?.row?.isConnected ? job.row : null) ||
    findMiricanvasTileRowByJob(job);

  const inRow = findMiricanvasKeywordBlockInRow(targetRow);
  if (inRow) return inRow;

  const blocks = getMiricanvasPanelKeywordBlocks();
  if (!blocks.length) return document;

  const blockForRow = findMiricanvasKeywordBlockForGridRow(targetRow, blocks);
  if (blockForRow) return blockForRow;

  const wantKey =
    job?.urlKey ||
    readMiricanvasGridRowImageKey(targetRow) ||
    normalizeMiricanvasFileUrlKey(String(job?.pinnedUrl || job?.rawUrl || ""));
  if (wantKey) {
    for (const block of blocks) {
      if (readMiricanvasPanelBlockImageKey(block) === wantKey) return block;
    }
  }

  const fileName = String(job?.fileName || readMiricanvasTileFileName(targetRow) || "")
    .trim()
    .toLowerCase();
  if (fileName) {
    for (const block of blocks) {
      const tile = block.closest?.(MIRICANVAS_ASSET_TILE_SEL);
      const fn = readMiricanvasTileFileName(tile || block).toLowerCase();
      if (fn && fn === fileName) return block;
    }
  }

  return blocks.length === 1 ? blocks[0] : document;
}

async function waitForMiricanvasPanelSynced(job, gridRow, timeoutMs = 2500) {
  const wantKey =
    job?.urlKey ||
    readMiricanvasGridRowImageKey(gridRow) ||
    normalizeMiricanvasFileUrlKey(String(job?.pinnedUrl || job?.rawUrl || ""));
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (gridRow?.isConnected && findMiricanvasKeywordBlockInRow(gridRow)) {
      return true;
    }
    const scope = findMiricanvasKeywordScopeForJob(job, gridRow);
    if (scope && scope !== document) {
      const scopeKey = readMiricanvasPanelBlockImageKey(scope);
      if (!wantKey || !scopeKey || scopeKey === wantKey) return true;
    }
    if (readMiricanvasToolbarSelectedCount() === 1 && waitForMiricanvasSingleAssetPanel(0)) {
      return true;
    }
    await sleep(120);
  }
  return false;
}

function resolveMiricanvasKeywordScope(scopeRoot = document, options = {}) {
  if (options?.job || options?.gridRow) {
    return findMiricanvasKeywordScopeForJob(options.job, options.gridRow);
  }
  return scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
}

function findMiricanvasKeywordChipContainer(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  return (
    root.querySelector('[data-f="IF-add5"]') ||
    root.querySelector('[data-f="IK-859d"] [data-f="IF-add5"]') ||
    (root.matches?.('[data-f="IF-add5"], [data-f="IK-859d"]') ? root : null) ||
    root.querySelector('[data-f="IK-859d"]') ||
    null
  );
}

function miricanvasHasChipKeywordUi(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  if (findMiricanvasKeywordChipContainer(root)) return true;
  if (root.querySelector('span[data-f="CL-67aa"] span[data-f="CS-567c"]')) return true;
  if (root.querySelector("span.css-mei3hz span.css-8uhtka")) return true;
  return Boolean(findMiricanvasKeywordTagInput(root));
}

function getMiricanvasExistingTags(scopeRoot = document) {
  const tags = new Set();
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  root
    .querySelectorAll('span[data-f="CS-567c"], span.css-8uhtka.e16oeupu3, span.css-8uhtka')
    .forEach((el) => {
      if (isInsideNeronaOverlay(el)) return;
      if (!el.closest('span[data-f="CL-67aa"], span.css-mei3hz')) return;
      const t = (el.textContent || "").trim();
      if (t && t.length <= 120) tags.add(t.toLowerCase());
    });
  return tags;
}

function getMiricanvasChipRows(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  return Array.from(root.querySelectorAll('span[data-f="CL-67aa"], span.css-mei3hz.e16oeupu3')).filter(
    (el) =>
      !isInsideNeronaOverlay(el) &&
      (el.querySelector('span[data-f="CS-567c"]') || el.querySelector("span.css-8uhtka"))
  );
}

function scoreMiricanvasKeywordInput(el) {
  let score = 0;
  const ph = (el.getAttribute("placeholder") || "").toLowerCase();
  const al = (el.getAttribute("aria-label") || "").toLowerCase();
  const nm = `${el.name || ""} ${el.id || ""}`.toLowerCase();
  if (/tag|keyword|hash|태그|키워드|해시/.test(ph + al + nm)) score += 55;
  if (el.closest('span[data-f="CL-67aa"], span.css-mei3hz')) score -= 80;
  if (String(el.type || "").toLowerCase() === "search") score -= 50;
  return score;
}

function findMiricanvasKeywordTagInput(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;

  const collectInputs = (node) => {
    if (!node) return [];
    return [
      ...node.querySelectorAll(
        'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="file"]):not([type="submit"]):not([type="button"])'
      ),
      ...node.querySelectorAll("textarea"),
      ...node.querySelectorAll('[contenteditable="true"]')
    ].filter((el) => isFormFieldVisible(el) && !isInsideNeronaOverlay(el));
  };

  const chipRoot = findMiricanvasKeywordChipContainer(root);
  if (chipRoot instanceof HTMLElement) {
    const inChip = collectInputs(chipRoot);
    if (inChip.length) return inChip[inChip.length - 1];

    for (const child of chipRoot.children) {
      if (
        child instanceof HTMLElement &&
        child.matches?.('input, textarea, [contenteditable="true"]') &&
        isFormFieldVisible(child)
      ) {
        return child;
      }
    }

    const ikRoot = chipRoot.closest('[data-f="IK-859d"]') || chipRoot.parentElement;
    if (ikRoot instanceof HTMLElement) {
      const inIk = collectInputs(ikRoot);
      if (inIk.length) return inIk[inIk.length - 1];

      // Input keyword miricanvas ada di sibling dari IK-859d (form[data-f="IF-96d1"]),
      // bukan di dalam chip container. Cari di parent IK-859d.
      const ikParent = ikRoot.parentElement;
      if (ikParent instanceof HTMLElement) {
        const scored = collectInputs(ikParent)
          .map((el) => ({ el, s: scoreMiricanvasKeywordInput(el) }))
          .filter((x) => x.s > 0)
          .sort((a, b) => b.s - a.s);
        if (scored[0]?.el) return scored[0].el;
      }
    }
  }

  const anchors = [
    chipRoot,
    root.querySelector('div[data-f="IF-add5"]'),
    root.querySelector('[data-f="IF-add5"]'),
    getMiricanvasChipRows(root)[0],
    root.querySelector('span[data-f="CL-67aa"]')
  ].filter(Boolean);

  for (const anchor of anchors) {
    let node = anchor instanceof HTMLElement ? anchor : null;
    for (let d = 0; d < 22 && node; d++) {
      const scored = collectInputs(node)
        .map((el) => ({ el, s: scoreMiricanvasKeywordInput(el) }))
        .sort((a, b) => b.s - a.s);
      if (scored[0]?.s > 0) return scored[0].el;
      if (scored[0]?.el && d >= 2) return scored[0].el;
      node = node.parentElement;
    }
  }

  const labels = Array.from(root.querySelectorAll("label, span, p, div, h2, h3, h4"));
  for (const node of labels) {
    const raw = (node.textContent || "").trim();
    if (!/tags?|keywords?|keyword|태그|키워드|해시/i.test(raw)) continue;
    let scope = node.closest("section") || node.closest("form") || node.parentElement;
    for (let i = 0; i < 18 && scope; i++) {
      const scored = collectInputs(scope)
        .map((el) => ({ el, s: scoreMiricanvasKeywordInput(el) }))
        .sort((a, b) => b.s - a.s);
      if (scored[0]?.el) return scored[0].el;
      scope = scope.parentElement;
    }
  }

  return null;
}

async function focusMiricanvasKeywordChipInput(scopeRoot = document) {
  const container = findMiricanvasKeywordChipContainer(scopeRoot);
  if (container instanceof HTMLElement) {
    dispatchPlainClick(container);
    await sleep(140);
  }

  let input = findMiricanvasKeywordTagInput(scopeRoot);
  if (input instanceof HTMLElement) {
    try {
      input.focus?.();
    } catch (_e) {
      /* ignore */
    }
    await sleep(70);
    return input;
  }

  if (container instanceof HTMLElement) {
    dispatchPlainClick(container);
    await sleep(120);
    input = findMiricanvasKeywordTagInput(scopeRoot);
    if (input instanceof HTMLElement) {
      try {
        input.focus?.();
      } catch (_e) {
        /* ignore */
      }
    }
  }

  return input || null;
}

const MIRICANVAS_ELEMENT_NAME_DATA_F = "DT-9450";
/** Grid upload DesignHub: li tile, checkbox, thumbnail (DOM user 2026). */
const MIRICANVAS_ASSET_TILE_SEL = 'li[data-f="TL-ddab"]';
const MIRICANVAS_ASSET_CARD_SEL = 'article[data-f="CA-d943"]';
const MIRICANVAS_ASSET_CHECKBOX_SEL = 'input[data-f="CI-66e5"]';
const MIRICANVAS_ASSET_THUMB_SEL = 'img[data-f="CT-dbbf"]';
const MIRICANVAS_ASSET_THUMB_WRAP_SEL = '[data-f="CT-5090"]';
const MIRICANVAS_ASSET_FILENAME_SEL = 'span[data-f="CF-3d96"]';
const MIRICANVAS_ELEMENT_NAME_MAX_CHARS = 100;

const miricanvasPinnedImageUrlByEl = new WeakMap();

function normalizeMiricanvasFileUrlKey(url) {
  const raw = String(url || "").trim();
  if (!raw) return "";
  const normalizePath = (path) =>
    decodeURIComponent(String(path || ""))
      .toLowerCase()
      .replace(/_(\d{2,4})(\.(png|jpe?g|webp))$/i, "_800$2");
  try {
    const u = new URL(raw, location.href);
    return normalizePath(u.pathname);
  } catch (_e) {
    return normalizePath(raw.split("?")[0]);
  }
}

function upgradeMiricanvasContributorImageUrl(url) {
  const raw = String(url || "").trim();
  if (!raw) return raw;
  return raw.replace(/_(\d{2,4})\.(png|jpe?g|webp)(\?|$)/i, (match, size, ext, tail) => {
    const n = parseInt(size, 10);
    if (!Number.isFinite(n) || n >= 800) return match;
    return `_800.${ext}${tail || ""}`;
  });
}

function readMiricanvasTileFileName(row) {
  if (!row) return "";
  const el = row.querySelector?.(MIRICANVAS_ASSET_FILENAME_SEL);
  if (!el) return "";
  return String(el.getAttribute("title") || el.textContent || "").replace(/\s+/g, " ").trim();
}

function pickMiricanvasThumbnailResourceUrlFromRow(row, imageEl) {
  const cached = imageEl ? miricanvasPinnedImageUrlByEl.get(imageEl) : "";
  if (cached) return cached;

  const img =
    row?.querySelector?.(`${MIRICANVAS_ASSET_THUMB_SEL}[src]`) ||
    row?.querySelector?.("img[src]") ||
    imageEl;
  const url = upgradeMiricanvasContributorImageUrl(resolveBestImageUrlFromElement(img));
  if (imageEl && url) miricanvasPinnedImageUrlByEl.set(imageEl, url);
  return url;
}

function pickMiricanvasThumbnailResourceUrl(imageEl) {
  if (!imageEl || !isMiricanvasContributorHost()) return "";
  const row = findMiricanvasAssetRowForImage(imageEl);
  return pickMiricanvasThumbnailResourceUrlFromRow(row, imageEl);
}

/** Snapshot URL + nama file per tile SEBELUM deselect (hindari img DOM di-reuse React). */
function trySnapshotMiricanvasInlineData(imgEl) {
  if (!imgEl) return null;
  const w = imgEl.naturalWidth || imgEl.width;
  const h = imgEl.naturalHeight || imgEl.height;
  if (!w || !h) return null;
  try {
    return imageElementToInlineDataViaCanvas(imgEl);
  } catch (_e) {
    return null;
  }
}

function getMiricanvasGridTilesInDomOrder(gridRoot = null) {
  const scope = gridRoot && gridRoot.nodeType === 1 ? gridRoot : findMiricanvasUploadGridRoot();
  const queryRoot = scope === document ? document : scope;
  return sortMiricanvasTilesDomOrder(
    Array.from(queryRoot.querySelectorAll(MIRICANVAS_ASSET_TILE_SEL)).filter(
      (li) => !isInsideNeronaOverlay(li) && (scope === document || scope.contains(li))
    )
  );
}

function snapshotMiricanvasBatchImages(imgs) {
  const allTiles = getMiricanvasGridTilesInDomOrder();
  const rowToIndex = new Map(allTiles.map((li, idx) => [li, idx]));

  return (Array.isArray(imgs) ? imgs : []).map((imgEl) => {
    const row = findMiricanvasAssetRowForImage(imgEl);
    const thumb =
      row?.querySelector?.(`${MIRICANVAS_ASSET_THUMB_SEL}[src]`) ||
      row?.querySelector?.("img[src]") ||
      imgEl;
    const rawUrl = resolveBestImageUrlFromElement(thumb);
    const pinnedUrl = upgradeMiricanvasContributorImageUrl(rawUrl) || rawUrl;
    const fileName = readMiricanvasTileFileName(row) || String(imgEl?.alt || "").trim();
    const inlineData = trySnapshotMiricanvasInlineData(thumb);
    return {
      imgEl,
      row,
      pinnedUrl,
      rawUrl,
      inlineData,
      fileName,
      domIndex: row != null ? rowToIndex.get(row) ?? -1 : -1,
      urlKey: normalizeMiricanvasFileUrlKey(pinnedUrl || rawUrl)
    };
  });
}

function findMiricanvasTileImgByPinnedUrl(pinnedUrl) {
  const key = normalizeMiricanvasFileUrlKey(pinnedUrl);
  if (!key) return null;

  for (const li of getMiricanvasGridTilesInDomOrder()) {
    const img = li.querySelector?.(`${MIRICANVAS_ASSET_THUMB_SEL}[src]`) || li.querySelector?.("img[src]");
    if (!img) continue;
    const src = upgradeMiricanvasContributorImageUrl(resolveBestImageUrlFromElement(img));
    if (normalizeMiricanvasFileUrlKey(src) === key) return img;
  }
  return null;
}

/** Cari ulang tile grid setelah deselect — hindari row/imgEl stale dari React re-render. */
function findMiricanvasTileRowByJob(job) {
  if (!job) return null;

  const urlKey = job.urlKey || normalizeMiricanvasFileUrlKey(job.pinnedUrl || job.rawUrl);
  const fileName = String(job.fileName || "").trim().toLowerCase();
  const tiles = getMiricanvasGridTilesInDomOrder();

  if (urlKey) {
    for (const li of tiles) {
      const img = li.querySelector?.(`${MIRICANVAS_ASSET_THUMB_SEL}[src]`) || li.querySelector?.("img[src]");
      if (!img) continue;
      const src = upgradeMiricanvasContributorImageUrl(resolveBestImageUrlFromElement(img));
      if (normalizeMiricanvasFileUrlKey(src) === urlKey) return li;
    }
  }

  if (fileName) {
    for (const li of tiles) {
      const fn = readMiricanvasTileFileName(li).toLowerCase();
      if (fn && fn === fileName) return li;
    }
  }

  if (Number.isFinite(job.domIndex) && job.domIndex >= 0 && tiles[job.domIndex]) {
    return tiles[job.domIndex];
  }

  if (job.row?.isConnected) return job.row;
  return null;
}

function resolveMiricanvasBatchTarget(job) {
  if (!job) return { imgEl: null, row: null };
  const row = findMiricanvasTileRowByJob(job);
  const imgEl =
    row?.querySelector?.(`${MIRICANVAS_ASSET_THUMB_SEL}[src]`) ||
    row?.querySelector?.("img[src]") ||
    findMiricanvasTileImgByPinnedUrl(job.pinnedUrl) ||
    job.imgEl;
  return { imgEl, row: row || findMiricanvasAssetRowForImage(imgEl) || job.row };
}

function findMiricanvasElementNameField(scopeRoot = document) {
  const roots = [];
  if (scopeRoot?.nodeType === 1) roots.push(scopeRoot);
  if (scopeRoot !== document) roots.push(document);

  for (const root of roots) {
    const byDataF = root.querySelector(`textarea[data-f="${MIRICANVAS_ELEMENT_NAME_DATA_F}"]`);
    if (byDataF && isFormFieldVisible(byDataF) && !isInsideNeronaOverlay(byDataF)) {
      return byDataF;
    }
  }

  const root = scopeRoot?.nodeType === 1 ? scopeRoot : document;
  const labelNodes = root.querySelectorAll("label, span, p, div, h2, h3, h4, h5");

  for (const node of labelNodes) {
    const raw = String(node.textContent || "").replace(/\s+/g, " ").trim();
    if (!/\belement\s*name\b/i.test(raw)) continue;
    let scope = node.parentElement;
    for (let i = 0; i < 14 && scope; i += 1) {
      const fields = Array.from(scope.querySelectorAll("textarea, input[type='text'], input:not([type])")).filter(
        (el) =>
          isFormFieldVisible(el) &&
          !isInsideNeronaOverlay(el) &&
          !isLikelyNoiseMetadataField(el)
      );
      if (fields.length) return fields[0];
      scope = scope.parentElement;
    }
  }

  return (
    Array.from(root.querySelectorAll("textarea, input[type='text']")).find(
      (el) =>
        isFormFieldVisible(el) &&
        !isInsideNeronaOverlay(el) &&
        !isLikelyNoiseMetadataField(el) &&
        /multiple\s*names?/i.test(String(el.placeholder || ""))
    ) || null
  );
}

function findMiricanvasKeywordsTextarea(scopeRoot = document) {
  const roots = [];
  if (scopeRoot?.nodeType === 1) roots.push(scopeRoot);
  if (scopeRoot !== document) roots.push(document);

  const nameField = findMiricanvasElementNameField(document);

  for (const root of roots) {
    const textareas = Array.from(root.querySelectorAll("textarea")).filter(
      (el) =>
        isFormFieldVisible(el) &&
        !isInsideNeronaOverlay(el) &&
        el !== nameField
    );

    const byPlaceholder = textareas.find((el) =>
      /multiple\s*keywords?/i.test(String(el.placeholder || ""))
    );
    if (byPlaceholder) return byPlaceholder;

    for (const node of root.querySelectorAll("label, span, p, div, h2, h3, h4, h5")) {
      const raw = String(node.textContent || "").replace(/\s+/g, " ").trim();
      if (!/^keywords?\b/i.test(raw) && !/\bkeywords?\b/i.test(raw)) continue;
      let scope = node.parentElement;
      for (let i = 0; i < 14 && scope; i += 1) {
        const hit = Array.from(scope.querySelectorAll("textarea")).find(
          (el) =>
            isFormFieldVisible(el) &&
            !isInsideNeronaOverlay(el) &&
            el !== nameField
        );
        if (hit) return hit;
        scope = scope.parentElement;
      }
    }

    const byHint = textareas.find((el) =>
      /keyword|tag|태그|키워드/i.test(
        `${el.placeholder || ""} ${el.getAttribute("aria-label") || ""} ${el.name || ""}`
      )
    );
    if (byHint) return byHint;
  }

  return null;
}

function miricanvasHasCommaKeywordsTextarea(scopeRoot = document) {
  return Boolean(findMiricanvasKeywordsTextarea(scopeRoot));
}

function formatMiricanvasKeywordsComma(value) {
  const list = sanitizeKeywordListForMarketplace(value, "miricanvas", { max: MIRICANVAS_KEYWORD_MAX });
  return list.join(", ");
}

function fillMiricanvasTextareaField(el, text) {
  if (!(el instanceof HTMLElement) || !String(text || "").trim()) return false;
  const value = String(text).trim();

  try {
    el.focus?.();
  } catch (_e) {
    /* ignore */
  }

  if (el.isContentEditable) {
    el.textContent = value;
    dispatchTypingEvents(el);
    return true;
  }

  const ok = setNativeValue(el, value);
  if (!ok) return false;
  flushNativeFieldValueCommitted(el, false);
  dispatchTypingEvents(el);
  try {
    el.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        inputType: "insertText",
        data: value
      })
    );
  } catch (_e) {
    /* ignore */
  }
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function fillMiricanvasKeywordsCommaField(value, scopeRoot = document) {
  const text = formatMiricanvasKeywordsComma(value);
  if (!text) return false;
  const el = findMiricanvasKeywordsTextarea(scopeRoot);
  if (!el) return false;
  return fillMiricanvasTextareaField(el, text);
}

function commitMiricanvasFieldEnter(el) {
  if (!(el instanceof HTMLElement)) return;
  const enterEvent = {
    key: "Enter",
    code: "Enter",
    keyCode: 13,
    which: 13,
    bubbles: true,
    cancelable: true
  };
  el.dispatchEvent(new KeyboardEvent("keydown", enterEvent));
  el.dispatchEvent(new KeyboardEvent("keypress", enterEvent));
  el.dispatchEvent(new KeyboardEvent("keyup", enterEvent));
}

async function fillMiricanvasElementNameWithCommit(value, scopeRoot = document, options = {}) {
  const el = findMiricanvasElementNameField(scopeRoot);
  if (el) {
    fillMiricanvasTextareaField(el, "");
    await sleep(60);
  }

  const ok = fillMiricanvasElementName(value, scopeRoot);
  if (!ok) return false;

  if (el) {
    const bulkMultiLine = /multiple\s*(names?|elements?|items?)/i.test(String(el.placeholder || ""));
    if (bulkMultiLine && options.allowBulkEnter) {
      commitMiricanvasFieldEnter(el);
      await sleep(90);
    }
    try {
      el.blur?.();
    } catch (_e) {
      /* ignore */
    }
    await sleep(120);
  }
  return ok;
}

/** Miricanvas: isi chip IF-add5 (Enter per kata) atau textarea keyword (comma, bukan Enter per baris). */
async function fillMiricanvasKeywordsEnterPerWordAsync(value, scopeRoot = document, options = {}) {
  const keywords = expandMiricanvasKeywordsToChipList(value);
  if (!keywords.length) return false;

  if (options?.job || options?.gridRow) {
    await waitForMiricanvasPanelSynced(options.job, options.gridRow, options.syncTimeoutMs ?? 2800);
  }

  const scopedRoot = resolveMiricanvasKeywordScope(scopeRoot, options);

  if (findMiricanvasKeywordChipContainer(scopedRoot) || miricanvasHasChipKeywordUi(scopedRoot)) {
    await removeAllMiricanvasTagsAsync(scopedRoot, () => true);
    await focusMiricanvasKeywordChipInput(scopedRoot);
    return fillMiricanvasKeywordTagsAsync(value, { scopeRoot: scopedRoot });
  }

  const textarea = findMiricanvasKeywordsTextarea(scopedRoot);
  if (textarea) {
    // Enter di textarea "Multiple keywords" Miricanvas = baris gambar berikutnya, bukan keyword berikutnya.
    fillMiricanvasTextareaField(textarea, "");
    await sleep(80);
    const ok = fillMiricanvasKeywordsCommaField(value, scopedRoot);
    try {
      textarea.blur?.();
    } catch (_e) {
      /* ignore */
    }
    return ok;
  }

  await focusMiricanvasKeywordChipInput(scopedRoot);
  const chipInput = findMiricanvasKeywordTagInput(scopedRoot);
  if (chipInput) {
    await removeAllMiricanvasTagsAsync(scopedRoot, () => true);
    return fillMiricanvasKeywordTagsAsync(value, { scopeRoot: scopedRoot });
  }

  return fillMiricanvasKeywordsCommaField(value, scopedRoot);
}

function expandMiricanvasKeywordsToChipList(text) {
  return sanitizeKeywordListForMarketplace(text, "miricanvas", { max: MIRICANVAS_KEYWORD_MAX });
}

function commitMiricanvasKeywordToInput(input, keyword) {
  if (!(input instanceof HTMLElement)) return false;
  setVecteezyTagInputValue(input, keyword);
  const enterEvent = {
    key: "Enter",
    code: "Enter",
    keyCode: 13,
    which: 13,
    bubbles: true
  };
  input.dispatchEvent(new KeyboardEvent("keydown", enterEvent));
  input.dispatchEvent(new KeyboardEvent("keypress", enterEvent));
  input.dispatchEvent(new KeyboardEvent("keyup", enterEvent));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function fillMiricanvasKeywordTags(value, scopeRoot = document) {
  const keywords = expandMiricanvasKeywordsToChipList(value);
  if (!keywords.length) return false;

  const input = findMiricanvasKeywordTagInput(scopeRoot);
  if (!input) return false;

  let inserted = 0;
  for (const keyword of keywords) {
    if (getMiricanvasExistingTags(scopeRoot).size >= MIRICANVAS_KEYWORD_MAX) break;
    if (getMiricanvasExistingTags(scopeRoot).has(keyword.toLowerCase())) continue;
    commitMiricanvasKeywordToInput(input, keyword);
    inserted += 1;
  }
  return inserted > 0 || getMiricanvasExistingTags(scopeRoot).size > 0;
}

async function fillMiricanvasKeywordTagsAsync(value, options = {}) {
  const scopeRoot = options.scopeRoot ?? document;
  const keywords = expandMiricanvasKeywordsToChipList(value);
  if (!keywords.length) return false;

  const resolveInput = async () => {
    let el = findMiricanvasKeywordTagInput(scopeRoot);
    if (!el && scopeRoot !== document) {
      el = findMiricanvasKeywordTagInput(document);
    }
    if (!el) {
      await focusMiricanvasKeywordChipInput(scopeRoot);
      el = findMiricanvasKeywordTagInput(scopeRoot);
      if (!el && scopeRoot !== document) {
        el = findMiricanvasKeywordTagInput(document);
      }
    }
    return el;
  };

  if (!(await resolveInput())) return false;

  // Deteksi apakah input miricanvas pakai comma separator (bukan Enter).
  // input[data-f="II-b5a4"] memiliki placeholder "Separate multiple keywords using commas (,)".
  const probeInput = await resolveInput();
  const usesComma = /comma/i.test(String(probeInput?.placeholder || ""));

  let inserted = 0;
  for (const keyword of keywords) {
    if (getMiricanvasExistingTags(scopeRoot).size >= MIRICANVAS_KEYWORD_MAX) break;
    let input = await resolveInput();
    if (!input) break;
    if (getMiricanvasExistingTags(scopeRoot).has(keyword.toLowerCase())) continue;
    commitMiricanvasKeywordToInput(input, keyword);
    // Jika input comma-based, dispatch juga comma key untuk trigger chip creation
    if (usesComma) {
      const commaEvt = { key: ",", code: "Comma", keyCode: 188, which: 188, bubbles: true, cancelable: true };
      try { input.dispatchEvent(new KeyboardEvent("keydown", commaEvt)); } catch (_e) {}
      try { input.dispatchEvent(new KeyboardEvent("keypress", commaEvt)); } catch (_e) {}
      try { input.dispatchEvent(new KeyboardEvent("keyup", commaEvt)); } catch (_e) {}
    }
    await sleep(120);
    if (getMiricanvasExistingTags(scopeRoot).has(keyword.toLowerCase())) {
      inserted += 1;
    } else {
      // Fallback: jika Enter tidak buat chip, coba comma (atau sebaliknya)
      await focusMiricanvasKeywordChipInput(scopeRoot);
      input = await resolveInput();
      if (input) {
        commitMiricanvasKeywordToInput(input, keyword);
        if (!usesComma) {
          const commaEvt = { key: ",", code: "Comma", keyCode: 188, which: 188, bubbles: true, cancelable: true };
          try { input.dispatchEvent(new KeyboardEvent("keydown", commaEvt)); } catch (_e) {}
          try { input.dispatchEvent(new KeyboardEvent("keyup", commaEvt)); } catch (_e) {}
        }
        await sleep(120);
        if (getMiricanvasExistingTags(scopeRoot).has(keyword.toLowerCase())) {
          inserted += 1;
        }
      }
    }
  }

  return inserted > 0 || getMiricanvasExistingTags(scopeRoot).size > 0;
}

async function removeAllMiricanvasTagsAsync(scopeRoot, shouldContinue = () => true) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  let noProgressRounds = 0;
  for (let round = 0; round < 60 && shouldContinue(); round += 1) {
    const chips = getMiricanvasChipRows(root);
    if (!chips.length) break;
    const countBefore = chips.length;
    for (const chip of chips) {
      const svg = chip.querySelector("svg");
      const clickEl =
        chip.querySelector("button") ||
        (svg instanceof SVGElement ? svg : null) ||
        chip;
      try {
        clickEl.click?.();
      } catch (_e) {
        /* ignore */
      }
      await sleep(45);
    }
    // Jika chip count tidak berkurang setelah diklik, berhenti agar tidak infinite loop
    const countAfter = getMiricanvasChipRows(root).length;
    if (countAfter >= countBefore) {
      noProgressRounds += 1;
      if (noProgressRounds >= 3) break;
    } else {
      noProgressRounds = 0;
    }
  }
  return getMiricanvasExistingTags(root).size === 0;
}

function isMiricanvasContributorHost() {
  const h = location.hostname;
  return /\.miricanvas\.com$/i.test(h) || h === "miricanvas.com" || h.includes("designhub.miricanvas.com");
}

function isMiricanvasBulkMetadataPlaceholder(el) {
  if (!(el instanceof HTMLElement)) return false;
  if (el.matches?.(`textarea[data-f="${MIRICANVAS_ELEMENT_NAME_DATA_F}"]`)) return false;
  if (findMiricanvasKeywordsTextarea(document) === el) return false;
  const ph = String(el.placeholder || el.getAttribute("aria-label") || "").toLowerCase();
  const val = readFormFieldKeywords(el).toLowerCase();
  return /multiple\s*(names|keywords|tags|elements)/i.test(ph + " " + val);
}

function findMiricanvasMetadataPanelRoot() {
  const labels = document.querySelectorAll("label, span, p, div, h2, h3, h4, h5");
  for (const node of labels) {
    const raw = String(node.textContent || "").replace(/\s+/g, " ").trim();
    if (!/\belement\s*name\b/i.test(raw)) continue;
    const panel =
      node.closest("section") ||
      node.closest("form") ||
      node.closest('[class*="panel" i]') ||
      node.closest('[class*="sidebar" i]') ||
      node.closest('[class*="drawer" i]');
    if (panel && !isInsideNeronaOverlay(panel)) return panel;
  }
  return document;
}

function findMiricanvasAssetRowForImage(imgEl) {
  if (!imgEl) return null;
  return (
    imgEl.closest(MIRICANVAS_ASSET_TILE_SEL) ||
    imgEl.closest(MIRICANVAS_ASSET_CARD_SEL) ||
    imgEl.closest(
      '[role="row"], [role="gridcell"], [role="listitem"], li, article, tr, [class*="item" i], [class*="card" i], [class*="Card" i], [class*="thumb" i], [class*="Thumb" i], [data-testid*="asset" i]'
    ) ||
    imgEl.parentElement
  );
}

function findMiricanvasAssetCheckbox(row) {
  if (!row) return null;
  const cb = row.querySelector?.(MIRICANVAS_ASSET_CHECKBOX_SEL);
  if (cb && !isInsideNeronaOverlay(cb)) return cb;
  const generic = row.querySelector?.('input[type="checkbox"]');
  if (generic && !isInsideNeronaOverlay(generic)) return generic;
  return null;
}

function isMiricanvasAssetRowSelected(row) {
  const cb = findMiricanvasAssetCheckbox(row);
  if (cb instanceof HTMLInputElement && cb.checked) return true;
  return false;
}

/** React kadang tidak set .checked — cocokkan jumlah class wrapper CT-5090 dengan toolbar. */
function getMiricanvasSelectedTilesByThumbWrapperClass(root, expectedCount) {
  if (!expectedCount || expectedCount < 1) return [];
  const buckets = new Map();
  root.querySelectorAll(MIRICANVAS_ASSET_TILE_SEL).forEach((li) => {
    if (isInsideNeronaOverlay(li)) return;
    const wrap = li.querySelector(MIRICANVAS_ASSET_THUMB_WRAP_SEL);
    if (!wrap) return;
    const key = String(wrap.className || "").trim();
    if (!key) return;
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(li);
  });
  for (const tiles of buckets.values()) {
    if (tiles.length === expectedCount) return sortMiricanvasTilesDomOrder(tiles);
  }
  return [];
}

function sortMiricanvasTilesDomOrder(tiles) {
  return [...tiles].sort((a, b) => {
    const ra = a.getBoundingClientRect();
    const rb = b.getBoundingClientRect();
    if (Math.abs(ra.top - rb.top) > 10) return ra.top - rb.top;
    return ra.left - rb.left;
  });
}

function findMiricanvasSelectionControlForRow(row) {
  return findMiricanvasAssetCheckbox(row);
}

function findMiricanvasUploadGridRoot() {
  const tile = document.querySelector(MIRICANVAS_ASSET_TILE_SEL);
  if (tile && !isInsideNeronaOverlay(tile)) {
    return (
      tile.closest('[role="grid"], [role="list"], ul, ol, main, section') ||
      tile.parentElement ||
      document
    );
  }

  const counts = new Map();
  const imgs = Array.from(document.querySelectorAll("img[src]")).filter(
    (img) => !isInsideNeronaOverlay(img) && isElementVisible(img)
  );

  for (const img of imgs.slice(0, 60)) {
    const grid =
      img.closest(
        '[role="grid"], [role="list"], main, section, [class*="grid" i], [class*="upload" i], [class*="Upload" i]'
      ) || findMiricanvasAssetRowForImage(img)?.parentElement?.parentElement;
    if (grid && !isInsideNeronaOverlay(grid)) {
      counts.set(grid, (counts.get(grid) || 0) + 1);
    }
  }

  let best = document;
  let bestCount = 0;
  for (const [grid, count] of counts) {
    if (count > bestCount) {
      bestCount = count;
      best = grid;
    }
  }
  return best;
}

function readMiricanvasToolbarSelectedCount() {
  const nodes = document.querySelectorAll("button, a, span, div, p, label");
  for (const el of nodes) {
    if (isInsideNeronaOverlay(el)) continue;
    const t = String(el.textContent || el.getAttribute("aria-label") || "")
      .replace(/\s+/g, " ")
      .trim();
    const m =
      t.match(/^(\d+)\s*(?:\/\s*\d+\s*)?(?:selected|items?\s*selected|개\s*선택|선택됨)/i) ||
      t.match(/(\d+)\s*(?:items?|assets?|elements?)\s*selected/i);
    if (m) return parseInt(m[1], 10) || 0;
  }
  return 0;
}

function getMiricanvasSelectedImages() {
  const picked = [];
  const seen = new Set();

  for (const row of sortMiricanvasTilesDomOrder(Array.from(getMiricanvasSelectedAssetRows()))) {
    const img =
      row.querySelector?.(`${MIRICANVAS_ASSET_THUMB_SEL}[src]`) ||
      row.querySelector?.("img[src]");
    if (!img || isInsideNeronaOverlay(img) || !isElementVisible(img)) continue;
    const k = imgDomDedupeKey(img);
    if (!k || seen.has(k)) continue;
    seen.add(k);
    picked.push(img);
  }

  return picked;
}

function isMiricanvasSingleSelectionReady(imgEl) {
  if (readMiricanvasToolbarSelectedCount() > 1) return false;
  if (getMiricanvasSelectedAssetRows().size > 1) return false;
  if (readMiricanvasToolbarSelectedCount() === 1) return true;
  return isMiricanvasExclusiveSelectionForImage(imgEl) || getMiricanvasSelectedAssetRows().size <= 1;
}

function isMiricanvasBulkSelectionActive() {
  return readMiricanvasToolbarSelectedCount() > 1 || getMiricanvasSelectedAssetRows().size > 1;
}

function getMiricanvasSelectedAssetRows(gridRoot = null) {
  const scope = gridRoot && gridRoot.nodeType === 1 ? gridRoot : findMiricanvasUploadGridRoot();
  const root = scope === document ? document : scope;
  const rows = new Set();

  root.querySelectorAll(MIRICANVAS_ASSET_TILE_SEL).forEach((li) => {
    if (isInsideNeronaOverlay(li)) return;
    if (scope !== document && !scope.contains(li)) return;
    if (isMiricanvasAssetRowSelected(li)) rows.add(li);
  });

  if (!rows.size) {
    const toolbarN = readMiricanvasToolbarSelectedCount();
    if (toolbarN > 0) {
      for (const li of getMiricanvasSelectedTilesByThumbWrapperClass(root, toolbarN)) {
        if (scope !== document && !scope.contains(li)) continue;
        rows.add(li);
      }
    }
  }

  if (!rows.size) {
    root.querySelectorAll(`${MIRICANVAS_ASSET_CHECKBOX_SEL}:checked`).forEach((cb) => {
      const li = cb.closest(MIRICANVAS_ASSET_TILE_SEL);
      if (li && !isInsideNeronaOverlay(li)) rows.add(li);
    });
  }

  return rows;
}

function isMiricanvasExclusiveSelectionForImage(imgEl) {
  const rows = getMiricanvasSelectedAssetRows();
  if (rows.size !== 1) return false;
  const targetRow = findMiricanvasAssetRowForImage(imgEl);
  if (!targetRow) return true;
  return rows.has(targetRow);
}

async function clickMiricanvasClearSelectionButton() {
  if (!isMiricanvasContributorHost()) return false;

  const candidates = document.querySelectorAll("button, a, [role='button'], span[role='button']");
  for (const el of candidates) {
    if (isInsideNeronaOverlay(el)) continue;
    const t = String(el.textContent || el.getAttribute("aria-label") || "")
      .replace(/\s+/g, " ")
      .trim();
    if (
      /^(clear|cancel|deselect|unselect|reset)(\s|$)/i.test(t) ||
      /clear\s*selection|deselect\s*all/i.test(t) ||
      /선택\s*해제|전체\s*해제|선택\s*취소|전체\s*취소|취소\s*선택/i.test(t)
    ) {
      try {
        el.click();
        await sleep(220);
        return true;
      } catch (_e) {
        /* ignore */
      }
    }
  }
  return false;
}

async function deselectAllMiricanvasGridAssets() {
  if (!isMiricanvasContributorHost()) return;

  await clickMiricanvasClearSelectionButton();
  const grid = findMiricanvasUploadGridRoot();

  for (let round = 0; round < 5; round += 1) {
    const toggles = new Set();
    const root = grid === document ? document : grid;
    root.querySelectorAll(`${MIRICANVAS_ASSET_CHECKBOX_SEL}:checked`).forEach((cb) => {
      if (!isInsideNeronaOverlay(cb)) toggles.add(cb);
    });
    root.querySelectorAll(`${MIRICANVAS_ASSET_TILE_SEL}`).forEach((li) => {
      if (!isMiricanvasAssetRowSelected(li)) return;
      const cb = findMiricanvasAssetCheckbox(li);
      if (cb) toggles.add(cb);
    });

    for (const el of toggles) {
      try {
        el.click();
      } catch (_e) {
        /* ignore */
      }
    }

    // Pendekatan oracle: klik tiap checkbox CI-66e5 dan cek perubahan toolbar count
    // untuk mendeteksi mana yang sedang terpilih (React tidak sync .checked ke DOM attr)
    if (!toggles.size && readMiricanvasToolbarSelectedCount() > 0) {
      const allCbs = Array.from(root.querySelectorAll(MIRICANVAS_ASSET_CHECKBOX_SEL)).filter(
        (cb) => !isInsideNeronaOverlay(cb)
      );
      for (const cb of allCbs) {
        if (readMiricanvasToolbarSelectedCount() <= 0) break;
        const before = readMiricanvasToolbarSelectedCount();
        cb.click();
        await sleep(80);
        const after = readMiricanvasToolbarSelectedCount();
        if (after > before) {
          // Tidak sengaja memilih — batalkan
          cb.click();
          await sleep(80);
        }
      }
    }

    if (getMiricanvasSelectedAssetRows(grid).size === 0 && readMiricanvasToolbarSelectedCount() <= 0) break;
    if (!toggles.size && readMiricanvasToolbarSelectedCount() <= 0) break;
    await sleep(100);
  }

  try {
    document.activeElement?.blur?.();
    const esc = { key: "Escape", code: "Escape", bubbles: true, cancelable: true };
    document.dispatchEvent(new KeyboardEvent("keydown", esc));
    document.dispatchEvent(new KeyboardEvent("keyup", esc));
  } catch (_e) {
    /* ignore */
  }

  await sleep(180);
}

async function waitForMiricanvasSingleAssetSelection(imgEl, timeoutMs = 4500) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (isMiricanvasSingleSelectionReady(imgEl)) {
      return true;
    }
    await sleep(140);
  }
  return isMiricanvasSingleSelectionReady(imgEl);
}

/** Lepas seleksi setelah isi form agar gambar berikutnya tidak bulk ke semua item terpilih. */
async function releaseMiricanvasSelectionAfterFill() {
  await commitMiricanvasMetadataPanel();
  await deselectAllMiricanvasGridAssets();
  await sleep(180);
}

/** Pilih hanya satu aset — hindari mode bulk ("Multiple names" untuk semua terpilih). */
async function selectExclusiveMiricanvasAsset(imgEl) {
  if (!imgEl || !isMiricanvasContributorHost()) return false;

  try {
    imgEl.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "instant" });
  } catch (_e) {
    try {
      imgEl.scrollIntoView({ block: "nearest", inline: "nearest" });
    } catch (_e2) {
      /* ignore */
    }
  }

  for (let attempt = 0; attempt < 5; attempt += 1) {
    await deselectAllMiricanvasGridAssets();
    await sleep(220 + attempt * 80);

    // Langsung klik checkbox — JANGAN klik elemen img karena bisa trigger
    // navigasi ke design editor dan keluar dari halaman upload.
    const row = findMiricanvasAssetRowForImage(imgEl);
    const control = findMiricanvasSelectionControlForRow(row);

    // React tidak sync .checked ke DOM attribute — klik tanpa cek kondisi
    if (control instanceof HTMLElement) {
      control.click();
    } else {
      dispatchPlainClick(row || imgEl);
    }

    await sleep(400 + attempt * 80);

    if (isMiricanvasSingleSelectionReady(imgEl)) {
      return true;
    }
  }

  return isMiricanvasSingleSelectionReady(imgEl);
}

async function commitMiricanvasMetadataPanel() {
  for (const el of [
    findMiricanvasElementNameField(),
    findMiricanvasKeywordsTextarea(),
    findMiricanvasKeywordTagInput()
  ]) {
    if (!el) continue;
    try {
      el.blur?.();
    } catch (_e) {
      /* ignore */
    }
  }
  await sleep(120);
}

function fillMiricanvasElementName(value, scopeRoot = document) {
  const text = String(value || "").trim().slice(0, MIRICANVAS_ELEMENT_NAME_MAX_CHARS);
  if (!text) return false;
  const el = findMiricanvasElementNameField(scopeRoot);
  if (!el) return false;
  return fillMiricanvasTextareaField(el, text);
}

/** Tunggu hingga panel single-aset miricanvas muncul (textarea[data-f="DT-9450"] visible).
 *  Mengembalikan false jika textarea masih menampilkan "Multiple names" (mode bulk-edit). */
async function waitForMiricanvasSingleAssetPanel(timeoutMs = 3000) {
  const isSingleMode = () => {
    const f = document.querySelector(`textarea[data-f="${MIRICANVAS_ELEMENT_NAME_DATA_F}"]`);
    if (!f || !isFormFieldVisible(f) || isInsideNeronaOverlay(f)) return false;
    // Bulk-edit mode: placeholder berubah jadi "Multiple names" — tolak kondisi ini
    if (/multiple\s*(names?|elements?|items?)/i.test(f.placeholder || "")) return false;
    return true;
  };
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (isSingleMode()) return true;
    await sleep(150);
  }
  return isSingleMode();
}

/** Tunggu hingga input keyword chip miricanvas tersedia di panel. */
async function waitForMiricanvasKeywordInputReady(scopeRoot = document, timeoutMs = 2000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (findMiricanvasKeywordChipContainer(scopeRoot) || miricanvasHasChipKeywordUi(scopeRoot)) return true;
    if (findMiricanvasKeywordsTextarea(scopeRoot)) return true;
    await sleep(150);
  }
  return false;
}

/** Panel upload Miricanvas: pilih 1 aset → isi → commit → lepas seleksi. */
async function applyMiricanvasMetadataToSingleAsset(imgEl, metadata) {
  if (!metadata) {
    return { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false };
  }

  await clickMiricanvasClearSelectionButton();
  const exclusiveOk = await selectExclusiveMiricanvasAsset(imgEl);
  const singleReady = await waitForMiricanvasSingleAssetSelection(imgEl);
  if (!singleReady) {
    await sleep(400);
  }

  // Verifikasi panel single-aset sudah muncul — mode bulk-edit menulis value yang sama
  // ke SEMUA gambar terpilih sekaligus (title sama + keyword chip tidak tersedia).
  const panelReady = await waitForMiricanvasSingleAssetPanel(2500);
  if (!panelReady) {
    return { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false, exclusiveSelection: false };
  }

  const norm = normalizeMetadataForMarketplace(metadata, "miricanvas");
  const mcRow = findMiricanvasAssetRowForImage(imgEl);
  const mcJob = {
    row: mcRow,
    pinnedUrl: pickMiricanvasThumbnailResourceUrl(imgEl),
    urlKey: readMiricanvasGridRowImageKey(mcRow),
    fileName: readMiricanvasTileFileName(mcRow),
    domIndex: getMiricanvasGridTilesInDomOrder().indexOf(mcRow)
  };

  await waitForMiricanvasPanelSynced(mcJob, mcRow, 2500);
  const fileNameDone = await fillMiricanvasElementNameWithCommit(norm.fileName, document);
  await sleep(160);

  await waitForMiricanvasKeywordInputReady(document, 2000);
  await waitForMiricanvasPanelSynced(mcJob, mcRow, 2000);

  const keywordDone = await fillMiricanvasKeywordsEnterPerWordAsync(norm.keywords, document, {
    gridRow: mcRow,
    job: mcJob
  });

  await releaseMiricanvasSelectionAfterFill();

  const exclusiveSelection = exclusiveOk || isMiricanvasSingleSelectionReady(imgEl);

  return {
    ok: fileNameDone || keywordDone,
    fileNameDone,
    descriptionDone: false,
    keywordDone,
    exclusiveSelection
  };
}

async function applyMiricanvasTagsAfterMetadata(metadata, scopeEl, options = {}) {
  const norm = normalizeMetadataForMarketplace(metadata, "miricanvas");
  const scope = resolveMiricanvasKeywordScope(scopeEl || document, options);

  if (miricanvasHasCommaKeywordsTextarea(scope) && !miricanvasHasChipKeywordUi(scope)) {
    return fillMiricanvasKeywordsEnterPerWordAsync(norm.keywords, scope, options);
  }

  const normalized = splitKeywords(norm.keywords, MIRICANVAS_KEYWORD_MAX, "miricanvas");
  const tagInput = findMiricanvasKeywordTagInput(scope);
  if (tagInput instanceof HTMLElement) {
    if (!tagInput.isContentEditable) {
      setNativeValue(tagInput, "");
      flushNativeFieldValueCommitted(tagInput);
    } else {
      tagInput.textContent = "";
    }
    dispatchTypingEvents(tagInput);
  }
  return fillMiricanvasKeywordTagsAsync(normalized, { scopeRoot: scope });
}

/** Panel keyword Adobe biasanya satu untuk seluruh halaman (bukan per baris grid). */
function findAdobeKeywordsField(scopeEl) {
  const sels = marketplaceSelectors?.adobe?.keywords;
  if (!sels?.length) return null;

  const global = firstMetadataField(sels, document);
  if (global) return global;

  if (scopeEl) {
    const scoped = firstMatchInScope(scopeEl, sels);
    if (scoped) return scoped;
  }

  const probes = Array.from(document.querySelectorAll("textarea, input[type='text']")).filter(
    (el) =>
      !isInsideNeronaOverlay(el) &&
      isFormFieldVisible(el) &&
      !isLikelyNoiseMetadataField(el)
  );
  return (
    probes.find((el) =>
      /(keyword|key word|tag|comma|separate|paste|;|태그|키워드|키\s*워드)/.test(hintOf(el))
    ) || null
  );
}

/** Kosongkan textarea keyword Adobe — hindari merge dengan aset sebelumnya. */
function clearAdobeKeywordsField(el) {
  if (!(el instanceof HTMLElement)) return false;

  const wipeDom = () => {
    try {
      el.focus?.();
    } catch (_e) {
      /* ignore */
    }

    if (el.isContentEditable) {
      el.textContent = "";
    } else if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      try {
        el.select();
        el.setSelectionRange(0, el.value.length);
      } catch (_e) {
        /* ignore */
      }
      setNativeValue(el, "");
      flushNativeFieldValueCommitted(el, true);
    } else {
      setNativeValue(el, "");
      flushNativeFieldValueCommitted(el, true);
    }

    try {
      el.dispatchEvent(
        new KeyboardEvent("keydown", { key: "a", code: "KeyA", ctrlKey: true, bubbles: true })
      );
      el.dispatchEvent(
        new KeyboardEvent("keydown", { key: "Backspace", code: "Backspace", bubbles: true })
      );
      el.dispatchEvent(
        new KeyboardEvent("keyup", { key: "Backspace", code: "Backspace", bubbles: true })
      );
    } catch (_e) {
      /* ignore */
    }

    dispatchTypingEvents(el);
    try {
      el.blur?.();
    } catch (_e) {
      /* ignore */
    }
  };

  wipeDom();
  if (readFormFieldKeywords(el).trim()) {
    wipeDom();
  }
  return !readFormFieldKeywords(el).trim();
}

function adobePageUsesUploadTileGrid() {
  return !!document.querySelector(".upload-tile img.upload-tile__thumbnail[src], .upload-tile__thumbnail[src]");
}

/** Satu aset upload = .content-grid-elements (tile + statusbar sibling). */
function findAdobeUploadGridCellForImage(imgEl) {
  if (!imgEl) return null;
  return (
    imgEl.closest(".content-grid-elements") ||
    imgEl.closest(".upload-tile")?.closest(".content-grid-elements") ||
    null
  );
}

function findAdobeUploadTileForImage(imgEl) {
  const grid = findAdobeUploadGridCellForImage(imgEl);
  if (grid) return grid.querySelector(".upload-tile") || grid;
  return (
    imgEl.closest(".upload-tile") ||
    imgEl.closest('[role="option"][title="Content tile"]')?.closest(".upload-tile")
  );
}

/**
 * Terpilih di grid upload Adobe = role="option" dengan aria-selected="true".
 * icon-radio-active di statusbar ada di SEMUA tile (bukan indikator centang user).
 */
function findAdobeUploadContentTileOption(gridCell) {
  if (!gridCell) return null;
  return (
    gridCell.querySelector?.('[role="option"][title="Content tile"]') ||
    gridCell.querySelector?.(".upload-tile [role=\"option\"]") ||
    gridCell.querySelector?.('[role="option"]')
  );
}

function isAdobeUploadGridCellSelected(gridCell) {
  if (!gridCell) return false;
  const opt = findAdobeUploadContentTileOption(gridCell);
  if (!opt) return false;
  return String(opt.getAttribute("aria-selected") || "").toLowerCase() === "true";
}

function isAdobeUploadTileMarkedSelected(tile) {
  const grid = tile?.closest?.(".content-grid-elements") || findAdobeUploadGridCellForImage(tile);
  return isAdobeUploadGridCellSelected(grid);
}

function findAdobeUploadTileToggleControl(tile) {
  const grid = tile?.closest?.(".content-grid-elements") || findAdobeUploadGridCellForImage(tile);
  const opt =
    findAdobeUploadContentTileOption(grid) ||
    tile?.querySelector?.('[role="option"][title="Content tile"], [role="option"]');
  if (opt && !isInsideNeronaOverlay(opt)) return opt;
  const wrapper = tile?.querySelector?.(".upload-tile__wrapper");
  if (wrapper && !isInsideNeronaOverlay(wrapper)) return wrapper;
  return tile || null;
}

function findAdobeAssetRowForImage(imgEl) {
  if (!imgEl) return null;
  const uploadTile = findAdobeUploadTileForImage(imgEl);
  if (uploadTile) return uploadTile;
  return (
    imgEl.closest(
      '[role="row"], [role="gridcell"], [role="listitem"], tr, li, article, [data-testid*="asset" i], [class*="asset" i], [class*="Asset" i], [class*="thumbnail" i], [class*="Thumbnail" i], [class*="card" i], [class*="Card" i]'
    ) || imgEl.parentElement
  );
}

function findAdobeSelectionControlForRow(row) {
  if (!row) return null;
  if (
    row.matches?.(".upload-tile, .content-grid-elements") ||
    row.querySelector?.(".upload-tile, .upload-statusbar")
  ) {
    const tile = row.matches?.(".upload-tile")
      ? row
      : row.querySelector?.(".upload-tile") || findAdobeUploadTileForImage(row.querySelector?.("img"));
    const toggle = findAdobeUploadTileToggleControl(tile || row);
    if (toggle && !isInsideNeronaOverlay(toggle)) return toggle;
  }
  const cb = row.querySelector('input[type="checkbox"]');
  if (cb && !isInsideNeronaOverlay(cb)) return cb;
  const ariaCb = row.querySelector('[role="checkbox"]');
  if (ariaCb && !isInsideNeronaOverlay(ariaCb)) return ariaCb;
  return null;
}

function dispatchPlainClick(target) {
  if (!(target instanceof HTMLElement)) return;
  const opts = { bubbles: true, cancelable: true, view: window, ctrlKey: false, metaKey: false, shiftKey: false, altKey: false };
  try {
    target.dispatchEvent(new MouseEvent("mousedown", opts));
    target.dispatchEvent(new MouseEvent("mouseup", opts));
    target.dispatchEvent(new MouseEvent("click", opts));
    if (typeof target.click === "function") target.click();
  } catch (_e) {
    /* ignore */
  }
}

/** Batal pilih semua aset — bulk-edit Adobe menulis keyword yang sama ke semua terpilih. */
async function deselectAllAdobeGridAssets() {
  if (!isAdobeContributorHost()) return;

  const toggles = new Set();
  document.querySelectorAll('input[type="checkbox"]:checked').forEach((cb) => {
    if (!isInsideNeronaOverlay(cb)) toggles.add(cb);
  });
  document.querySelectorAll('[role="checkbox"][aria-checked="true"]').forEach((el) => {
    if (!isInsideNeronaOverlay(el)) toggles.add(el);
  });
  document
    .querySelectorAll('.content-grid-elements [role="option"][aria-selected="true"]')
    .forEach((opt) => {
      if (!isInsideNeronaOverlay(opt)) toggles.add(opt);
    });
  document.querySelectorAll(".content-grid-elements").forEach((grid) => {
    if (isInsideNeronaOverlay(grid) || !isAdobeUploadGridCellSelected(grid)) return;
    const toggle = findAdobeUploadTileToggleControl(grid.querySelector(".upload-tile") || grid);
    if (toggle) toggles.add(toggle);
  });

  for (const el of toggles) {
    try {
      el.click();
    } catch (_e) {
      /* ignore */
    }
  }

  try {
    document.activeElement?.blur?.();
    const esc = { key: "Escape", code: "Escape", bubbles: true, cancelable: true };
    document.dispatchEvent(new KeyboardEvent("keydown", esc));
    document.dispatchEvent(new KeyboardEvent("keyup", esc));
  } catch (_e) {
    /* ignore */
  }

  await sleep(160);
}

function countAdobeSelectedUploadCells() {
  let count = 0;
  document.querySelectorAll(".content-grid-elements").forEach((grid) => {
    if (!isInsideNeronaOverlay(grid) && isAdobeUploadGridCellSelected(grid)) {
      count += 1;
    }
  });
  return count;
}

function isAdobeExclusiveSelectionForImage(imgEl) {
  if (countAdobeSelectedUploadCells() !== 1) return false;
  return isAdobeUploadGridCellSelected(findAdobeUploadGridCellForImage(imgEl));
}

async function waitForAdobeSingleAssetSelection(imgEl, timeoutMs = 4000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (isAdobeExclusiveSelectionForImage(imgEl)) return true;
    await sleep(120);
  }
  return isAdobeExclusiveSelectionForImage(imgEl);
}

/** Urutan grid (atas→bawah, kiri→kanan) — sama dengan urutan centang user. */
function sortAdobeCheckedImagesDomOrder(imgs) {
  const unique = [];
  const seen = new Set();
  for (const img of imgs) {
    const key = imgDomDedupeKey(img);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    unique.push(img);
  }
  return unique.sort((a, b) => {
    const ra = a.getBoundingClientRect();
    const rb = b.getBoundingClientRect();
    if (Math.abs(ra.top - rb.top) > 10) return ra.top - rb.top;
    return ra.left - rb.left;
  });
}

/** Hanya satu aset terpilih agar panel metadata + keyword mengikat ke gambar ini saja. */
async function selectExclusiveAdobeAsset(imgEl) {
  if (!imgEl || !isAdobeContributorHost()) return false;

  try {
    imgEl.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "instant" });
  } catch (_e) {
    try {
      imgEl.scrollIntoView({ block: "nearest", inline: "nearest" });
    } catch (_e2) {
      /* ignore */
    }
  }

  for (let attempt = 0; attempt < 5; attempt += 1) {
    await deselectAllAdobeGridAssets();
    await sleep(180 + attempt * 60);

    const row = findAdobeAssetRowForImage(imgEl);
    const control = findAdobeSelectionControlForRow(row);
    const tile = findAdobeUploadTileForImage(imgEl);

    const grid = findAdobeUploadGridCellForImage(imgEl);
    const opt = findAdobeUploadContentTileOption(grid);

    if (opt instanceof HTMLElement) {
      if (String(opt.getAttribute("aria-selected") || "").toLowerCase() !== "true") {
        opt.click();
      }
    } else if (control instanceof HTMLInputElement && control.type === "checkbox") {
      if (!control.checked) control.click();
    } else if (control instanceof HTMLElement) {
      control.click();
    } else if (tile instanceof HTMLElement) {
      const toggle = findAdobeUploadTileToggleControl(tile);
      if (toggle instanceof HTMLElement) toggle.click();
      else dispatchPlainClick(tile);
    } else {
      dispatchPlainClick(imgEl);
    }

    await sleep(260 + attempt * 80);

    if (isAdobeExclusiveSelectionForImage(imgEl)) {
      return true;
    }

    if (tile && !isAdobeUploadTileMarkedSelected(tile)) {
      dispatchPlainClick(imgEl);
      await sleep(200);
    }
  }

  return isAdobeExclusiveSelectionForImage(imgEl);
}

async function commitAdobeMetadataPanel() {
  const sels = marketplaceSelectors?.adobe;
  if (!sels) return;
  for (const group of [sels.keywords, sels.title, sels.description]) {
    const el = firstMetadataField(group, document);
    if (el) {
      try {
        el.blur?.();
      } catch (_e) {
        /* ignore */
      }
    }
  }
  await sleep(120);
}

/** Panel bulk Adobe: pilih 1 aset → isi metadata → commit sebelum gambar berikutnya. */
async function applyAdobeMetadataToSingleAsset(imgEl, metadata) {
  if (!metadata) return { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false };

  if (!isAdobeExclusiveSelectionForImage(imgEl)) {
    await selectExclusiveAdobeAsset(imgEl);
    await waitForAdobeSingleAssetSelection(imgEl);
  }

  const kwEl = findAdobeKeywordsField();
  if (kwEl) clearAdobeKeywordsField(kwEl);
  await sleep(80);

  const result = applyGeneric(marketplaceSelectors.adobe, metadata, "adobe");
  await commitAdobeMetadataPanel();
  return result;
}

async function prepareAdobeKeywordsForApply(imgEl) {
  await selectExclusiveAdobeAsset(imgEl);
  const kwEl = findAdobeKeywordsField();
  if (kwEl) clearAdobeKeywordsField(kwEl);
  await sleep(80);
  return kwEl;
}

function fillAdobeKeywordsField(el, value) {
  if (!(el instanceof HTMLElement) || !value) return false;
  const text = formatKeywordsForStockInput(value, "adobe");
  if (!text) return false;

  clearAdobeKeywordsField(el);
  if (readFormFieldKeywords(el).trim()) {
    clearAdobeKeywordsField(el);
  }

  try {
    el.focus?.();
  } catch (_e) {
    /* ignore */
  }

  if (el.isContentEditable) {
    el.textContent = text;
  } else {
    setNativeValue(el, text);
  }

  dispatchTypingEvents(el);
  try {
    el.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        inputType: "insertText",
        data: text
      })
    );
  } catch (_e) {
    /* ignore */
  }
  el.dispatchEvent(new Event("change", { bubbles: true }));
  try {
    el.blur?.();
  } catch (_e) {
    /* ignore */
  }
  return true;
}

function fillKeywordsField(value, selectors, marketplace, options = {}) {
  if (!value) return false;
  const replace = options.replace !== false;
  const el =
    marketplace === "adobe"
      ? findAdobeKeywordsField() || firstMetadataField(selectors) || firstMatch(selectors)
      : firstMetadataField(selectors) || firstMatch(selectors);
  if (!el) return false;

  const text = formatKeywordsForStockInput(value, marketplace);
  if (!text) return false;

  const existing = readFormFieldKeywords(el);
  const merged =
    !replace && existing.trim().length
      ? mergeExistingKeywords(existing, text, { max: 50 })
      : text;

  if (marketplace === "adobe") {
    return fillAdobeKeywordsField(el, merged);
  }

  if (el.isContentEditable) {
    el.textContent = merged;
    dispatchTypingEvents(el);
    return true;
  }

  const setOk = setNativeValue(el, merged);
  if (setOk) {
    dispatchTypingEvents(el);
  }

  if (marketplace === "vecteezy") {
    // Beberapa form Vecteezy membaca nilai lewat event paste/typing.
    try {
      const pasteEvent = new Event("paste", { bubbles: true, cancelable: true });
      el.dispatchEvent(pasteEvent);
    } catch (_error) {
      // no-op
    }
  }

  return setOk;
}

function fillCategory(categoryValue) {
  const categorySelect = firstMatch([
    'select[name*="category"]',
    'select[id*="category"]',
    '[data-testid*="category"] select'
  ]);

  if (!categorySelect || !categoryValue) return false;

  const options = Array.from(categorySelect.options || []);
  const exact = options.find(
    (opt) => opt.textContent?.trim().toLowerCase() === categoryValue.toLowerCase()
  );
  const contains = options.find((opt) =>
    opt.textContent?.trim().toLowerCase().includes(categoryValue.toLowerCase())
  );
  const picked = exact || contains;

  if (!picked) return false;

  categorySelect.value = picked.value;
  categorySelect.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function applyGeneric(selectors, metadata, marketplace) {
  const norm = normalizeMetadataForMarketplace(metadata, marketplace);
  const { fileName, description, keywords, category } = norm;
  const fileNameDone =
    marketplace === "miricanvas"
      ? fillMiricanvasElementName(fileName)
      : fillTextField(fileName, selectors.title);
  const descriptionDone = fillTextField(description, selectors.description);
  const normalizedKeywords =
    marketplace === "vecteezy"
      ? scrubVecteezyKeywordComma(keywords)
      : splitKeywords(keywords, getMarketplaceKeywordMax(marketplace), marketplace);
  let keywordDone = false;
  if (marketplace === "vecteezy") {
    if (vecteezyHasChipKeywordUi()) {
      keywordDone = fillVecteezyKeywordTags(normalizedKeywords);
    } else {
      keywordDone = fillKeywordsField(
        normalizedKeywords,
        selectors.keywords,
        marketplace
      );
    }
  } else if (marketplace === "miricanvas") {
    if (miricanvasHasChipKeywordUi()) {
      keywordDone = fillMiricanvasKeywordTags(normalizedKeywords);
    } else if (miricanvasHasCommaKeywordsTextarea()) {
      keywordDone = fillMiricanvasKeywordsCommaField(normalizedKeywords);
    } else {
      keywordDone = fillKeywordsField(normalizedKeywords, selectors.keywords, marketplace, {
        replace: true
      });
    }
  } else if (marketplace === "magnific") {
    if (magnificHasChipKeywordUi()) {
      keywordDone = fillMagnificKeywordTags(normalizedKeywords);
    } else {
      keywordDone = fillKeywordsField(normalizedKeywords, selectors.keywords, marketplace, {
        replace: true
      });
    }
  } else if (marketplace === "shutterstock") {
    if (shutterstockHasChipKeywordUi()) {
      keywordDone = fillShutterstockKeywordTags(normalizedKeywords);
    } else {
      keywordDone = fillKeywordsField(normalizedKeywords, selectors.keywords, marketplace, {
        replace: true
      });
    }
  } else {
    keywordDone = fillKeywordsField(normalizedKeywords, selectors.keywords, marketplace, {
      replace: true
    });
  }
  if (!keywordDone && marketplace === "vecteezy") {
    const hardTarget = firstMatch([
      'textarea[placeholder*="comma separated" i]',
      'textarea[placeholder*="min 5" i]',
      'input[placeholder*="comma separated" i]',
      'input[placeholder*="min 5" i]'
    ]);
    if (hardTarget) {
      keywordDone = setNativeValue(hardTarget, normalizedKeywords);
      if (keywordDone) {
        dispatchTypingEvents(hardTarget);
      }
    }
  }
  const categoryDone = fillCategory(category);

  /** Adobe / Magnific / Shutterstock: beberapa form tidak tertangkap selector — probing hint aksesibilitas. */
  let fileNameApplied = fileNameDone;
  let keywordApplied = keywordDone;
  if (marketplaceUsesDomFieldProbe(marketplace) && normalizedKeywords) {
    if (
      !keywordApplied &&
      !(marketplace === "magnific" && magnificHasChipKeywordUi()) &&
      !(marketplace === "vecteezy" && vecteezyHasChipKeywordUi()) &&
      !(marketplace === "shutterstock" && shutterstockHasChipKeywordUi())
    ) {
      const probes = Array.from(document.querySelectorAll("textarea, input[type='text']")).filter(
        (el) => !isInsideNeronaOverlay(el) && isFormFieldVisible(el)
      );
      const hintOf = (el) =>
        `${el.name || ""} ${el.id || ""} ${el.placeholder || ""} ${el.getAttribute("aria-label") || ""}`.toLowerCase();
      const kwEl =
        marketplace === "adobe"
          ? findAdobeKeywordsField()
          : probes.find(
              (el) =>
                !isLikelyNoiseMetadataField(el) &&
                /(keyword|key word|tag|comma|separate|paste|;|태그|키워드|키\s*워드)/.test(hintOf(el))
            );
      if (kwEl) {
        if (marketplace === "adobe") {
          clearAdobeKeywordsField(kwEl);
          keywordApplied = fillAdobeKeywordsField(kwEl, normalizedKeywords);
        } else if (kwEl.isContentEditable) {
          kwEl.textContent = normalizedKeywords;
          dispatchTypingEvents(kwEl);
          keywordApplied = true;
        } else {
          keywordApplied = setNativeValue(kwEl, normalizedKeywords);
          if (keywordApplied) dispatchTypingEvents(kwEl);
        }
      }
    }
    if (!fileNameApplied && fileName) {
      const probes = Array.from(document.querySelectorAll('input[type="text"], input:not([type]), textarea')).filter(
        (el) => !isInsideNeronaOverlay(el) && isFormFieldVisible(el)
      );
      const hintOf = (el) =>
        `${el.name || ""} ${el.id || ""} ${el.placeholder || ""} ${el.getAttribute("aria-label") || ""}`.toLowerCase();
      const titleEl = probes.find((el) =>
        /(^title|^filename|^name\b|judul|제목|타이틀)/.test(hintOf(el))
      );
      if (titleEl && !titleEl.isContentEditable) {
        fileNameApplied = setNativeValue(titleEl, fileName);
        if (fileNameApplied) dispatchTypingEvents(titleEl);
      }
    }
  }

  return {
    ok: descriptionDone || keywordApplied || categoryDone || fileNameApplied,
    fileNameDone: fileNameApplied,
    descriptionDone,
    keywordDone: keywordApplied,
    categoryDone
  };
}

function clearKeywordsFieldFirstMatch(selectors, marketplace) {
  if (marketplace === "adobe") {
    const el = findAdobeKeywordsField() || firstMetadataField(selectors) || firstMatch(selectors);
    return el ? clearAdobeKeywordsField(el) : false;
  }
  const el = firstMetadataField(selectors) || firstMatch(selectors);
  if (!el || isLikelyNoiseMetadataField(el)) return false;
  if (el.isContentEditable) {
    el.textContent = "";
    dispatchTypingEvents(el);
    return true;
  }
  const ok = setNativeValue(el, "");
  if (ok) {
    flushNativeFieldValueCommitted(el);
    dispatchTypingEvents(el);
  }
  return ok;
}

/** Kosongkan title, deskripsi, keyword di form global + fallback seperti applyGeneric. */
function clearGenericMetadata(selectors, marketplace) {
  const fileNameDone = clearTextField(selectors.title);
  let descriptionDone = clearTextField(selectors.description);
  let keywordDone = clearKeywordsFieldFirstMatch(selectors.keywords, marketplace);

  if (!keywordDone && marketplace === "vecteezy") {
    const hardTarget = firstMatch([
      'textarea[placeholder*="comma separated" i]',
      'textarea[placeholder*="min 5" i]',
      'input[placeholder*="comma separated" i]',
      'input[placeholder*="min 5" i]'
    ]);
    if (hardTarget) {
      keywordDone = setNativeValue(hardTarget, "");
      if (keywordDone) dispatchTypingEvents(hardTarget);
    }
  }

  let keywordApplied = keywordDone;
  let fileNameApplied = fileNameDone;
  if (marketplaceUsesDomFieldProbe(marketplace)) {
    if (!keywordApplied) {
      const probes = Array.from(document.querySelectorAll("textarea, input[type='text']")).filter(
        (el) =>
          !isInsideNeronaOverlay(el) &&
          isFormFieldVisible(el) &&
          !isLikelyNoiseMetadataField(el)
      );
      const kwEl =
        marketplace === "adobe"
          ? findAdobeKeywordsField()
          : probes.find((el) => /(keyword|key word|tag|comma|separate|;|태그|키워드|키\s*워드)/.test(hintOf(el)));
      if (kwEl) {
        if (marketplace === "adobe") {
          keywordApplied = clearAdobeKeywordsField(kwEl);
        } else if (kwEl.isContentEditable) {
          kwEl.textContent = "";
          dispatchTypingEvents(kwEl);
          keywordApplied = true;
        } else if (setNativeValue(kwEl, "")) {
          flushNativeFieldValueCommitted(kwEl);
          dispatchTypingEvents(kwEl);
          keywordApplied = true;
        }
      }
    }
    let descriptionApplied = descriptionDone;
    if (!descriptionApplied) {
      const probesD = Array.from(document.querySelectorAll("textarea")).filter(
        (el) =>
          !isInsideNeronaOverlay(el) &&
          isFormFieldVisible(el) &&
          !isLikelyNoiseMetadataField(el)
      );
      const descElProbe = probesD.find((el) =>
        /(description|deskripsi|caption|tell buyers|tell us)/.test(hintOf(el))
      );
      if (descElProbe) {
        if (descElProbe.isContentEditable) {
          descElProbe.textContent = "";
          dispatchTypingEvents(descElProbe);
          descriptionApplied = true;
        } else if (setNativeValue(descElProbe, "")) {
          flushNativeFieldValueCommitted(descElProbe);
          dispatchTypingEvents(descElProbe);
          descriptionApplied = true;
        }
      }
    }

    if (!fileNameApplied) {
      const probes = Array.from(document.querySelectorAll('input[type="text"], input:not([type]), textarea')).filter(
        (el) =>
          !isInsideNeronaOverlay(el) &&
          isFormFieldVisible(el) &&
          !isLikelyNoiseMetadataField(el)
      );
      const titleElProbe = probes.find((el) => /(^title|^filename|^name\b|judul|제목|타이틀)/.test(hintOf(el)));
      if (titleElProbe) {
        if (titleElProbe.isContentEditable) {
          titleElProbe.textContent = "";
          dispatchTypingEvents(titleElProbe);
          fileNameApplied = true;
        } else if (setNativeValue(titleElProbe, "")) {
          flushNativeFieldValueCommitted(titleElProbe);
          dispatchTypingEvents(titleElProbe);
          fileNameApplied = true;
        }
      }
    }
    descriptionDone = descriptionApplied;
  }

  return {
    ok: fileNameApplied || descriptionDone || keywordApplied,
    fileNameDone: fileNameApplied,
    descriptionDone,
    keywordDone: keywordApplied
  };
}

/** Hapus chip keyword Vecteezy dengan mengklik tombol hapus pada tiap tag (boleh dibatalkan). */
async function removeAllVecteezyTagsAsync(scopeRoot, shouldContinue = () => true) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  let iterations = 0;

  const tryKeyboardRemoveViaInput = async () => {
    const input = findVecteezyKeywordTagInput(root);
    if (!(input instanceof HTMLElement)) return false;
    if (!isFormFieldVisible(input) || isInsideNeronaOverlay(input)) return false;

    try {
      input.focus?.();
    } catch (_e) {}

    // Pastikan value input kosong agar Backspace menghapus chip terakhir.
    if (!input.isContentEditable) {
      try {
        if (setNativeValue(input, "")) {
          flushNativeFieldValueCommitted(input);
          dispatchTypingEvents(input);
        }
      } catch (_e) {}
    } else {
      try {
        input.textContent = "";
        dispatchTypingEvents(input);
      } catch (_e) {}
    }

    let removedAny = false;
    let prev = getVecteezyExistingTags().size;
    // Spam backspace: pada komponen tags/autocomplete, backspace saat input kosong akan menghapus chip terakhir.
    for (let i = 0; i < 80 && shouldContinue(); i += 1) {
      const evDown = new KeyboardEvent("keydown", {
        bubbles: true,
        cancelable: true,
        key: "Backspace",
        code: "Backspace",
        keyCode: 8,
        which: 8
      });
      const evUp = new KeyboardEvent("keyup", {
        bubbles: true,
        cancelable: true,
        key: "Backspace",
        code: "Backspace",
        keyCode: 8,
        which: 8
      });
      input.dispatchEvent(evDown);
      input.dispatchEvent(evUp);
      await sleep(25);

      const now = getVecteezyExistingTags().size;
      if (now < prev) {
        removedAny = true;
        prev = now;
      }
      if (now === 0) break;
    }
    return removedAny;
  };

  while (iterations < 260 && shouldContinue()) {
    iterations += 1;
    const lists = Array.from(
      root.querySelectorAll(
        [
          'ul[data-testid="tags-list"]',
          '[data-testid*="tags" i]',
          '[class*="tags" i] ul',
          '[role="list"]'
        ].join(", ")
      )
    ).filter((ul) => {
      if (!(ul instanceof HTMLElement)) return false;
      if (isInsideNeronaOverlay(ul)) return false;
      const st = window.getComputedStyle(ul);
      if (st.display === "none" || st.visibility === "hidden") return false;
      const r = ul.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    });

    let clicked = false;
    const tryClickRemoveButtonWithin = async (container) => {
      if (!(container instanceof HTMLElement)) return false;
      const candidates = Array.from(
        container.querySelectorAll(
          [
            'button[aria-label*="remove" i]',
            'button[aria-label*="delete" i]',
            'button[aria-label*="close" i]',
            'button[title*="remove" i]',
            'button[title*="delete" i]',
            'button[title*="close" i]',
            '[data-testid*="remove" i]',
            '[data-testid*="delete" i]',
            // MUI / Autocomplete chips
            "button.MuiChip-deleteIcon",
            ".MuiChip-root button",
            '[aria-label="Delete"]'
          ].join(", ")
        )
      ).filter((el) => el instanceof HTMLElement && isFormFieldVisible(el) && !isInsideNeronaOverlay(el));

      // Jika tidak ada kandidat eksplisit, coba tombol kecil dalam chip.
      if (!candidates.length) {
        const btns = Array.from(container.querySelectorAll("button")).filter(
          (b) => b instanceof HTMLElement && isFormFieldVisible(b) && !isInsideNeronaOverlay(b)
        );
        btns.sort((a, b) => a.getBoundingClientRect().width - b.getBoundingClientRect().width);
        for (const b of btns.slice(0, 24)) {
          const al = (b.getAttribute("aria-label") || "").toLowerCase();
          const tl = (b.getAttribute("title") || "").toLowerCase();
          if (al.includes("remove") || al.includes("delete") || al.includes("close")) return (b.click(), true);
          if (tl.includes("remove") || tl.includes("delete") || tl.includes("close")) return (b.click(), true);
          const r = b.getBoundingClientRect();
          if (r.width > 0 && r.width <= 36 && r.height > 0 && r.height <= 36) return (b.click(), true);
        }
        return false;
      }

      candidates.sort((a, b) => a.getBoundingClientRect().width - b.getBoundingClientRect().width);
      candidates[0].click();
      return true;
    };

    // 1) Coba dari list/tag container yang terdeteksi.
    for (const list of lists) {
      // Prioritaskan area yang terlihat mengandung item tag.
      const items = list.querySelectorAll('[data-testid="tag"], [data-testid*="tag" i], li, [role="listitem"]');
      if (!items.length) continue;
      const ok = await tryClickRemoveButtonWithin(list);
      if (ok) {
        clicked = true;
        await sleep(55);
        break;
      }
    }

    // 2) Fallback: cari berdasarkan input keywords, lalu cari tombol remove di sekitar section itu.
    if (!clicked) {
      const input = findVecteezyKeywordTagInput(root);
      const scope =
        input?.closest('section, form, [role="region"], [data-testid*="keyword" i], [data-testid*="tags" i]') ||
        input?.parentElement ||
        null;
      if (scope) {
        const ok = await tryClickRemoveButtonWithin(scope);
        if (ok) {
          clicked = true;
          await sleep(55);
        }
      }
    }

    // 3) Fallback kuat untuk bulk upload: pakai backspace dari input keywords untuk menghapus chip.
    if (!clicked) {
      const kb = await tryKeyboardRemoveViaInput();
      if (kb) {
        clicked = true;
        await sleep(55);
      }
    }

    if (!clicked) break;
  }
  return true;
}

const VECTEEZY_RESOURCE_CARD_SEL = '[data-testid="resource-card"]';
const VECTEEZY_RESOURCE_CARD_SELECTED_SEL = '[data-testid="resource-card"].is-selected';
const VECTEEZY_RESOURCE_PREVIEW_SEL = '[data-testid="resource-card-preview"]';
const VECTEEZY_RESOURCE_THUMB_SEL =
  '[data-testid="resource-card-preview"] img[src], [data-testid="resource-card"] img[src]';

function isVecteezyContributorHost() {
  const h = String(location.hostname || "").toLowerCase();
  return h === "contributors.vecteezy.com";
}

function findVecteezyResourceCardForImage(imgEl) {
  if (!imgEl) return null;
  return imgEl.closest?.(VECTEEZY_RESOURCE_CARD_SEL) || null;
}

function isVecteezyResourceCardSelected(card) {
  if (!(card instanceof HTMLElement)) return false;
  if (card.matches?.(VECTEEZY_RESOURCE_CARD_SELECTED_SEL)) return true;
  return card.classList?.contains("is-selected") === true;
}

function getVecteezySelectedResourceCards() {
  const cards = [];
  const seen = new Set();
  document.querySelectorAll(VECTEEZY_RESOURCE_CARD_SELECTED_SEL).forEach((el) => {
    if (isInsideNeronaOverlay(el)) return;
    const id = el.getAttribute("data-resource-id") || imgDomDedupeKey(el.querySelector("img[src]"));
    const key = id || String(el.className || "");
    if (seen.has(key)) return;
    seen.add(key);
    cards.push(el);
  });
  return cards;
}

function getVecteezySelectedImages() {
  const imgs = [];
  const seen = new Set();
  for (const card of getVecteezySelectedResourceCards()) {
    const img =
      card.querySelector?.(`${VECTEEZY_RESOURCE_PREVIEW_SEL} img[src]`) ||
      card.querySelector?.('img[src]');
    if (!img || isInsideNeronaOverlay(img) || !isElementVisible(img)) continue;
    const key = imgDomDedupeKey(img);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    imgs.push(img);
  }
  return imgs;
}

function pickVecteezyThumbnailResourceUrl(imageEl) {
  if (!imageEl || !isVecteezyContributorHost()) return "";
  const card = findVecteezyResourceCardForImage(imageEl);
  const img =
    card?.querySelector?.(`${VECTEEZY_RESOURCE_PREVIEW_SEL} img[src]`) ||
    card?.querySelector?.("img[src]") ||
    imageEl;
  return resolveBestImageUrlFromElement(img);
}

function findVecteezyResourceCardByResourceId(resourceId) {
  const id = String(resourceId || "").trim();
  if (!id) return null;
  try {
    return document.querySelector(`${VECTEEZY_RESOURCE_CARD_SEL}[data-resource-id="${CSS.escape(id)}"]`);
  } catch (_e) {
    return document.querySelector(`${VECTEEZY_RESOURCE_CARD_SEL}[data-resource-id="${id}"]`);
  }
}

/** Snapshot URL + resource id per card SEBELUM deselect (hindari img/card DOM berubah). */
function snapshotVecteezyBatchImages(imgs) {
  return (Array.isArray(imgs) ? imgs : []).map((imgEl) => {
    const card = findVecteezyResourceCardForImage(imgEl);
    const pinnedUrl = pickVecteezyThumbnailResourceUrl(imgEl);
    const resourceId = card?.getAttribute?.("data-resource-id") || "";
    return { imgEl, card, pinnedUrl, resourceId };
  });
}

function resolveVecteezyBatchTarget(job) {
  if (!job) return { imgEl: null, card: null };
  const freshCard = job.resourceId ? findVecteezyResourceCardByResourceId(job.resourceId) : null;
  const card = freshCard || job.card || findVecteezyResourceCardForImage(job.imgEl);
  const imgEl =
    card?.querySelector?.(`${VECTEEZY_RESOURCE_PREVIEW_SEL} img[src]`) ||
    card?.querySelector?.("img[src]") ||
    job.imgEl;
  return { imgEl, card };
}

function clickVecteezyResourceCard(card) {
  if (!(card instanceof HTMLElement)) return false;
  const target =
    card.querySelector?.('[data-testid="resource-card-preview"]') ||
    card.querySelector?.("img[src]") ||
    card;
  if (target instanceof HTMLElement) {
    target.click();
    return true;
  }
  dispatchPlainClick(card);
  return true;
}

async function deselectAllVecteezyResourceCards() {
  if (!isVecteezyContributorHost()) return;
  for (let round = 0; round < 16; round += 1) {
    const selected = getVecteezySelectedResourceCards();
    if (!selected.length) break;
    let changed = false;
    for (const card of selected) {
      clickVecteezyResourceCard(card);
      changed = true;
      await sleep(70);
    }
    if (!changed) break;
    await sleep(120);
  }
}

function isVecteezyExclusiveSelectionForCard(card) {
  if (!card || !isVecteezyResourceCardSelected(card)) return false;
  return getVecteezySelectedResourceCards().length === 1;
}

async function selectExclusiveVecteezyResourceCard(imgEl, job = null) {
  if (!isVecteezyContributorHost()) return false;

  const target = resolveVecteezyBatchTarget(job || { imgEl });
  const card = target.card || findVecteezyResourceCardForImage(imgEl);
  if (!card) return false;

  try {
    card.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "instant" });
  } catch (_e) {
    try {
      card.scrollIntoView({ block: "nearest", inline: "nearest" });
    } catch (_e2) {
      /* ignore */
    }
  }

  await deselectAllVecteezyResourceCards();

  clickVecteezyResourceCard(card);
  await sleep(280);
  if (isVecteezyExclusiveSelectionForCard(card)) return true;

  clickVecteezyResourceCard(card);
  await sleep(220);
  return isVecteezyExclusiveSelectionForCard(card);
}

/** Vecteezy: pilih 1 resource-card → isi title/desc/tag → deselect. */
async function applyVecteezyMetadataToSingleAsset(imgEl, metadata, job = null) {
  if (!metadata) {
    return { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false };
  }

  const target = resolveVecteezyBatchTarget(job || { imgEl });
  const card = target.card || findVecteezyResourceCardForImage(imgEl);
  if (!isVecteezyExclusiveSelectionForCard(card)) {
    const selected = await selectExclusiveVecteezyResourceCard(imgEl, job);
    if (!selected) return { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false };
    await sleep(220);
  }

  closeVecteezyBlockingModalIfAny();
  const scope = resolveVecteezyBatchTarget(job || { imgEl }).card || card;
  let result = scope
    ? applyMarketplaceMetadataInScope(scope, metadata, "vecteezy")
    : { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false };

  if (!result.ok) {
    result = applyGeneric(marketplaceSelectors.vecteezy, metadata, "vecteezy");
  }

  const tagOk = await applyVecteezyTagsAfterMetadata(metadata, null);
  if (tagOk) {
    result.keywordDone = true;
    result.ok = result.ok || tagOk;
  }

  const freshCard = resolveVecteezyBatchTarget(job || { imgEl }).card || card;
  if (freshCard && isVecteezyResourceCardSelected(freshCard)) {
    clickVecteezyResourceCard(freshCard);
    await sleep(180);
  }

  return result;
}

function closeVecteezyBlockingModalIfAny() {
  if (!location.hostname.includes("vecteezy.com")) {
    return false;
  }

  const closeButton = firstMatch([
    'button[aria-label*="close" i]',
    'button[class*="close" i]',
    '[role="dialog"] button'
  ]);

  const titleEl = Array.from(document.querySelectorAll("h1,h2,h3,div,p")).find((el) =>
    /prohibited terms in titles/i.test(el.textContent || "")
  );

  if (titleEl) {
    const modal =
      titleEl.closest('[role="dialog"]') ||
      titleEl.closest(".modal") ||
      titleEl.parentElement;
    const modalClose = modal?.querySelector("button");
    if (modalClose instanceof HTMLElement) {
      modalClose.click();
      return true;
    }
  }

  if (closeButton instanceof HTMLElement) {
    const txt = (closeButton.textContent || "").toLowerCase();
    if (txt.includes("close") || closeButton.getAttribute("aria-label")) {
      closeButton.click();
      return true;
    }
  }

  return false;
}

function normalizeTitle(seedTitle) {
  return String(seedTitle || "")
    .trim()
    .split(" ")
    .filter(Boolean)
    .map((word) => word[0].toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");
}

function buildLocalMetadataFromPrompt(seedTitle, style, category) {
  const normalizedTitle = normalizeTitle(seedTitle);

  const stylePart = style ? `, ${style}` : "";
  const description = `${normalizedTitle}${stylePart}. High quality stock image suitable for commercial and editorial use.`;

  const tokens = `${seedTitle}, ${style}, ${category}, stock, photo, commercial`
    .split(/[,.\s-]+/g)
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean)
    .slice(0, 49);

  const keywords = Array.from(new Set(tokens)).join(", ");

  return {
    fileName: normalizedTitle,
    description,
    keywords,
    category: category || "People"
  };
}

function stripJsonResponseWrapper(text) {
  let raw = String(text || "").trim();
  if (raw.startsWith(")]}'")) {
    raw = raw.replace(/^\)\]\}'\s*/, "").trim();
  }
  if (raw.charCodeAt(0) === 0xfeff) {
    raw = raw.slice(1);
  }
  return raw;
}

function safeJsonParse(text) {
  const raw = stripJsonResponseWrapper(text);
  if (!raw) return null;

  const unfenced = raw
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .replace(/```/g, "")
    .trim();

  const tryParse = (slice) => {
    try {
      return JSON.parse(slice);
    } catch (_e) {
      return null;
    }
  };

  let parsed = tryParse(unfenced);
  if (parsed) return parsed;

  const start = unfenced.indexOf("{");
  const end = unfenced.lastIndexOf("}");
  if (start >= 0 && end > start) {
    parsed = tryParse(unfenced.slice(start, end + 1));
    if (parsed) return parsed;
  }

  const aStart = unfenced.indexOf("[");
  const aEnd = unfenced.lastIndexOf("]");
  if (aStart >= 0 && aEnd > aStart) {
    parsed = tryParse(unfenced.slice(aStart, aEnd + 1));
    if (parsed) return parsed;
  }

  return null;
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = String(reader.result || "");
      const commaIndex = result.indexOf(",");
      if (commaIndex === -1) {
        reject(new Error("Format base64 tidak valid."));
        return;
      }
      resolve(result.slice(commaIndex + 1));
    };
    reader.onerror = () => reject(new Error("Gagal membaca blob gambar."));
    reader.readAsDataURL(blob);
  });
}

/**
 * Batas untuk gambar yang dikirim ke vision API.
 *
 * Dipakai bersama oleh jalur canvas DAN jalur fetch. Dulu hanya jalur canvas yang
 * menurunkan resolusi, sementara jalur fetch mengirim file asli apa adanya —
 * padahal justru jalur fetch yang paling sering dipakai (canvas kena taint CORS
 * di CDN marketplace, dan Miricanvas sengaja memilih fetch lewat
 * preferPinnedUrlFetch). Akibatnya gambar 6000px berukuran megabyte diunggah
 * utuh: lambat dikirim, lebih lama diproses model, dan lebih boros poin.
 */
const NERONA_VISION_MAX_EDGE = 1280;
const NERONA_VISION_JPEG_QUALITY = 0.88;
/** Di bawah ini, mengompres ulang tidak sepadan dengan kehilangan detailnya. */
const NERONA_VISION_SKIP_SHRINK_BYTES = 300 * 1024;

function neronaScaledSize(width, height) {
  const longest = Math.max(width, height);
  if (!longest || longest <= NERONA_VISION_MAX_EDGE) return { width, height, scaled: false };
  const sc = NERONA_VISION_MAX_EDGE / longest;
  return {
    width: Math.max(1, Math.round(width * sc)),
    height: Math.max(1, Math.round(height * sc)),
    scaled: true
  };
}

/**
 * Perkecil blob gambar sebelum dikirim. Mengembalikan null kalau tidak perlu
 * atau tidak bisa — pemanggil lalu memakai byte aslinya, karena generate yang
 * berhasil dengan gambar besar tetap lebih baik daripada gagal sama sekali.
 */
async function shrinkImageBlobToInlineData(blob) {
  try {
    if (!blob || typeof createImageBitmap !== "function") return null;
    // SVG dan format tanpa dimensi raster tidak bisa digambar ulang dengan aman.
    if (/svg/i.test(blob.type || "")) return null;

    const bitmap = await createImageBitmap(blob);
    const target = neronaScaledSize(bitmap.width, bitmap.height);
    if (!target.scaled && blob.size <= NERONA_VISION_SKIP_SHRINK_BYTES) {
      bitmap.close?.();
      return null;
    }

    const canvas = document.createElement("canvas");
    canvas.width = target.width;
    canvas.height = target.height;
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      bitmap.close?.();
      return null;
    }
    ctx.drawImage(bitmap, 0, 0, target.width, target.height);
    bitmap.close?.();

    const dataUrl = canvas.toDataURL("image/jpeg", NERONA_VISION_JPEG_QUALITY);
    const [, data] = dataUrl.split(",", 2);
    if (!data) return null;
    return { mimeType: "image/jpeg", data };
  } catch (_e) {
    // Gambar rusak, format tak dikenal, atau canvas ditolak — pakai aslinya.
    return null;
  }
}

function imageElementToInlineDataViaCanvas(imageEl) {
  if (!imageEl) {
    throw new Error("Elemen gambar tidak tersedia.");
  }

  const width = imageEl.naturalWidth || imageEl.width;
  const height = imageEl.naturalHeight || imageEl.height;
  if (!width || !height) {
    throw new Error("Ukuran gambar tidak valid.");
  }

  const target = neronaScaledSize(width, height);
  const outW = target.width;
  const outH = target.height;

  const canvas = document.createElement("canvas");
  canvas.width = outW;
  canvas.height = outH;
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    throw new Error("Canvas context tidak tersedia.");
  }

  ctx.drawImage(imageEl, 0, 0, outW, outH);
  const dataUrl = canvas.toDataURL("image/jpeg", NERONA_VISION_JPEG_QUALITY);
  const [header, data] = dataUrl.split(",", 2);
  const mimeMatch = /data:([^;]+);base64/i.exec(header || "");

  if (!data) {
    throw new Error("Konversi gambar ke base64 gagal.");
  }

  return {
    mimeType: mimeMatch?.[1] || "image/jpeg",
    data
  };
}

/** Maks thumbnail di modal picker (dulu 12 → sering kurang untuk grid Adobe). */
const NERONA_PICKER_IMAGE_CAP = 48;

function isElementVisible(el, minSide = 28) {
  if (!el) return false;
  const rect = el.getBoundingClientRect();
  return rect.width >= minSide && rect.height >= minSide;
}

function isInsideNeronaOverlay(el) {
  return !!(el?.closest && el.closest("[data-nerona-overlay]"));
}

function isAdobeContributorHost() {
  const h = location.hostname;
  return h.includes("contributor.stock.adobe.com") || h.includes("contributors.stock.adobe.com");
}

/** Warna seperti border/ring seleksi Adobe (biru dominan — hindari abu-abu). */
function isBlueishCssColor(value) {
  if (!value || value === "transparent") return false;
  const m = /rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/.exec(String(value));
  if (!m) return false;
  const r = Number(m[1]);
  const g = Number(m[2]);
  const b = Number(m[3]);
  return b >= 100 && b > r + 25 && b > g + 15;
}

function rgbaSnippetsInString(s) {
  return String(s).match(/rgba?\([^)]+\)/g) || [];
}

function elementHasAdobeStyleSelectionRing(el) {
  if (!el || isInsideNeronaOverlay(el)) return false;
  const st = getComputedStyle(el);
  const outlineW = parseFloat(st.outlineWidth) || 0;
  if (outlineW >= 2 && st.outlineStyle !== "none" && isBlueishCssColor(st.outlineColor)) {
    return true;
  }
  const sides = ["Top", "Right", "Bottom", "Left"];
  const maxBorder = Math.max(
    ...sides.map((side) => parseFloat(st[`border${side}Width`]) || 0)
  );
  if (maxBorder >= 2) {
    for (const side of sides) {
      if (isBlueishCssColor(st[`border${side}Color`])) {
        return true;
      }
    }
  }
  const sh = st.boxShadow;
  if (sh && sh !== "none") {
    if (rgbaSnippetsInString(sh).some(isBlueishCssColor)) {
      return true;
    }
  }
  return false;
}

/**
 * Grid Adobe sering menandai multi-select dengan ring biru / border, bukan checkbox DOM.
 * Naik dari <img> ke ancestor dan cek outline, border, atau box-shadow biru.
 */
function addAdobeImagesSelectedByVisualRing(imgs) {
  const pool = document.querySelectorAll("img[src]");
  for (const img of pool) {
    if (isInsideNeronaOverlay(img) || !isElementVisible(img) || !isLikelyAdobeGridThumbnail(img)) continue;
    let el = img;
    for (let d = 0; d < 10 && el; d += 1) {
      if (isInsideNeronaOverlay(el)) break;
      if (elementHasAdobeStyleSelectionRing(el)) {
        imgs.add(img);
        break;
      }
      el = el.parentElement;
    }
  }
}

function isLikelyAdobeMainPreviewImage(img) {
  if (!img) return false;
  const r = img.getBoundingClientRect();
  const area = r.width * r.height;
  const vpArea = Math.max(window.innerWidth * window.innerHeight, 1);
  if (area > vpArea * 0.12) return true;
  const nw = img.naturalWidth || 0;
  const nh = img.naturalHeight || 0;
  return nw >= 640 && nh >= 640 && area > vpArea * 0.06;
}

function isLikelyAdobeGridThumbnail(img) {
  if (!img?.src || isInsideNeronaOverlay(img) || !isElementVisible(img)) return false;
  if (img.classList?.contains("upload-tile__thumbnail") || img.closest?.(".upload-tile")) {
    return true;
  }
  if (isLikelyAdobeMainPreviewImage(img)) return false;
  const r = img.getBoundingClientRect();
  return r.width >= 40 && r.height >= 40 && r.width <= window.innerWidth * 0.42;
}

function distanceImgToViewportCenter(img) {
  const r = img.getBoundingClientRect();
  const cx = r.left + r.width / 2;
  const cy = r.top + r.height / 2;
  const vx = window.innerWidth / 2;
  const vy = window.innerHeight / 2;
  return Math.hypot(cx - vx, cy - vy);
}

function sortImagesByViewportCenterProximity(imgs) {
  return [...imgs].sort((a, b) => distanceImgToViewportCenter(a) - distanceImgToViewportCenter(b));
}

function scoreAdobeSelectionStrength(img) {
  if (!img) return -Infinity;
  let score = 0;
  let el = img;
  for (let d = 0; d < 12 && el; d += 1) {
    if (isInsideNeronaOverlay(el)) break;
    const cls = String(el.className || "");
    if (/is-selected|itemIsSelected|assetList-item--isSelected/i.test(cls)) score += 100;
    const opt = el.closest?.('[role="option"][title="Content tile"], [role="option"]');
    if (opt && String(opt.getAttribute("aria-selected") || "").toLowerCase() === "true") {
      score += 100;
    }
    if (el.matches?.('[role="checkbox"][aria-checked="true"]')) score += 70;
    if (el.querySelector?.('input[type="checkbox"]:checked, [role="checkbox"][aria-checked="true"]')) {
      score += 65;
    }
    if (elementHasAdobeStyleSelectionRing(el)) score += 55;
    el = el.parentElement;
  }
  score -= distanceImgToViewportCenter(img) / 1200;
  return score;
}

function rankAdobeSelectedImages(imgs) {
  const unique = [];
  const seen = new Set();
  for (const img of imgs) {
    const key = imgDomDedupeKey(img);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    unique.push(img);
  }
  const active = document.activeElement;
  const isActiveRelated = (img) => {
    if (!active || !img) return false;
    if (img === active || active === img) return true;
    const row = findAdobeAssetRowForImage(img);
    return !!(row?.contains(active) || active.contains?.(img) || img.contains?.(active));
  };
  return unique.sort((a, b) => {
    const aActive = isActiveRelated(a);
    const bActive = isActiveRelated(b);
    if (aActive && !bActive) return -1;
    if (bActive && !aActive) return 1;
    return scoreAdobeSelectionStrength(b) - scoreAdobeSelectionStrength(a);
  });
}

function collectAdobeGridThumbnailImages() {
  const thumbs = [];
  document.querySelectorAll("img[src]").forEach((img) => {
    if (isLikelyAdobeGridThumbnail(img)) thumbs.push(img);
  });
  return thumbs;
}

/** Class Spectrum: hanya state terpilih nyata — bukan is-focused (sering = fokus keyboard di aset pertama). */
function addAdobeImagesFromSelectedClassRoots(imgs) {
  const roots = document.querySelectorAll(
    '[class*="itemIsSelected"], [class*="assetList-item--isSelected"], [class*="is-selected"]'
  );
  for (const root of roots) {
    if (isInsideNeronaOverlay(root)) continue;
    const cls = String(root.className || "");
    if (/unselected/i.test(cls)) continue;
    if (/is-focused/i.test(cls) && !/itemIsSelected|assetList-item--isSelected/i.test(cls)) continue;
    root.querySelectorAll("img[src]").forEach((img) => {
      if (!isInsideNeronaOverlay(img) && isElementVisible(img) && isLikelyAdobeGridThumbnail(img)) {
        imgs.add(img);
      }
    });
  }
}

/** Grid upload Adobe: hanya tile dengan role="option" aria-selected="true". */
function addAdobeImagesFromUploadTiles(imgs) {
  const options = document.querySelectorAll(
    '.content-grid-elements [role="option"][aria-selected="true"]'
  );
  for (const opt of options) {
    if (isInsideNeronaOverlay(opt)) continue;
    const grid = opt.closest(".content-grid-elements");
    const img =
      grid?.querySelector?.("img.upload-tile__thumbnail[src]") ||
      opt.querySelector?.("img.upload-tile__thumbnail[src]") ||
      opt.querySelector?.("img[src]");
    if (img && !isInsideNeronaOverlay(img) && isElementVisible(img) && isLikelyAdobeGridThumbnail(img)) {
      imgs.add(img);
    }
  }
}

function addAdobeImagesFromLegacyCheckedControls(imgs) {
  const addImgFromRoot = (root) => {
    if (!root || isInsideNeronaOverlay(root)) return;
    const img = root.querySelector?.("img[src]");
    if (img && !isInsideNeronaOverlay(img) && isElementVisible(img) && isLikelyAdobeGridThumbnail(img)) {
      imgs.add(img);
    }
  };

  document.querySelectorAll('input[type="checkbox"]:checked').forEach((cb) => {
    if (isInsideNeronaOverlay(cb)) return;
    const row =
      cb.closest(
        '[role="row"], [role="gridcell"], [role="rowgroup"] [role="row"], tr, li, article, [class*="row"], [class*="Row"], [class*="asset"], [class*="Asset"], [class*="thumbnail"], [class*="Thumbnail"], [class*="file"], [class*="File"]'
      ) || cb.parentElement?.parentElement;
    addImgFromRoot(row);
  });

  document.querySelectorAll('[role="checkbox"][aria-checked="true"]').forEach((el) => {
    if (isInsideNeronaOverlay(el)) return;
    const row = el.closest(
      '[role="row"], [role="gridcell"], tr, li, article, [class*="row"], [class*="Row"], [class*="asset"], [class*="Asset"]'
    );
    addImgFromRoot(row || el.parentElement);
  });

  addAdobeImagesFromSelectedClassRoots(imgs);
}

/** Hanya aset yang user centang / pilih eksplisit — untuk antrian generate metadata. */
function findAdobeExplicitlyCheckedImageElements() {
  const imgs = new Set();
  if (adobePageUsesUploadTileGrid()) {
    addAdobeImagesFromUploadTiles(imgs);
    return sortAdobeCheckedImagesDomOrder(Array.from(imgs));
  }
  addAdobeImagesFromLegacyCheckedControls(imgs);
  return sortAdobeCheckedImagesDomOrder(Array.from(imgs));
}

/**
 * Gambar terpilih di grid Adobe.
 * Prioritas: checkbox / class terpilih eksplisit. Heuristik lemah (fokus, ring biru) hanya jika tidak ada centang.
 */
function findAdobeSelectedImageElements() {
  const explicit = findAdobeExplicitlyCheckedImageElements();
  if (explicit.length) return explicit;

  const imgs = new Set();
  addAdobeImagesFromUploadTiles(imgs);
  addAdobeImagesSelectedByVisualRing(imgs);

  return rankAdobeSelectedImages(Array.from(imgs));
}

function imgDomDedupeKey(img) {
  if (!img?.src) return "";
  const src = String(img.currentSrc || img.src).trim();
  const r = img.getBoundingClientRect();
  return `${src}|${Math.round(r.left)}|${Math.round(r.top)}|${Math.round(r.width)}|${Math.round(r.height)}`;
}

/** Gambar besar di viewport contributor (thumbnail grid + preview); hindari gabung URL sama ke satu slot. */
function collectAdobeContributorGalleryImages() {
  const areas = [];
  document.querySelectorAll("img[src]").forEach((img) => {
    if (isInsideNeronaOverlay(img) || !isElementVisible(img)) return;
    const src = String(img.currentSrc || img.src).trim();
    if (!src) return;
    const r = img.getBoundingClientRect();
    areas.push({ img, area: r.width * r.height });
  });
  areas.sort((a, b) => b.area - a.area);
  const picked = [];
  const seenKeys = new Set();
  for (const { img } of areas) {
    const key = imgDomDedupeKey(img);
    if (!key || seenKeys.has(key)) continue;
    seenKeys.add(key);
    picked.push(img);
    if (picked.length >= NERONA_PICKER_IMAGE_CAP * 3) break;
  }
  return picked;
}

function getAdobeAnalyzableImageCandidates() {
  const selectedList = findAdobeSelectedImageElements();
  const selectedKeys = new Set(
    selectedList.map((i) => i.currentSrc || i.src).filter(Boolean)
  );
  const seen = new Set();
  const ordered = [];

  const push = (img) => {
    if (!img?.src || !isElementVisible(img) || isInsideNeronaOverlay(img)) return;
    if (isAdobeContributorHost() && !isLikelyAdobeGridThumbnail(img) && !isLikelyAdobeMainPreviewImage(img)) {
      return;
    }
    const key = imgDomDedupeKey(img);
    if (!key || seen.has(key)) return;
    seen.add(key);
    ordered.push(img);
  };

  rankAdobeSelectedImages(selectedList).forEach(push);

  collectAdobeGridThumbnailImages().forEach(push);
  collectAdobeContributorGalleryImages().forEach((img) => {
    if (isLikelyAdobeGridThumbnail(img)) push(img);
  });

  const fallbackSelectors =
    '[aria-selected="true"] img, [data-testid*="selected"] img, img[alt][src], img[srcset], img[src]';
  document.querySelectorAll(fallbackSelectors).forEach((item) => push(item));

  const head = ordered.filter((img) => selectedKeys.has(img.currentSrc || img.src));
  const tail = ordered.filter((img) => !selectedKeys.has(img.currentSrc || img.src));
  tail.sort((a, b) => distanceImgToViewportCenter(a) - distanceImgToViewportCenter(b));
  return [...rankAdobeSelectedImages(head), ...tail].slice(0, NERONA_PICKER_IMAGE_CAP);
}

function getLikelyAnalyzedImageElement() {
  const candidates = getAnalyzableImageCandidates();
  return candidates[0] || null;
}

function getAnalyzableImageCandidates() {
  if (isAdobeContributorHost()) {
    return getAdobeAnalyzableImageCandidates();
  }
  if (isShutterstockContributorHost()) {
    const selected = getShutterstockSelectedImages();
    if (selected.length) return selected.slice(0, NERONA_PICKER_IMAGE_CAP);
  }

  const prioritizedSelectors = [
    '[data-testid="asset-card"][aria-checked="true"] img[src]',
    '[aria-selected="true"] img',
    '[class*="selected"] img',
    '[data-testid*="selected"] img'
  ];
  const fallbackSelector = "img[alt][src]";

  const seen = new Set();
  const prioritized = [];
  for (const selector of prioritizedSelectors) {
    for (const item of document.querySelectorAll(selector)) {
      if (!item?.src || !isElementVisible(item)) continue;
      const key = item.currentSrc || item.src;
      if (seen.has(key)) continue;
      seen.add(key);
      prioritized.push(item);
    }
  }

  const rest = [];
  for (const item of document.querySelectorAll(fallbackSelector)) {
    if (!item?.src || !isElementVisible(item)) continue;
    const key = item.currentSrc || item.src;
    if (seen.has(key)) continue;
    seen.add(key);
    rest.push(item);
  }

  rest.sort((a, b) => {
    const aScore = (a.naturalWidth || 0) * (a.naturalHeight || 0);
    const bScore = (b.naturalWidth || 0) * (b.naturalHeight || 0);
    return bScore - aScore;
  });

  const candidates = [...prioritized, ...rest];
  return candidates.slice(0, NERONA_PICKER_IMAGE_CAP);
}

function getImageDisplayName(imageEl, index) {
  const alt = String(imageEl?.alt || "").trim();
  if (alt) return alt.slice(0, 60);
  const src = String(imageEl?.currentSrc || imageEl?.src || "").trim();
  const fromUrl = src.split("?")[0].split("/").pop() || "";
  if (fromUrl) return fromUrl.slice(0, 60);
  return `Image ${index + 1}`;
}

function askUserToPickImages(candidates, options = {}) {
  const { preselectSrcKeys = null, refreshPickerState = null } = options;

  return new Promise((resolve) => {
    const initialList = Array.isArray(candidates) ? candidates : [];
    if (!initialList.length && !refreshPickerState) {
      resolve([]);
      return;
    }

    const overlay = document.createElement("div");
    overlay.setAttribute("data-nerona-overlay", "1");
    overlay.style.position = "fixed";
    overlay.style.inset = "0";
    overlay.style.zIndex = "2147483646";
    overlay.style.background = "rgba(8, 15, 34, 0.75)";
    overlay.style.backdropFilter = "blur(2px)";
    overlay.style.display = "flex";
    overlay.style.alignItems = "center";
    overlay.style.justifyContent = "center";
    overlay.style.padding = "16px";

    const panel = document.createElement("div");
    panel.style.width = "min(920px, 95vw)";
    panel.style.maxHeight = "82vh";
    panel.style.overflow = "auto";
    panel.style.background = "#0b1220";
    panel.style.border = "1px solid #334155";
    panel.style.borderRadius = "12px";
    panel.style.padding = "14px";
    panel.style.boxShadow = "0 30px 80px rgba(0,0,0,0.55)";
    panel.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px;">
        <div>
          <div style="font-size:14px;font-weight:700;color:#e2e8f0;">Pilih gambar untuk dianalisa</div>
          <div style="font-size:12px;color:#94a3b8;">Bisa pilih lebih dari satu. Sistem akan memproses satu per satu.</div>
        </div>
        <div id="nerona-picker-header-actions" style="display:flex;gap:8px;align-items:center;flex-shrink:0;"></div>
      </div>
      <div id="nerona-picker-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px;"></div>
      <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px;">
        <button type="button" id="nerona-picker-cancel" style="background:#1f2937;color:#e2e8f0;border:1px solid #374151;border-radius:8px;padding:8px 12px;cursor:pointer;">Batal</button>
        <button type="button" id="nerona-picker-ok" style="background:linear-gradient(135deg,#2563eb,#7c3aed);color:#fff;border:0;border-radius:8px;padding:8px 12px;font-weight:700;cursor:pointer;">Analisa Gambar Terpilih</button>
      </div>
    `;

    const headerActions = panel.querySelector("#nerona-picker-header-actions");
    const grid = panel.querySelector("#nerona-picker-grid");

    let state = {
      list: [...initialList],
      keys: preselectSrcKeys
    };

    const defaultCheckedForIndex = (index, src, keysSet) => {
      if (keysSet && keysSet.size > 0) {
        return keysSet.has(src) ? "checked" : "";
      }
      return index === 0 ? "checked" : "";
    };

    const renderGrid = () => {
      if (!grid) return;
      grid.innerHTML = "";
      const { list, keys } = state;
      if (!list.length) {
        grid.innerHTML = `
          <div style="grid-column:1/-1;font-size:13px;color:#94a3b8;line-height:1.5;">
            Tidak ada gambar terdeteksi. Di Adobe: centang aset di grid, lalu klik <strong style="color:#e2e8f0;">Segarkan</strong>.
          </div>`;
        updateSelectAllLabel();
        return;
      }
      list.forEach((img, index) => {
        const card = document.createElement("label");
        card.style.display = "block";
        card.style.border = "1px solid #334155";
        card.style.borderRadius = "10px";
        card.style.padding = "8px";
        card.style.cursor = "pointer";
        card.style.background = "#0f172a";

        const name = getImageDisplayName(img, index);
        const src = img.currentSrc || img.src;
        const checked = defaultCheckedForIndex(index, src, keys);
        card.innerHTML = `
        <input type="checkbox" data-image-index="${index}" ${checked} style="margin-bottom:8px;" />
        <img src="${src}" alt="" style="width:100%;height:96px;object-fit:cover;border-radius:8px;border:1px solid #1e293b;" />
        <div style="font-size:11px;color:#cbd5e1;margin-top:6px;line-height:1.3;">${name}</div>
      `;
        const cb = card.querySelector('input[type="checkbox"]');
        cb?.addEventListener("change", updateSelectAllLabel);
        grid.appendChild(card);
      });
      updateSelectAllLabel();
    };

    const btnStyle =
      "background:#1e293b;color:#e2e8f0;border:1px solid #334155;border-radius:8px;padding:6px 10px;cursor:pointer;";

    const updateSelectAllLabel = () => {
      if (!selectAllBtn) return;
      const all = panel.querySelectorAll('input[type="checkbox"][data-image-index]');
      const checked = panel.querySelectorAll('input[type="checkbox"][data-image-index]:checked');
      selectAllBtn.textContent =
        all.length > 0 && checked.length === all.length ? "Batal Pilih" : "Pilih Semua";
    };

    const selectAllBtn = document.createElement("button");
    selectAllBtn.type = "button";
    selectAllBtn.textContent = "Pilih Semua";
    selectAllBtn.setAttribute("title", "Pilih atau batalkan semua gambar");
    selectAllBtn.style.cssText = btnStyle;
    selectAllBtn.addEventListener("click", () => {
      const boxes = Array.from(
        panel.querySelectorAll('input[type="checkbox"][data-image-index]')
      );
      if (!boxes.length) return;
      const allChecked = boxes.every((cb) => cb.checked);
      boxes.forEach((cb) => {
        cb.checked = !allChecked;
      });
      updateSelectAllLabel();
    });
    headerActions?.appendChild(selectAllBtn);

    if (refreshPickerState && headerActions) {
      const refreshBtn = document.createElement("button");
      refreshBtn.type = "button";
      refreshBtn.textContent = "Segarkan";
      refreshBtn.setAttribute("title", "Ambil ulang daftar gambar dari halaman (setelah ubah pilihan di Adobe)");
      refreshBtn.style.cssText = btnStyle;
      refreshBtn.addEventListener("click", () => {
        requestAnimationFrame(() => {
          try {
            const next = refreshPickerState();
            state = {
              list: Array.isArray(next.candidates) ? [...next.candidates] : [],
              keys: next.preselectSrcKeys
            };
            renderGrid();
            showNeronaToast(`Daftar diperbarui: ${state.list.length} gambar terdeteksi.`);
          } catch (err) {
            showNeronaToast(err?.message || "Gagal menyegarkan daftar gambar.");
          }
        });
      });
      headerActions.appendChild(refreshBtn);
    }

    const closeBtn = document.createElement("button");
    closeBtn.type = "button";
    closeBtn.id = "nerona-picker-close";
    closeBtn.textContent = "Tutup";
    closeBtn.style.cssText = btnStyle;
    headerActions?.appendChild(closeBtn);

    renderGrid();

    const close = () => {
      overlay.remove();
    };

    const submit = () => {
      const list = state.list;
      const checks = Array.from(
        panel.querySelectorAll('input[type="checkbox"][data-image-index]:checked')
      );
      const selected = checks
        .map((input) => Number(input.getAttribute("data-image-index")))
        .filter((idx) => Number.isFinite(idx) && list[idx])
        .map((idx) => list[idx]);
      close();
      resolve(selected);
    };

    closeBtn.addEventListener("click", () => {
      close();
      resolve([]);
    });
    panel.querySelector("#nerona-picker-cancel")?.addEventListener("click", () => {
      close();
      resolve([]);
    });
    panel.querySelector("#nerona-picker-ok")?.addEventListener("click", submit);

    overlay.appendChild(panel);
    document.body.appendChild(overlay);
  });
}

function normalizeKeywordsForStock(keywordsInput, fallbackTitle, limits = {}) {
  const min = Number.isFinite(limits.min) ? limits.min : 15;
  const max = Number.isFinite(limits.max) ? limits.max : 50;
  const marketplaceKey = String(limits.marketplaceKey || limits.marketplace || "").toLowerCase();
  /** Jangan sisipkan potongan judul ketika keyword vision sudah cukup — mengurangi pola berulang antar gambar. */
  const skipTitleAugment = Boolean(limits.skipTitleAugment);
  const titleAugmentMinAi = Number.isFinite(limits.titleAugmentMinAi) ? limits.titleAugmentMinAi : 10;

  const rawInput = Array.isArray(keywordsInput)
    ? keywordsInput.join(", ")
    : String(keywordsInput || "");

  if (marketplaceKey === "vecteezy") {
    return scrubVecteezyKeywordComma(rawInput);
  }

  const fromComma = sanitizeKeywordListForMarketplace(rawInput, marketplaceKey, {
    max,
    augmentFromTitle: false
  });

  const fromTitle =
    skipTitleAugment && fromComma.length >= titleAugmentMinAi
      ? []
      : sanitizeKeywordListForMarketplace(
          String(fallbackTitle || "").split(/[\s,.-]+/).join(", "),
          marketplaceKey,
          { max: 12, augmentFromTitle: false }
        );

  const merged = [];
  const seen = new Set();
  for (const k of [...fromComma, ...fromTitle]) {
    const key = k.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    merged.push(k);
    if (merged.length >= max) break;
  }

  const finalList = merged.slice(0, max);
  if (finalList.length < min) {
    return finalList.join(", ");
  }
  return finalList.join(", ");
}

/** Baca keyword yang sudah terisi dari input/textarea/contenteditable */
function readFormFieldKeywords(el) {
  if (!el) return "";
  if (el.isContentEditable) return String(el.textContent || "").trim();
  return String(el.value || "").trim();
}

/**
 * Menggabungkan keyword yang sudah ada dengan yang baru — tidak menghapus existing.
 * Urutan: existing tetap lebih dulu (supaya tulisan pengguna tidak tergeser prioritasnya).
 */
function mergeExistingKeywords(existingComma, incomingComma, limits = {}) {
  const max = Number.isFinite(limits.max) ? limits.max : 50;

  const tokenizeParts = (s) =>
    String(s || "")
      .split(",")
      .map((k) => k.replace(/\s+/g, " ").trim())
      .filter(Boolean);

  const seenLower = new Set();
  const out = [];

  const pushPreserveOrder = (k) => {
    const normalized = String(k || "").trim();
    if (!normalized.length) return;
    const key = normalized.toLowerCase();
    if (seenLower.has(key)) return;
    seenLower.add(key);
    out.push(normalized);
  };

  for (const part of tokenizeParts(existingComma)) pushPreserveOrder(part);
  for (const part of tokenizeParts(incomingComma)) pushPreserveOrder(part);

  return out.slice(0, max).join(", ");
}

/** Mengikis keyword AI yang jelas tidak terkait blok analisis gambar ini (fallback jika kena terlalu banyak). */
function filterKeywordsByVisualGrounding(parsed, commaKeywords) {
  if (!commaKeywords?.trim?.() || !parsed || typeof parsed !== "object") {
    return commaKeywords;
  }
  let groundingNorm = "";
  try {
    groundingNorm = JSON.stringify({
      title: parsed.title,
      description: parsed.description,
      visualBrief: parsed.visualBrief,
      visualAnalysis: parsed.visualAnalysis,
      styleMetadata: parsed.styleMetadata,
      technicalMetadata: parsed.technicalMetadata
    }).toLowerCase();
  } catch (_e) {
    return commaKeywords;
  }

  const wordsInKeyword = (k) =>
    String(k || "")
      .toLowerCase()
      .match(/[a-z0-9]{3,}/g) || [];

  const parts = String(commaKeywords)
    .split(",")
    .map((k) => k.replace(/\s+/g, " ").trim())
    .filter(Boolean);

  const grounded = [];
  for (const k of parts) {
    const ws = wordsInKeyword(k);
    if (!ws.length) continue;
    if (ws.some((w) => groundingNorm.includes(w))) {
      grounded.push(k);
      continue;
    }
    /** Frasa konservatif: salah satu kata terlalu pendek tetapi whole phrase in title/description */
    const low = k.toLowerCase();
    const inTitleDesc =
      typeof parsed.description === "string" && parsed.description.toLowerCase().includes(low)
        ? true
        : typeof parsed.title === "string" && parsed.title.toLowerCase().includes(low);
    if (inTitleDesc) grounded.push(k);
  }

  /** Jangan buang keseluruhan jika grounding JSON tipis/heuristik gagal — pertahankan asli AI */
  if (grounded.length < Math.min(12, Math.max(8, Math.floor(parts.length * 0.35)))) {
    return commaKeywords;
  }
  return grounded.join(", ");
}

function resolveBestImageUrlFromElement(img) {
  if (!img) return "";
  const srcset = String(img.getAttribute("srcset") || "").trim();
  if (srcset) {
    let bestUrl = "";
    let bestW = 0;
    for (const part of srcset.split(",")) {
      const chunk = part.trim();
      if (!chunk) continue;
      const bits = chunk.split(/\s+/);
      const url = bits[0] || "";
      const w = parseInt(String(bits[1] || "0").replace(/\D/g, ""), 10) || 0;
      if (url && w >= bestW) {
        bestW = w;
        bestUrl = url;
      }
    }
    if (bestUrl) return bestUrl;
  }
  return String(img.currentSrc || img.src || "").trim();
}

/** URL thumbnail aset upload Adobe dari sel grid (hindari img DOM yang di-reuse). */
function pickAdobeThumbnailResourceUrl(imageEl) {
  if (!imageEl || !isAdobeContributorHost()) return "";
  const grid = findAdobeUploadGridCellForImage(imageEl);
  const img =
    (grid &&
      grid.querySelector?.("img.upload-tile__thumbnail[src], .upload-tile img[src], img[src]")) ||
    imageEl;
  return resolveBestImageUrlFromElement(img);
}

function pickImageResourceUrl(imageEl) {
  if (!imageEl) return "";
  if (isAdobeContributorHost()) {
    const adobeUrl = pickAdobeThumbnailResourceUrl(imageEl);
    if (adobeUrl) return adobeUrl;
  }
  if (isMagnificContributorHost()) {
    const magnificUrl = pickMagnificThumbnailResourceUrl(imageEl);
    if (magnificUrl) return magnificUrl;
  }
  if (isMiricanvasContributorHost()) {
    const miricanvasUrl = pickMiricanvasThumbnailResourceUrl(imageEl);
    if (miricanvasUrl) return miricanvasUrl;
  }
  if (isVecteezyContributorHost()) {
    const vecteezyUrl = pickVecteezyThumbnailResourceUrl(imageEl);
    if (vecteezyUrl) return vecteezyUrl;
  }
  if (isShutterstockContributorHost()) {
    const shutterstockUrl = pickShutterstockThumbnailResourceUrl(imageEl);
    if (shutterstockUrl) return shutterstockUrl;
  }
  return resolveBestImageUrlFromElement(imageEl);
}

async function loadImageElementFromUrl(resourceUrl) {
  const url = String(resourceUrl || "").trim();
  if (!url) throw new Error("URL gambar kosong.");
  if (url.startsWith("data:")) {
    const img = new Image();
    img.src = url;
    await img.decode?.().catch(() => sleep(80));
    return img;
  }
  const img = new Image();
  img.crossOrigin = "anonymous";
  await new Promise((resolve, reject) => {
    img.onload = () => resolve();
    img.onerror = () => reject(new Error("Gagal memuat gambar untuk analisis AI."));
    img.src = url;
  });
  return img;
}

async function fetchResourceUrlAsInlineData(resourceUrl) {
  const url = String(resourceUrl || "").trim();
  if (!url) throw new Error("URL gambar kosong.");

  if (url.startsWith("data:")) {
    const [header, data] = url.split(",", 2);
    const mimeMatch = /data:([^;]+);base64/i.exec(header || "");
    return {
      mimeType: mimeMatch?.[1] || "image/jpeg",
      data: data || ""
    };
  }

  let response = null;
  try {
    response = await fetch(url, { credentials: "include" });
  } catch (_error) {
    response = null;
  }
  if (response?.ok) {
    const blob = await response.blob();
    // Perkecil dulu; kalau tidak bisa, kirim byte aslinya.
    const shrunk = await shrinkImageBlobToInlineData(blob);
    if (shrunk) return shrunk;
    const base64 = await blobToBase64(blob);
    return {
      mimeType: blob.type || "image/jpeg",
      data: base64
    };
  }

  const proxy = await proxyFetchFromBackground({
    url,
    method: "GET",
    headers: {},
    credentials: "include",
    expectBinary: true
  });
  if (!proxy?.ok || !proxy?.base64) {
    throw new Error(String(proxy?.text || "Failed to fetch"));
  }

  const proxyMime = proxy.contentType || "image/jpeg";
  const proxyShrunk = await shrinkBase64Image(proxy.base64, proxyMime);
  if (proxyShrunk) return proxyShrunk;

  return {
    mimeType: proxyMime,
    data: proxy.base64
  };
}

/** Jalur proxy mengembalikan base64, bukan Blob — bungkus dulu agar bisa diperkecil. */
async function shrinkBase64Image(base64, mimeType) {
  try {
    const binary = atob(String(base64 || ""));
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return await shrinkImageBlobToInlineData(new Blob([bytes], { type: mimeType }));
  } catch (_e) {
    return null;
  }
}

async function imageElementToInlineData(imageEl, options = {}) {
  const preEncoded = options.pinnedInlineData || options.preEncodedInlineData;
  if (preEncoded?.data) return preEncoded;

  const pinnedUrl = String(options.pinnedUrl || options.pinnedImageUrl || "").trim();
  const fallbackUrls = (Array.isArray(options.fallbackUrls) ? options.fallbackUrls : [])
    .map((u) => String(u || "").trim())
    .filter(Boolean);
  const liveUrl = imageEl ? pickImageResourceUrl(imageEl) : "";
  const resourceUrl = pinnedUrl || liveUrl;
  if (!resourceUrl) {
    throw new Error("Gambar target tidak ditemukan.");
  }

  const urlCandidates = [...new Set([resourceUrl, ...fallbackUrls].filter(Boolean))];
  const pinnedMatchesLive = !pinnedUrl || !liveUrl || pinnedUrl === liveUrl;
  const preferFetch = Boolean(options.preferPinnedUrlFetch && pinnedUrl);

  if (!preferFetch && imageEl && (!pinnedUrl || pinnedMatchesLive)) {
    try {
      return await imageElementToInlineDataViaCanvas(imageEl);
    } catch (_error) {
      /* canvas gagal (tainted / belum load) — lanjut fetch */
    }
  }

  let lastError = null;
  for (const url of urlCandidates) {
    try {
      return await fetchResourceUrlAsInlineData(url);
    } catch (error) {
      lastError = error;
    }
  }

  throw new Error(
    `Gagal ambil gambar dari halaman (${lastError?.message || "Failed to fetch"}).`
  );
}

function extensionRuntime() {
  try {
    if (typeof chrome !== "undefined" && chrome.runtime) return chrome.runtime;
    if (typeof browser !== "undefined" && browser.runtime) return browser.runtime;
  } catch (_e) {
    /* ignore */
  }
  return null;
}

function formatTokenUsageForUi(usage) {
  if (!usage || typeof usage !== "object") return "";
  const p = usage.prompt;
  const c = usage.completion;
  const t = usage.total;
  if (t != null && p != null && c != null) return `Token: ${p}+${c}=${t}`;
  if (t != null) return `Token: ${t}`;
  if (p != null && c != null) return `Token: ${p}+${c}`;
  if (p != null) return `Token (prompt): ${p}`;
  if (c != null) return `Token (output): ${c}`;
  return "";
}

function addTokenUsageTotals(running, usage) {
  if (!usage) return running;
  const add =
    usage.total != null && Number.isFinite(usage.total)
      ? usage.total
      : usage.prompt != null && usage.completion != null
        ? usage.prompt + usage.completion
        : 0;
  return running + (Number.isFinite(add) ? add : 0);
}

// NERONA-WEB PROXY MAP: no_points -> "Poin habis. Isi ulang di dashboard Nerona."
// inactive -> "Paket tidak aktif." | missing_license -> "Hubungkan akun Nerona dulu (token)."
// payload_too_large -> "Gambar terlalu besar." | network/ai_error/other -> "Gagal generate via Nerona. Coba lagi."
function neronaGenerateErrorMessage(error) {
  const map = {
    no_points: "Poin habis. Isi ulang di dashboard Nerona.",
    inactive: "Paket tidak aktif.",
    missing_license: "Hubungkan akun Nerona dulu (token).",
    payload_too_large: "Gambar terlalu besar.",
    unauthorized: "Token akun Nerona tidak valid atau sudah dicabut. Hubungkan ulang di Profile nerona-web.",
    invalid_key: "Token akun Nerona tidak valid atau sudah dicabut. Hubungkan ulang di Profile nerona-web."
  };
  return map[error] || "Gagal generate via Nerona. Coba lagi.";
}

// Generation now routes through the nerona-web structured feature endpoint (metered
// by tenant points). Prompts are assembled server-side from the structured payload —
// the extension only sends feature inputs (marketplace, image, context, etc).
async function callGenerate(payload) {
  const r = await NeronaWebClient.generateFeature(payload);
  if (!r.ok) {
    const err = new Error(neronaGenerateErrorMessage(r.error));
    // Raw code kept on the error so batch callers can react (e.g. skip the rest
    // of the queue when the tenant runs out of points).
    err.neronaCode = r.error || "";
    throw err;
  }
  // Server-truth saldo, dikirim di setiap respons generate. Sebelumnya dibuang.
  setNeronaProgressPoints(r.pointsBalance);
  const usage = r.usage
    ? {
        prompt: r.usage.promptTokens || 0,
        completion: r.usage.completionTokens || 0,
        total: (r.usage.promptTokens || 0) + (r.usage.completionTokens || 0)
      }
    : null;
  return { text: r.content || "", usage };
}

function proxyFetchFromBackground(request) {
  return new Promise((resolve, reject) => {
    const rt = extensionRuntime();
    if (!rt?.sendMessage) {
      reject(new Error("Runtime ekstensi tidak tersedia. Muat ulang tab atau ekstensi Nerona."));
      return;
    }
    rt.sendMessage(
      {
        type: "NERONA_PROXY_FETCH",
        request
      },
      (response) => {
        const lastError = rt.lastError;
        if (lastError) {
          reject(new Error(lastError.message || "Background request gagal."));
          return;
        }
        if (!response) {
          reject(new Error("Tidak ada response dari background."));
          return;
        }
        resolve(response);
      }
    );
  });
}

function getCurrentCategoryText() {
  const categorySelect = firstMatch([
    'select[name*="category"]',
    'select[id*="category"]',
    '[data-testid*="category"] select'
  ]);
  return categorySelect?.selectedOptions?.[0]?.textContent?.trim() || "People";
}

function getCategoryOptionsText() {
  const categorySelect = firstMatch([
    'select[name*="category"]',
    'select[id*="category"]',
    '[data-testid*="category"] select'
  ]);
  if (!categorySelect) return [];
  return Array.from(categorySelect.options || [])
    .map((opt) => opt.textContent?.trim())
    .filter(Boolean);
}

function metadataFromParsedAi(parsed, fallback) {
  if (!parsed || typeof parsed !== "object") return fallback;
  const categories = parsed.categories && typeof parsed.categories === "object" ? parsed.categories : null;
  const aiTitle =
    parsed.title || parsed.optimizedTitle || parsed.fileName || (parsed.output && parsed.output.title);
  const aiDesc =
    parsed.description || parsed.stockDescription || (parsed.output && parsed.output.description);
  const aiKeywords =
    parsed.keywords || parsed.primaryKeywords || (parsed.output && parsed.output.keywords);
  return {
    fileName: aiTitle || fallback.fileName,
    description: aiDesc || fallback.description,
    keywords: Array.isArray(aiKeywords)
      ? aiKeywords.join(", ")
      : aiKeywords || fallback.keywords,
    category: categories?.main || parsed.category || fallback.category,
    subcategory: categories?.sub || parsed.subcategory || ""
  };
}

function sanitizeVecteezyTitle(value) {
  let title = String(value || "")
    .replace(/[_-]+/g, " ")
    .replace(/[^a-zA-Z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (!title) {
    title = "creative stock design illustration background";
  }

  let words = title
    .split(" ")
    .map((w) => w.trim().toLowerCase())
    .filter((w) => w && !VECTEEZY_PROHIBITED_KEYWORDS.has(w));

  const titleFillers = [
    "creative",
    "stock",
    "design",
    "illustration",
    "background",
    "modern",
    "colorful"
  ];
  let fillIdx = 0;
  while (words.length < VECTEEZY_TITLE_MIN_WORDS && fillIdx < titleFillers.length * 2) {
    const w = titleFillers[fillIdx % titleFillers.length];
    fillIdx += 1;
    if (!words.includes(w)) words.push(w);
  }
  if (words.length > VECTEEZY_TITLE_MAX_WORDS) {
    words = words.slice(0, VECTEEZY_TITLE_MAX_WORDS);
  }

  return words.join(" ").slice(0, VECTEEZY_TITLE_MAX_CHARS).trim();
}

function sanitizeVecteezyKeywords(value, fallbackTitle) {
  const merged = [];
  const seen = new Set();
  const pushWord = (w) => {
    const token = normalizeVecteezyKeywordLettersOnly(w);
    if (!token || !isReadableVecteezyKeyword(token)) return;
    if (seen.has(token)) return;
    seen.add(token);
    merged.push(token);
  };

  for (const w of expandVecteezyKeywordsToChipList(value)) {
    pushWord(w);
    if (merged.length >= VECTEEZY_KEYWORD_MAX) break;
  }

  if (merged.length < VECTEEZY_KEYWORD_MAX) {
    for (const w of expandVecteezyKeywordsToChipList(sanitizeVecteezyTitle(fallbackTitle))) {
      pushWord(w);
      if (merged.length >= VECTEEZY_KEYWORD_MAX) break;
    }
  }

  let fillIdx = 0;
  while (merged.length < 5 && fillIdx < VECTEEZY_KEYWORD_FILLER.length * 2) {
    const next = VECTEEZY_KEYWORD_FILLER[fillIdx % VECTEEZY_KEYWORD_FILLER.length];
    fillIdx += 1;
    pushWord(next);
    if (merged.length >= VECTEEZY_KEYWORD_MAX) break;
  }

  return merged.slice(0, VECTEEZY_KEYWORD_MAX).join(", ");
}

function normalizeMetadataForMarketplace(metadata, marketplace) {
  const m = metadata || {};
  const mp = String(marketplace || "").toLowerCase();

  if (mp === "vecteezy") {
    const safeTitle = sanitizeVecteezyTitle(
      m.fileName || m.description || "creative stock image"
    );
    return {
      ...m,
      fileName: safeTitle,
      keywords: sanitizeVecteezyKeywords(m.keywords, safeTitle),
      description: String(m.description || "").replace(/[^a-zA-Z0-9\s.,]/g, " ")
    };
  }

  return {
    ...m,
    keywords: sanitizeMarketplaceKeywordsComma(m.keywords, mp, {
      fallbackTitle: m.fileName,
      max: getMarketplaceKeywordMax(mp),
      augmentFromTitle: false
    })
  };
}

/** Token pendek untuk judul unik Vecteezy — jangan dipakai sebagai keyword chip. */
function vecteezyUniqueToken(seed) {
  let h = 2166136261;
  const s = String(seed);
  for (let i = 0; i < s.length; i += 1) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  const n = (h >>> 0).toString(36).replace(/[^a-z0-9]/gi, "");
  return `ref${n.slice(0, 5)}`;
}

/**
 * Memastikan judul Vecteezy unik dalam sesi upload (platform mengharuskan judul tidak dobel).
 * Jika bentrok, token pendek ditambahkan di akhir judul (judul detail tetap dipertahankan).
 */
function applyVecteezyUniqueFileName(metadata, usedTitleKeys, imageEl, batchIndex) {
  const norm = normalizeMetadataForMarketplace(metadata, "vecteezy");
  const keyOf = (t) => String(t || "").toLowerCase().replace(/\s+/g, " ").trim();

  let candidate = norm.fileName;
  if (!usedTitleKeys.has(keyOf(candidate))) {
    usedTitleKeys.add(keyOf(candidate));
    return norm;
  }

  const baseTitle = String(norm.fileName || "creative stock design illustration").trim();
  const src = pickImageResourceUrl(imageEl) || `batch${batchIndex}`;
  let salt = 0;
  do {
    const token = vecteezyUniqueToken(`${src}|${norm.fileName}|${salt}|${batchIndex}`);
    candidate = `${baseTitle} ${token}`.slice(0, VECTEEZY_TITLE_MAX_CHARS).trim();
    salt += 1;
    if (salt > 120) {
      candidate = `${baseTitle} ${vecteezyUniqueToken(`${Date.now()}|${Math.random()}`)}`
        .slice(0, VECTEEZY_TITLE_MAX_CHARS)
        .trim();
      break;
    }
  } while (usedTitleKeys.has(keyOf(candidate)));

  usedTitleKeys.add(keyOf(candidate));
  return normalizeMetadataForMarketplace({ ...metadata, fileName: candidate }, "vecteezy");
}

// Riwayat metadata dikirim SETELAH metadata final terbentuk: keyword yang benar
// benar diisi ke form baru ada setelah penyaringan visual dan pemotongan limit per
// marketplace, jadi mencatatnya dari respons server akan menyimpan daftar yang salah.
//
// Sengaja tidak di-await dan tidak pernah melempar — generate sudah selesai dan
// poinnya sudah terpakai; gagal mencatat riwayat bukan urusan yang perlu
// mengganggu user.
function logMetadataToNerona(marketplaceKey, metadata) {
  try {
    globalThis.NeronaWebClient?.logMetadata?.({
      marketplace: marketplaceKey,
      pageUrl: location.href,
      title: metadata?.fileName || "",
      keywords: metadata?.keywords || ""
    });
  } catch (_e) {
    /* abaikan */
  }
}

async function generateMetadataFromImage(marketplace, imageEl, progressCallback, options = {}) {
  const targetImage = imageEl || getLikelyAnalyzedImageElement();
  if (!targetImage) {
    throw new Error("Gambar tidak ditemukan. Pilih gambar lalu coba lagi.");
  }
  const fallbackTitle = normalizeTitle(targetImage?.alt || "Creative Stock Photo");
  const category = getCurrentCategoryText();
  const fallback = buildLocalMetadataFromPrompt(fallbackTitle, "", category);

  progressCallback?.("encode");
  const pinnedUrl =
    options.pinnedImageUrl ||
    options.pinnedUrl ||
    (isAdobeContributorHost() && targetImage ? pickAdobeThumbnailResourceUrl(targetImage) : "") ||
    (isMiricanvasContributorHost() && targetImage ? pickMiricanvasThumbnailResourceUrl(targetImage) : "") ||
    (isVecteezyContributorHost() && targetImage ? pickVecteezyThumbnailResourceUrl(targetImage) : "");
  const inlineData =
    options.pinnedInlineData?.data
      ? options.pinnedInlineData
      : await imageElementToInlineData(targetImage, {
          pinnedUrl,
          fallbackUrls: options.fallbackUrls,
          preferPinnedUrlFetch: options.preferPinnedUrlFetch
        });

  const promptMode = options.promptMode === "quick" ? "quick" : "advanced";

  progressCallback?.("ai");
  const aiResult = await callGenerate({
    feature: "metadata",
    marketplace,
    promptMode,
    batchIndex: options.batchIndex,
    image: { mime: inlineData.mimeType, dataBase64: inlineData.data }
  });
  progressCallback?.("usage", aiResult.usage);
  const text = aiResult.text || "";
  const parsed = safeJsonParse(text || "") || safeJsonParse(JSON.stringify(fallback));
  const metadata = metadataFromParsedAi(parsed, fallback);

  const aiKeywordCount = Array.isArray(parsed?.keywords)
    ? parsed.keywords.length
    : String(metadata.keywords || "").split(",").filter(Boolean).length;

  const groundedKeywordsComma = filterKeywordsByVisualGrounding(
    parsed,
    typeof metadata.keywords === "string"
      ? metadata.keywords
      : Array.isArray(metadata.keywords)
        ? metadata.keywords.join(", ")
        : ""
  );

  const marketplaceKey =
    options.marketplaceKey || resolveMarketplaceKeyFromLabel(marketplace);

  const keywordLimits =
    marketplaceKey === "vecteezy"
      ? { min: 10, max: VECTEEZY_KEYWORD_MAX, skipTitleAugment: true }
      : marketplaceKey === "miricanvas"
        ? {
            min: MIRICANVAS_KEYWORD_MAX,
            max: MIRICANVAS_KEYWORD_MAX,
            skipTitleAugment: aiKeywordCount >= 22
          }
        : marketplaceKey === "magnific"
          ? {
              min: MAGNIFIC_KEYWORD_MAX,
              max: MAGNIFIC_KEYWORD_MAX,
              skipTitleAugment: aiKeywordCount >= 45
            }
          : marketplaceKey === "shutterstock"
            ? {
                min: SHUTTERSTOCK_KEYWORD_MAX,
                max: SHUTTERSTOCK_KEYWORD_MAX,
                skipTitleAugment: aiKeywordCount >= 45
              }
            : { min: 50, max: 50, skipTitleAugment: aiKeywordCount >= 40 };

  const draft = {
    ...metadata,
    keywords: normalizeKeywordsForStock(groundedKeywordsComma || metadata.keywords, metadata.fileName, {
      ...keywordLimits,
      marketplaceKey
    }),
    extra: parsed && typeof parsed === "object" ? parsed : null,
    tokenUsage: aiResult.usage || null
  };

  const finalMetadata = normalizeMetadataForMarketplace(draft, marketplaceKey);
  logMetadataToNerona(marketplaceKey, finalMetadata);
  return finalMetadata;
}

function showNeronaToast(text) {
  const toastId = "nerona-metadata-toast";
  let el = document.getElementById(toastId);
  if (!el) {
    el = document.createElement("div");
    el.id = toastId;
    el.style.position = "fixed";
    el.style.right = "20px";
    el.style.bottom = "86px";
    el.style.padding = "10px 12px";
    el.style.background = "#111827";
    el.style.color = "#e5e7eb";
    el.style.border = "1px solid #374151";
    el.style.borderRadius = "8px";
    el.style.zIndex = "2147483647";
    el.style.fontSize = "12px";
    document.body.appendChild(el);
  }
  el.textContent = text;
  window.clearTimeout(el._hideTimer);
  el._hideTimer = window.setTimeout(() => {
    if (el) el.remove();
  }, 2600);
}

function ensureNeronaProgressPanel() {
  const panelId = "nerona-metadata-progress";
  let panel = document.getElementById(panelId);

  const layoutProgressPanel = (el) => {
    el.style.position = "fixed";
    el.style.left = "50%";
    el.style.right = "auto";
    el.style.bottom = "24px";
    el.style.transform = "translateX(-50%)";
    el.style.width = "min(520px, 94vw)";
    el.style.maxHeight = "50vh";
    el.style.overflow = "auto";
    el.style.zIndex = "2147483647";
    el.style.background = "#0b1220";
    el.style.border = "1px solid #334155";
    el.style.borderRadius = "12px";
    el.style.boxShadow = "0 30px 80px rgba(0,0,0,0.55)";
    el.style.padding = "10px";
  };

  if (panel) {
    layoutProgressPanel(panel);
    return panel;
  }

  panel = document.createElement("div");
  panel.id = panelId;
  panel.setAttribute("data-nerona-overlay", "1");
  layoutProgressPanel(panel);

  panel.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px;">
      <div id="nerona-progress-title" style="font-size:12px;font-weight:800;color:#e2e8f0;">Progress Generate Metadata</div>
      <div id="nerona-progress-points" style="font-size:11px;font-weight:700;color:#94a3b8;margin-left:auto;white-space:nowrap;"></div>
      <button type="button" id="nerona-progress-close" style="background:#1e293b;color:#e2e8f0;border:1px solid #334155;border-radius:8px;padding:6px 10px;cursor:pointer;">Tutup</button>
    </div>
    <div style="height:8px;background:#0f172a;border:1px solid #1e293b;border-radius:999px;overflow:hidden;margin-bottom:8px;">
      <div id="nerona-progress-bar" style="height:100%;width:0%;background:linear-gradient(135deg,#2563eb,#7c3aed);"></div>
    </div>
    <div id="nerona-progress-sub" style="font-size:11px;color:#94a3b8;margin-bottom:8px;"></div>
    <div id="nerona-progress-list" style="display:flex;flex-direction:column;gap:8px;"></div>
  `;

  // Panel baru dibangun: pakai saldo yang sudah diketahui (dari gerbang akses atau
  // generate sebelumnya) supaya angkanya ada sejak frame pertama.
  renderNeronaProgressPoints();

  panel.querySelector("#nerona-progress-close")?.addEventListener("click", () => {
    panel.remove();
  });

  document.body.appendChild(panel);
  return panel;
}

function setNeronaProgressBar(current, total) {
  const panel = ensureNeronaProgressPanel();
  const bar = panel.querySelector("#nerona-progress-bar");
  if (!bar) return;
  const safeTotal = Math.max(0, Number(total) || 0);
  const safeCurrent = Math.max(0, Number(current) || 0);
  const pct = safeTotal > 0 ? Math.max(0, Math.min(100, Math.round((safeCurrent / safeTotal) * 100))) : 0;
  bar.style.width = `${pct}%`;
}

function setNeronaProgressSubtext(text) {
  const panel = ensureNeronaProgressPanel();
  const el = panel.querySelector("#nerona-progress-sub");
  if (el) el.textContent = text || "";
}

/**
 * Ambang peringatan saldo poin, diturunkan dari BATCH_MAX_ITEMS (50) dengan
 * perkiraan ~5 poin per gambar — jadi di bawah LOW satu batch penuh berisiko
 * berhenti di tengah, dan di bawah CRITICAL tidak cukup untuk 10 gambar.
 * Perkiraan itu bukan hasil pengukuran (biaya nyata ikut ukuran gambar & model),
 * jadi kedua angka ini sengaja ditaruh berdampingan supaya mudah disetel ulang.
 */
const NERONA_POINTS_LOW = 250;
const NERONA_POINTS_CRITICAL = 50;

/** Saldo terakhir yang diketahui, supaya panel bisa langsung menampilkannya saat dibuat. */
let neronaLastKnownPoints = null;

/**
 * Menulis saldo ke header panel progress KALAU panelnya sedang ada. Tidak pernah
 * memanggil ensureNeronaProgressPanel — fungsi itu MEMBUAT panel, dan memunculkan
 * panel progress hanya untuk memperbarui angka akan mengubah perilaku generate
 * gambar tunggal.
 *
 * Elemennya sendiri, BUKAN di dalam #nerona-progress-sub: baris sub itu satu string
 * yang ditimpa utuh dari 17 pemanggil setNeronaProgressSubtext, jadi saldo yang
 * dititipkan di sana akan terhapus oleh pemanggil mana pun yang lupa
 * menempelkannya kembali.
 */
function renderNeronaProgressPoints() {
  const n = neronaLastKnownPoints;
  if (!Number.isFinite(n)) return;
  const el = document.getElementById("nerona-progress-points");
  if (!el) return;
  el.textContent = `● ${n.toLocaleString("id-ID")} poin`;
  el.style.color =
    n < NERONA_POINTS_CRITICAL ? "#fca5a5" : n < NERONA_POINTS_LOW ? "#fcd34d" : "#94a3b8";
  el.title =
    n < NERONA_POINTS_LOW
      ? "Poin menipis — batch besar bisa berhenti di tengah. Isi ulang di dashboard Nerona."
      : "Sisa poin akun Nerona Anda.";
}

function setNeronaProgressPoints(balance) {
  // null/"" ditolak eksplisit: Number(null) === 0, jadi tanpa ini saldo yang tidak
  // diketahui akan tampil "0 poin" merah — memberi tahu pengguna poinnya habis
  // padahal yang sebenarnya terjadi adalah datanya tidak ada.
  if (balance === null || balance === undefined || balance === "") return;
  const n = Number(balance);
  if (!Number.isFinite(n)) return;
  neronaLastKnownPoints = n;
  renderNeronaProgressPoints();
}

function progressKeyForImage(imgEl, index) {
  const src = String(imgEl?.currentSrc || imgEl?.src || "");
  return `${index}:${src.slice(0, 180)}`;
}

function upsertProgressItem(imgEl, index, patch) {
  const panel = ensureNeronaProgressPanel();
  const list = panel.querySelector("#nerona-progress-list");
  if (!list) return;

  const key = progressKeyForImage(imgEl, index);
  let row = list.querySelector(`[data-key="${CSS.escape(key)}"]`);
  if (!row) {
    row = document.createElement("div");
    row.setAttribute("data-key", key);
    row.style.display = "grid";
    row.style.gridTemplateColumns = "84px 1fr";
    row.style.gap = "10px";
    row.style.alignItems = "start";
    row.style.padding = "8px";
    row.style.border = "1px solid #1e293b";
    row.style.borderRadius = "10px";
    row.style.background = "#0f172a";

    const thumbSrc = String(imgEl?.currentSrc || imgEl?.src || "");
    const name = getImageDisplayName(imgEl, index);
    row.innerHTML = `
      <img src="${thumbSrc}" alt="" style="width:84px;height:54px;object-fit:cover;border-radius:8px;border:1px solid #1e293b;" />
      <div>
        <div data-role="name" style="font-size:11px;color:#cbd5e1;line-height:1.25;margin-bottom:2px;"></div>
        <div data-role="status" style="font-size:11px;color:#93c5fd;margin-bottom:4px;"></div>
        <div data-role="title" style="font-size:12px;font-weight:800;color:#e2e8f0;margin-bottom:4px;"></div>
        <div data-role="keywords" style="font-size:11px;color:#a7b2c7;line-height:1.35;"></div>
        <div data-role="tokens" style="font-size:10px;color:#64748b;margin-top:4px;"></div>
      </div>
    `;
    row.querySelector('[data-role="name"]').textContent = name;
    list.appendChild(row);
  }

  const setText = (role, value) => {
    const el = row.querySelector(`[data-role="${role}"]`);
    if (el) el.textContent = value || "";
  };

  if (patch?.status !== undefined) setText("status", patch.status);
  if (patch?.title !== undefined) setText("title", patch.title);
  if (patch?.keywords !== undefined) setText("keywords", patch.keywords);
  if (patch?.tokens !== undefined) setText("tokens", patch.tokens);
}

function getNeronaLogoUrl() {
  try {
    const rt = extensionRuntime();
    return rt?.getURL ? rt.getURL("icons/icon48.png") : "";
  } catch (_e) {
    return "";
  }
}

const NERONA_ACTION_ICON_SVG = {
  scoring: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3v18h18"/><path d="M7 16v-3"/><path d="M12 16V8"/><path d="M17 16v-6"/></svg>`,
  commercial: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 6v12"/><path d="M15 9.5a3.5 3.5 0 1 0-6 0"/><path d="M9 14.5h6"/></svg>`,
  keyword: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><path d="M7 7h.01"/></svg>`,
  toggleCollapse: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 15l-6-6-6 6"/></svg>`,
  toggleExpand: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>`,
  spinner: `<svg class="nerona-spin" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M12 2v4"/><path d="M12 18v4"/><path d="m4.93 4.93 2.83 2.83"/><path d="m16.24 16.24 2.83 2.83"/><path d="M2 12h4"/><path d="M18 12h4"/><path d="m4.93 19.07 2.83-2.83"/><path d="m16.24 7.76 2.83-2.83"/></svg>`
};

function ensureNeronaSpinnerStyles() {
  if (document.getElementById("nerona-spinner-style")) return;
  const style = document.createElement("style");
  style.id = "nerona-spinner-style";
  style.textContent =
    "@keyframes nerona-spin{to{transform:rotate(360deg)}}.nerona-spin{animation:nerona-spin .85s linear infinite;display:inline-block;}";
  document.head.appendChild(style);
}

function neronaActionIconMarkup(iconType) {
  return NERONA_ACTION_ICON_SVG[iconType] || "";
}

/** Tombol aksi: ikon SVG + label (label bisa di-update terpisah). */
function decorateNeronaActionButton(button, options = {}) {
  if (!button) return;
  const label = String(options.label || "").trim();
  const iconType = options.iconType || "";
  const labelAttr = options.labelAttr || "data-nerona-action-label";

  if (label) {
    button.setAttribute("data-nerona-action-label-text", label);
    button.title = label;
    button.setAttribute("aria-label", label);
  }

  button.textContent = "";
  button.style.display = "inline-flex";
  button.style.alignItems = "center";
  button.style.justifyContent = "center";
  button.style.gap = "8px";

  let iconWrap = button.querySelector("[data-nerona-action-icon]");
  if (!iconWrap) {
    iconWrap = document.createElement("span");
    iconWrap.setAttribute("data-nerona-action-icon", "1");
    iconWrap.style.display = "inline-flex";
    iconWrap.style.alignItems = "center";
    iconWrap.style.flexShrink = "0";
    button.appendChild(iconWrap);
  }
  if (iconType) {
    iconWrap.setAttribute("data-icon-type", iconType);
    iconWrap.innerHTML = neronaActionIconMarkup(iconType);
  }

  if (label) {
    let span = button.querySelector(`[${labelAttr}]`);
    if (!span) {
      span = document.createElement("span");
      span.setAttribute(labelAttr, "1");
      button.appendChild(span);
    }
    span.textContent = label;
  }
}

function decorateFloatingBarToggleButton(button, collapsed) {
  if (!button) return;
  const title = collapsed ? "Tampilkan tools" : "Sembunyikan tools";
  button.title = title;
  button.setAttribute("aria-label", title);
  button.setAttribute("aria-expanded", collapsed ? "false" : "true");
  button.textContent = "";

  let iconWrap = button.querySelector("[data-nerona-toggle-icon]");
  if (!iconWrap) {
    iconWrap = document.createElement("span");
    iconWrap.setAttribute("data-nerona-toggle-icon", "1");
    iconWrap.style.display = "inline-flex";
    iconWrap.style.alignItems = "center";
    iconWrap.style.justifyContent = "center";
    button.appendChild(iconWrap);
  }
  iconWrap.innerHTML = neronaActionIconMarkup(collapsed ? "toggleExpand" : "toggleCollapse");
}

function setNeronaActionButtonProgress(button, stepText) {
  if (!button) return;
  ensureNeronaSpinnerStyles();
  const base =
    button.getAttribute("data-nerona-action-label-text") ||
    button.getAttribute("data-nerona-gen-default-label") ||
    "Memproses";
  const span = button.querySelector("[data-nerona-action-label]");
  if (span) {
    span.textContent = stepText ? `${base} (${stepText})` : `${base} (Memproses…)`;
  }
  const iconWrap = button.querySelector("[data-nerona-action-icon]");
  if (iconWrap) {
    iconWrap.innerHTML = neronaActionIconMarkup("spinner");
  }
  button.setAttribute("aria-busy", "true");
}

function resetNeronaActionButton(button) {
  if (!button) return;
  const label = button.getAttribute("data-nerona-action-label-text") || "";
  const iconType =
    button.id === "nerona-keyword-ai-btn"
      ? "keyword"
      : button.id === "nerona-ai-scoring-btn"
        ? "scoring"
        : button.id === "nerona-commercial-intent-btn"
          ? "commercial"
          : "";
  if (label && iconType) {
    decorateNeronaActionButton(button, { label, iconType });
  }
  button.removeAttribute("aria-busy");
}

const KEYWORD_AI_PROGRESS_DEFAULT_TITLE = "Progress Generate Metadata";

function beginKeywordAiProgressPanel(months) {
  const panel = ensureNeronaProgressPanel();
  let titleEl = panel.querySelector("#nerona-progress-title");
  if (!titleEl) {
    const fallback = panel.querySelector("div[style*='font-weight:800']");
    if (fallback) {
      fallback.id = "nerona-progress-title";
      titleEl = fallback;
    }
  }
  if (titleEl) {
    titleEl.setAttribute("data-prev-title", titleEl.textContent || KEYWORD_AI_PROGRESS_DEFAULT_TITLE);
    titleEl.textContent = "Keyword AI — riset tren";
  }
  setNeronaProgressBar(0, 100);
  setKeywordAiProgressPanel("prepare", months, "");
  return panel;
}

function setKeywordAiProgressPanel(phase, months, tokenLine) {
  const panel = document.getElementById("nerona-metadata-progress");
  if (!panel) return;

  const steps = {
    license: { pct: 12, text: "Memeriksa lisensi…" },
    prepare: { pct: 28, text: "Menyiapkan riset keyword & event…" },
    ai: {
      pct: 72,
      text: `Riset AI: ${months?.current || "bulan ini"} & ${months?.next || "bulan depan"}…`
    },
    parse: { pct: 92, text: "Memproses hasil JSON…" },
    done: { pct: 100, text: "Selesai." },
    error: { pct: 100, text: "Gagal." }
  };
  const step = steps[phase] || steps.prepare;
  setNeronaProgressBar(step.pct, 100);
  const extra = tokenLine ? ` · ${tokenLine}` : "";
  setNeronaProgressSubtext(`${step.text}${extra}`);

  let row = panel.querySelector("[data-keyword-ai-progress-row]");
  const list = panel.querySelector("#nerona-progress-list");
  if (!row && list) {
    row = document.createElement("div");
    row.setAttribute("data-keyword-ai-progress-row", "1");
    Object.assign(row.style, {
      padding: "10px 12px",
      border: "1px solid #1e293b",
      borderRadius: "10px",
      background: "#0f172a"
    });
    row.innerHTML = `
      <div data-role="status" style="font-size:12px;color:#93c5fd;margin-bottom:6px;"></div>
      <div data-role="detail" style="font-size:11px;color:#a7b2c7;line-height:1.4;"></div>
    `;
    list.prepend(row);
  }
  if (row) {
    const statusEl = row.querySelector('[data-role="status"]');
    const detailEl = row.querySelector('[data-role="detail"]');
    if (statusEl) statusEl.textContent = step.text;
    if (detailEl) {
      detailEl.textContent =
        phase === "ai"
          ? "Menganalisis peluang microstock untuk bulan berjalan dan bulan berikutnya."
          : phase === "done"
            ? "Panel hasil akan dibuka otomatis."
            : phase === "error"
              ? String(months?.error || "Terjadi kesalahan.")
              : "Mohon tunggu, jangan tutup tab.";
    }
  }
}

function endKeywordAiProgressPanel(keepOpen) {
  const panel = document.getElementById("nerona-metadata-progress");
  const titleEl = panel?.querySelector("#nerona-progress-title");
  if (titleEl) {
    titleEl.textContent =
      titleEl.getAttribute("data-prev-title") || KEYWORD_AI_PROGRESS_DEFAULT_TITLE;
    titleEl.removeAttribute("data-prev-title");
  }
  if (!keepOpen) {
    panel?.querySelector("[data-keyword-ai-progress-row]")?.remove();
  }
}

/** Isi tombol floating dengan logo Nerona + label (span terpisah agar progress tidak menghapus gambar). */
function decorateGenerateButtonContents(button, labelText) {
  if (!button) return;
  const label = String(labelText || "Generate Metadata").trim() || "Generate Metadata";
  button.setAttribute("data-nerona-gen-default-label", label);
  const url = getNeronaLogoUrl();
  button.textContent = "";
  button.style.display = "inline-flex";
  button.style.alignItems = "center";
  button.style.gap = "8px";
  if (url) {
    const img = document.createElement("img");
    img.src = url;
    img.alt = "Nerona";
    img.style.height = "26px";
    img.style.width = "auto";
    img.style.maxWidth = "96px";
    img.style.borderRadius = "6px";
    img.style.objectFit = "contain";
    img.style.flexShrink = "0";
    img.draggable = false;
    img.setAttribute("data-nerona-btn-logo", "1");
    button.appendChild(img);
  }
  const span = document.createElement("span");
  span.setAttribute("data-nerona-gen-label", "1");
  span.textContent = label;
  button.appendChild(span);
}

function setGenerateProgress(button, stepText) {
  if (!button) return;
  const base =
    button.getAttribute("data-nerona-gen-default-label") || "Generate Metadata";
  const span = button.querySelector("[data-nerona-gen-label]");
  if (span) {
    span.textContent = `${base} (${stepText})`;
    return;
  }
  button.textContent = `${base} (${stepText})`;
}

function resetGenerateProgress(button) {
  if (!button) return;
  const base =
    button.getAttribute("data-nerona-gen-default-label") || "Generate Metadata";
  const span = button.querySelector("[data-nerona-gen-label]");
  if (span) {
    span.textContent = base;
    return;
  }
  button.textContent = base;
}

function isQuotaLimitError(statusCode, detailText) {
  if (statusCode === 429) return true;
  const txt = String(detailText || "").toLowerCase();
  return (
    txt.includes("quota") ||
    txt.includes("resource_exhausted") ||
    txt.includes("rate limit") ||
    txt.includes("limit exceeded") ||
    txt.includes("too many requests")
  );
}

function styleGenerateButton(button) {
  if (!button) return;
  button.style.background = "linear-gradient(135deg,#2563eb,#7c3aed)";
  button.style.color = "#fff";
  button.style.border = "1px solid rgba(255,255,255,0.25)";
  button.style.borderRadius = "999px";
  button.style.padding = "10px 16px 10px 12px";
  button.style.fontWeight = "700";
  button.style.cursor = "pointer";
  button.style.letterSpacing = "0.2px";
  button.style.boxShadow = "0 14px 32px rgba(37,99,235,0.35)";
}

function styleGenerateQuickButton(button) {
  styleGenerateButton(button);
}

function styleGenerateAdvancedButton(button) {
  if (!button) return;
  button.style.background = "linear-gradient(135deg,#6d28d9,#be185d)";
  button.style.color = "#fff";
  button.style.border = "1px solid rgba(255,255,255,0.28)";
  button.style.borderRadius = "999px";
  button.style.padding = "10px 16px 10px 12px";
  button.style.fontWeight = "700";
  button.style.cursor = "pointer";
  button.style.letterSpacing = "0.2px";
  button.style.boxShadow = "0 14px 32px rgba(109,40,217,0.38)";
}

function styleRemoveMetadataButton(button) {
  if (!button) return;
  button.style.background = "linear-gradient(135deg,#b91c1c,#9f1239)";
  button.style.color = "#fff";
  button.style.border = "1px solid rgba(255,255,255,0.22)";
  button.style.borderRadius = "999px";
  button.style.padding = "10px 18px";
  button.style.fontWeight = "700";
  button.style.cursor = "pointer";
  button.style.letterSpacing = "0.2px";
  button.style.boxShadow = "0 14px 28px rgba(185,28,28,0.35)";
}

function styleFloatingActionBar(container) {
  container.style.position = "fixed";
  container.style.left = "auto";
  container.style.right = "20px";
  container.style.bottom = "20px";
  container.style.transform = "none";
  container.style.zIndex = "2147483647";
  container.style.display = "flex";
  container.style.flexDirection = "column";
  container.style.alignItems = "stretch";
  container.style.gap = "10px";
  container.style.width = "220px";
  container.style.maxWidth = "min(220px, calc(100vw - 40px))";
  container.style.minWidth = "0";
  container.style.boxSizing = "border-box";
  container.style.pointerEvents = "auto";
}

function styleKeywordAiButton(button) {
  if (!button) return;
  button.style.background = "linear-gradient(135deg,#d97706,#ea580c)";
  button.style.color = "#fff";
  button.style.border = "1px solid rgba(255,255,255,0.25)";
  button.style.borderRadius = "999px";
  button.style.padding = "10px 14px";
  button.style.fontWeight = "700";
  button.style.cursor = "pointer";
  button.style.letterSpacing = "0.2px";
  button.style.boxShadow = "0 14px 28px rgba(234,88,12,0.35)";
  button.style.width = "100%";
  button.style.whiteSpace = "nowrap";
}

function styleCommercialIntentButton(button) {
  if (!button) return;
  button.style.background = "linear-gradient(135deg,#7c3aed,#4f46e5)";
  button.style.color = "#fff";
  button.style.border = "1px solid rgba(255,255,255,0.25)";
  button.style.borderRadius = "999px";
  button.style.padding = "10px 16px";
  button.style.fontWeight = "700";
  button.style.cursor = "pointer";
  button.style.letterSpacing = "0.15px";
  button.style.boxShadow = "0 14px 28px rgba(79,70,229,0.38)";
  button.style.width = "100%";
  button.style.fontSize = "12px";
  button.style.whiteSpace = "nowrap";
}

function styleScoringAgentButton(button) {
  if (!button) return;
  button.style.background = "linear-gradient(135deg,#059669,#0d9488)";
  button.style.color = "#fff";
  button.style.border = "1px solid rgba(255,255,255,0.22)";
  button.style.borderRadius = "999px";
  button.style.padding = "10px 18px";
  button.style.fontWeight = "700";
  button.style.cursor = "pointer";
  button.style.letterSpacing = "0.2px";
  button.style.boxShadow = "0 14px 28px rgba(5,150,105,0.38)";
  button.style.width = "100%";
  button.style.whiteSpace = "nowrap";
}

function styleFloatingBarToggleButton(button) {
  if (!button) return;
  button.style.background = "#1e293b";
  button.style.color = "#e2e8f0";
  button.style.border = "1px solid #475569";
  button.style.borderRadius = "12px";
  button.style.padding = "0";
  button.style.width = "42px";
  button.style.height = "42px";
  button.style.minWidth = "42px";
  button.style.display = "inline-flex";
  button.style.alignItems = "center";
  button.style.justifyContent = "center";
  button.style.cursor = "pointer";
  button.style.alignSelf = "flex-end";
  button.style.flexShrink = "0";
}

function readFloatingBarCollapsedState() {
  try {
    return sessionStorage.getItem("nerona_floating_bar_collapsed") === "1";
  } catch (_e) {
    return false;
  }
}

function setFloatingBarActionsCollapsed(collapsed) {
  const wrap = document.getElementById("nerona-floating-actions-wrap");
  const toggle = document.getElementById("nerona-floating-bar-toggle");
  if (wrap) {
    wrap.style.display = collapsed ? "none" : "flex";
  }
  if (toggle) {
    decorateFloatingBarToggleButton(toggle, collapsed);
  }
  try {
    sessionStorage.setItem("nerona_floating_bar_collapsed", collapsed ? "1" : "0");
  } catch (_e) {
    /* ignore */
  }
}

function ensureFloatingActionsWrap(bar) {
  let wrap = document.getElementById("nerona-floating-actions-wrap");
  if (!wrap) {
    wrap = document.createElement("div");
    wrap.id = "nerona-floating-actions-wrap";
    wrap.style.display = "flex";
    wrap.style.flexDirection = "column";
    wrap.style.gap = "10px";
    wrap.style.width = "100%";
  }
  const toggle = document.getElementById("nerona-floating-bar-toggle");
  if (toggle && toggle.parentElement === bar) {
    if (toggle.nextElementSibling !== wrap) {
      bar.insertBefore(wrap, toggle.nextElementSibling);
    }
  } else if (!wrap.parentElement) {
    bar.appendChild(wrap);
  }
  return wrap;
}

function installFloatingBarToggle(bar) {
  let toggle = document.getElementById("nerona-floating-bar-toggle");
  if (!toggle) {
    toggle = document.createElement("button");
    toggle.id = "nerona-floating-bar-toggle";
    toggle.type = "button";
    toggle.setAttribute("aria-controls", "nerona-floating-actions-wrap");
    styleFloatingBarToggleButton(toggle);
    styleFloatingBarToggleButton(toggle);
    toggle.addEventListener("click", () => {
      setFloatingBarActionsCollapsed(!readFloatingBarCollapsedState());
    });
    bar.insertBefore(toggle, bar.firstChild);
  } else if (toggle.parentElement !== bar || bar.firstChild !== toggle) {
    bar.insertBefore(toggle, bar.firstChild);
  }
  styleFloatingBarToggleButton(toggle);
  setFloatingBarActionsCollapsed(readFloatingBarCollapsedState());
  return toggle;
}

function getEventKeywordResearchMonthContext() {
  const now = new Date();
  const current = now.toLocaleString("en-US", { month: "long", year: "numeric" });
  const nextDate = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const next = nextDate.toLocaleString("en-US", { month: "long", year: "numeric" });
  return { current, next };
}

/** Batch generate/remove dapat dihentikan lewat tombol Stop */
const neronaBatchControl = {
  cancelled: false,
  reset() {
    this.cancelled = false;
  },
  abort() {
    this.cancelled = true;
  },
  isAborted() {
    return this.cancelled;
  }
};

function ensureStopOperationButton() {
  let el = document.getElementById("nerona-operation-stop-btn");
  if (el) return el;
  el = document.createElement("button");
  el.id = "nerona-operation-stop-btn";
  el.type = "button";
  el.textContent = "Stop";
  el.style.display = "none";
  el.style.position = "fixed";
  el.style.zIndex = "2147483648";
  el.style.right = "20px";
  el.style.bottom = "76px";
  el.style.padding = "8px 16px";
  el.style.borderRadius = "10px";
  el.style.border = "1px solid #f87171";
  el.style.background = "#450a0a";
  el.style.color = "#fecaca";
  el.style.fontWeight = "700";
  el.style.fontSize = "12px";
  el.style.cursor = "pointer";
  el.style.boxShadow = "0 8px 20px rgba(0,0,0,0.45)";
  el.addEventListener("click", () => {
    neronaBatchControl.abort();
    showNeronaToast("Menghentikan…");
  });
  document.body.appendChild(el);
  return el;
}

function showStopOperationButton() {
  ensureStopOperationButton().style.display = "block";
}

function hideStopOperationButton() {
  const el = document.getElementById("nerona-operation-stop-btn");
  if (el) el.style.display = "none";
}

function decorateRemoveButtonContents(button) {
  if (!button) return;
  button.textContent = "";
  button.style.display = "inline-flex";
  button.style.alignItems = "center";
  button.style.gap = "6px";
  const span = document.createElement("span");
  span.setAttribute("data-nerona-remove-label", "1");
  span.textContent = "Remove Metadata";
  button.appendChild(span);
}

function setRemoveProgress(button, stepText) {
  if (!button) return;
  const span = button.querySelector("[data-nerona-remove-label]");
  if (span) {
    span.textContent = `Remove Metadata (${stepText})`;
    return;
  }
  button.textContent = `Remove Metadata (${stepText})`;
}

function resetRemoveProgress(button) {
  if (!button) return;
  const span = button.querySelector("[data-nerona-remove-label]");
  if (span) {
    span.textContent = "Remove Metadata";
    return;
  }
  button.textContent = "Remove Metadata";
}

function firstMatchInScope(scope, selectors) {
  if (!scope) return null;
  const scoped = firstMetadataField(selectors, scope);
  if (scoped) return scoped;
  for (const selector of selectors) {
    let matches;
    try {
      matches = Array.from(scope.querySelectorAll(selector));
    } catch (_e) {
      continue;
    }
    const visible = matches.find(
      (el) =>
        isFormFieldVisible(el) && !isInsideNeronaOverlay(el) && !isLikelyNoiseMetadataField(el)
    );
    if (visible) return visible;
    const fallback = matches.find((el) => !isInsideNeronaOverlay(el) && !isLikelyNoiseMetadataField(el));
    if (fallback) return fallback;
  }
  return null;
}

function findAdobeRowForImage(imgEl) {
  if (!imgEl) return null;
  if (isVecteezyContributorHost()) {
    const card = findVecteezyResourceCardForImage(imgEl);
    if (card) return card;
  }
  const rowSelectorMatch = (el) =>
    el.matches?.(
      '[role="row"], [role="listitem"], tr, li, article, [data-testid*="asset" i], [data-testid*="row" i], [data-testid*="card" i], [class*="asset" i], [class*="Asset" i], [class*="row" i], [class*="Row" i], [class*="card" i], [class*="Card" i], [class*="item" i], [class*="Item" i]'
    );

  let el = imgEl.parentElement;
  let bestWithFields = null;
  for (let d = 0; d < 16 && el; d += 1) {
    if (isInsideNeronaOverlay(el)) break;
    const looksLikeRow = rowSelectorMatch(el);
    const hasFormField =
      el.querySelector?.('input[type="text"], input:not([type]), textarea, [contenteditable="true"]');
    if (looksLikeRow && hasFormField) {
      return el;
    }
    if (hasFormField && !bestWithFields) {
      bestWithFields = el;
    }
    el = el.parentElement;
  }
  return bestWithFields;
}

/** Kartu/baris kontributor untuk gambar (fallback bila baris ditolak tidak punya field metadata). */
function findContributorAssetScopeForImage(imgEl) {
  if (!imgEl) return null;
  const primary = findAdobeRowForImage(imgEl);
  if (primary) return primary;
  let el = imgEl.parentElement;
  for (let d = 0; d < 14 && el; d += 1) {
    if (isInsideNeronaOverlay(el)) break;
    if (
      el.matches?.(
        '[role="row"], [role="listitem"], tr, li, article, [data-testid*="asset" i], [data-testid*="card" i], [class*="asset" i], [class*="Asset" i], [class*="card" i], [class*="Card" i]'
      )
    ) {
      return el;
    }
    el = el.parentElement;
  }
  return imgEl.parentElement;
}

const NERONA_REJECT_PROBLEM_STATUS_RE = new RegExp(
  [
    "\\brejected\\b",
    "\\brejection\\b",
    "\\bdeclined\\b",
    "\\bdenied\\b",
    "\\bditolak\\b",
    "\\btidak diterima\\b",
    "\\bnot approved\\b",
    "\\bnot accepted\\b",
    "\\bwasn'?t accepted\\b"
  ].join("|"),
  "i"
);

/** Status jelas positif — jangan tampilkan jika hanya teks approved/published tanpa rejected/ditolak. */
const NERONA_APPROVED_ONLY_STATUS_RE = new RegExp(
  [
    "\\bapproved\\b",
    "\\baccepted\\b",
    "\\bpublished\\b",
    "\\bactive\\b",
    "\\blive\\b",
    "\\bavailable\\b",
    "\\bdisetujui\\b",
    "\\bdipublikasikan\\b",
    "\\blulus\\b",
    "\\bready to publish\\b",
    "\\bsuccessfully\\s+published\\b"
  ].join("|"),
  "i"
);

function collectScopeStatusBlob(scopeEl) {
  if (!scopeEl) return "";
  const attrBits = [];
  try {
    const max = 140;
    const nodes = scopeEl.querySelectorAll(
      "[class],[data-testid],[aria-label],[title],[data-status],[role='status'],[data-state]"
    );
    const n = Math.min(nodes.length, max);
    for (let i = 0; i < n; i += 1) {
      const node = nodes[i];
      attrBits.push(
        `${node.className || ""} ${node.getAttribute("data-testid") || ""} ${node.getAttribute("aria-label") || ""} ${node.getAttribute("title") || ""} ${node.getAttribute("data-status") || ""} ${node.getAttribute("data-state") || ""}`
      );
    }
  } catch (_e) {
    /* ignore */
  }
  return `${scopeEl.innerText || ""} ${attrBits.join(" ")}`.replace(/\s+/g, " ").trim();
}

function rowScopeLooksRejected(scopeEl) {
  return scopeEligibleForRejectAnalyzer(scopeEl);
}

/** Kartu layak Reject Analyzer: hanya status rejected / ditolak / declined eksplisit. */
function scopeEligibleForRejectAnalyzer(scopeEl) {
  if (!scopeEl) return false;
  const text = collectScopeStatusBlob(scopeEl);
  if (!text) return false;

  const hasReject = NERONA_REJECT_PROBLEM_STATUS_RE.test(text);
  if (!hasReject) return false;

  const looksApprovedOnly =
    NERONA_APPROVED_ONLY_STATUS_RE.test(text) && !hasReject;
  return !looksApprovedOnly;
}

function isCanvaContributorsHost() {
  const h = String(location.hostname || "").toLowerCase();
  if (!h.endsWith("canva.com")) return false;
  const p = String(location.pathname || "");
  if (/^creator\./i.test(h) || /^creators\./i.test(h)) return true;
  return /\/creators\//i.test(p) || /\/creator\//i.test(p);
}

/** ID elemen media Canva (contoh: MAHIwTJlX4U) — dipakai di /_ajax/media?ids= */
const CANVA_MEDIA_ID_RE = /\b(MA[A-Za-z0-9_-]{8,32})\b/;

function extractCanvaMediaElementIdFromContext(imgEl) {
  if (!imgEl || !isCanvaContributorsHost()) return "";
  let hay =
    `${imgEl.currentSrc || ""} ${imgEl.src || ""} ${imgEl.srcset || ""} ${imgEl.getAttribute("src") || ""}`;
  for (const u of [imgEl.currentSrc, imgEl.src]) {
    if (!u) continue;
    const pathId = String(u).match(
      /\/(MA[A-Za-z0-9_-]{8,40})(?=\/|$|[?#])|ids=([A-Za-z0-9_-]{10,40})/i
    );
    if (pathId) return (pathId[1] || pathId[2] || "").trim();
  }
  let el = imgEl.parentElement;
  for (let d = 0; d < 18 && el; d += 1, el = el.parentElement) {
    if (isInsideNeronaOverlay(el)) break;
    try {
      el.querySelectorAll?.("a[href]").forEach((a) => {
        hay += ` ${a.getAttribute("href") || ""}`;
      });
    } catch (_e) {
      /* ignore */
    }
    if (el.attributes) {
      for (const a of el.attributes) hay += ` ${a.value}`;
    }
  }

  const fromIdsParam = hay.match(/[?&]ids=([^&#'"\s]+)/i);
  if (fromIdsParam) {
    const raw = decodeURIComponent(fromIdsParam[1].trim());
    const first = raw.split(",")[0].trim();
    if (first && CANVA_MEDIA_ID_RE.test(first)) return first;
    if (first && first.length >= 10) return first;
  }

  const idM = hay.match(CANVA_MEDIA_ID_RE);
  return idM ? idM[1] : "";
}

function canvaScopeEligibleForRejectAnalyzer(scopeEl) {
  return scopeEligibleForRejectAnalyzer(scopeEl);
}

/** Tab/filter Canva untuk aset bermasalah — DOM sering tanpa kata "rejected". */
function isCanvaProblemLibraryView() {
  if (!isCanvaContributorsHost()) return false;
  const blob = `${location.pathname || ""} ${location.search || ""} ${location.hash || ""}`.toLowerCase();
  return /reject|declin|review|issue|problem|failed|removed|unpublish|moderat|guideline|not-approved|needs-change|ditolak|penolakan|action-required|resubmit/.test(
    blob
  );
}

async function fetchCanvaMediaAjaxContextForReject(mediaId) {
  if (!mediaId) return "";
  const origin = location.origin || "https://www.canva.com";
  const url = `${origin.replace(/\/$/, "")}/_ajax/media?ids=${encodeURIComponent(
    mediaId
  )}&staging&projection=FKGSTD&qualities=THUMBNAIL_LARGE&qualities=ORIGINAL`;
  try {
    const r = await fetch(url, {
      credentials: "include",
      headers: { Accept: "application/json, text/plain, */*" }
    });
    const t = await r.text();
    return `\n--- Canva _ajax/media (element id ${mediaId}) HTTP ${r.status} ---\n${t.slice(0, 14000)}`;
  } catch (e) {
    return `\n--- Canva _ajax/media fetch error ---\n${String(e?.message || e)}`;
  }
}

function getRejectAnalyzerButtonAnchor(imgEl, cfg) {
  if (cfg?.marketplaceKey === "canva") {
    const wrap = imgEl?.closest?.(
      '[class*="card" i], [class*="Card" i], [class*="Cell" i], [class*="grid" i], [class*="Media" i], [class*="media" i], [class*="Row" i], [class*="Item" i], article, [role="listitem"], [role="row"], li, section, tr, main a, [data-testid]'
    );
    if (wrap && !isInsideNeronaOverlay(wrap)) return wrap;
  }
  return imgEl?.parentElement || null;
}

function gatherCanvaRejectAnalyzerThumbnailImages() {
  if (!isCanvaContributorsHost()) return [];
  const picked = [];
  const seen = new Set();
  for (const img of document.querySelectorAll("img[src]")) {
    if (isInsideNeronaOverlay(img) || !isElementVisible(img)) continue;
    const src = String(img.currentSrc || img.src || "").trim();
    if (!src || src.startsWith("data:")) continue;
    const r = img.getBoundingClientRect();
    if (r.width < 40 || r.height < 40) continue;
    if (r.width > 920 || r.height > 920) continue;
    const mediaId = extractCanvaMediaElementIdFromContext(img);
    if (!mediaId) continue;
    const scope = findContributorAssetScopeForImage(img);
    if (!scope || !scope.contains(img)) continue;
    if (!canvaScopeEligibleForRejectAnalyzer(scope)) continue;
    const k = imgDomDedupeKey(img);
    if (!k || seen.has(k)) continue;
    seen.add(k);
    picked.push(img);
  }
  return picked;
}

/** my-items & grid: banyak kartu tanpa teks "reject" di DOM — tetap tampilkan tombol (tanpa wajib media id). */
function gatherCanvaCreatorsPageThumbnailsRelaxed() {
  if (!isCanvaContributorsHost()) return [];
  const picked = [];
  const seen = new Set();
  const max = 72;
  for (const img of document.querySelectorAll("img")) {
    if (picked.length >= max) break;
    if (isInsideNeronaOverlay(img) || !isElementVisible(img, 24)) continue;
    const src = String(img.currentSrc || img.src || "").trim();
    const srcset = String(img.getAttribute("srcset") || "").trim();
    if (!src && !srcset) continue;
    if (src.startsWith("data:")) continue;
    const r = img.getBoundingClientRect();
    if (r.width < 32 || r.height < 32) continue;
    if (r.width > 980 || r.height > 980) continue;
    const scope = findContributorAssetScopeForImage(img);
    if (!scope || !scope.contains(img)) continue;
    const k = imgDomDedupeKey(img);
    if (!k || seen.has(k)) continue;
    seen.add(k);
    picked.push(img);
  }
  return picked;
}

/** Fallback Canva: ID media + tab/filter bermasalah (bukan semua thumbnail di halaman approved). */
function gatherCanvaRejectAnalyzerThumbnailImagesByMediaIdOnly() {
  if (!isCanvaContributorsHost() || !isCanvaProblemLibraryView()) return [];
  const picked = [];
  const seen = new Set();
  for (const img of document.querySelectorAll("img[src]")) {
    if (isInsideNeronaOverlay(img) || !isElementVisible(img)) continue;
    const src = String(img.currentSrc || img.src || "").trim();
    if (!src || src.startsWith("data:")) continue;
    const r = img.getBoundingClientRect();
    if (r.width < 40 || r.height < 40) continue;
    if (r.width > 920 || r.height > 920) continue;
    const mediaId = extractCanvaMediaElementIdFromContext(img);
    if (!mediaId) continue;
    const scope = findContributorAssetScopeForImage(img);
    if (!scope || !scope.contains(img)) continue;
    const k = imgDomDedupeKey(img);
    if (!k || seen.has(k)) continue;
    seen.add(k);
    picked.push(img);
  }
  return picked;
}

function collectRejectContextSnippet(scopeEl) {
  if (!scopeEl) return "";
  let snippet = "";
  try {
    const clone = scopeEl.cloneNode(true);
    clone.querySelectorAll("[data-nerona-overlay]").forEach((n) => n.remove());
    clone.querySelectorAll('[data-nerona-reject-analyzer="1"]').forEach((n) => n.remove());
    snippet = String(clone.innerText || "")
      .replace(/\s+/g, " ")
      .trim();
  } catch (_e) {
    snippet = String(scopeEl.innerText || "")
      .replace(/\s+/g, " ")
      .trim();
  }
  return snippet.slice(0, 9000);
}

function gatherRejectAnalyzerEligibleThumbnailImages() {
  const picked = [];
  const seen = new Set();
  for (const img of document.querySelectorAll("img[src]")) {
    if (isInsideNeronaOverlay(img) || !isElementVisible(img)) continue;
    const src = String(img.currentSrc || img.src || "").trim();
    if (!src || src.startsWith("data:")) continue;
    const r = img.getBoundingClientRect();
    if (r.width < 40 || r.height < 40) continue;
    if (r.width > 920 || r.height > 920) continue;
    const scope = findContributorAssetScopeForImage(img);
    if (!scope || !scope.contains(img)) continue;
    if (!scopeEligibleForRejectAnalyzer(scope)) continue;
    const k = imgDomDedupeKey(img);
    if (!k || seen.has(k)) continue;
    seen.add(k);
    picked.push(img);
  }
  return picked;
}

function gatherRejectedContributorThumbnailImages() {
  return gatherRejectAnalyzerEligibleThumbnailImages();
}

function styleRejectAnalyzerButton(button) {
  if (!button) return;
  button.style.background = "linear-gradient(135deg,#b45309,#c2410c)";
  button.style.color = "#fff";
  button.style.border = "1px solid rgba(255,255,255,0.28)";
  button.style.borderRadius = "8px";
  button.style.padding = "4px 8px";
  button.style.fontWeight = "800";
  button.style.fontSize = "10px";
  button.style.lineHeight = "1.1";
  button.style.cursor = "pointer";
  button.style.letterSpacing = "0.2px";
  button.style.boxShadow = "0 6px 16px rgba(180,83,9,0.45)";
  button.style.maxWidth = "120px";
  button.style.textAlign = "center";
}

function scoringMeterColor(value) {
  const v = Number(value) || 0;
  if (v >= 75) return "#4ade80";
  if (v >= 50) return "#fbbf24";
  return "#f87171";
}

function createScoreMeter(label, value) {
  const wrap = document.createElement("div");
  Object.assign(wrap.style, {
    background: "#0f172a",
    border: "1px solid #1e293b",
    borderRadius: "10px",
    padding: "10px 12px"
  });
  const top = document.createElement("div");
  Object.assign(top.style, {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "6px",
    gap: "8px"
  });
  const lab = document.createElement("span");
  lab.textContent = label;
  lab.style.fontSize = "11px";
  lab.style.color = "#94a3b8";
  lab.style.fontWeight = "700";
  const num = document.createElement("span");
  const n = Math.round(Number(value) || 0);
  num.textContent = String(n);
  num.style.fontSize = "18px";
  num.style.fontWeight = "900";
  num.style.color = scoringMeterColor(n);
  top.appendChild(lab);
  top.appendChild(num);
  const barBg = document.createElement("div");
  barBg.style.height = "6px";
  barBg.style.borderRadius = "999px";
  barBg.style.background = "#1e293b";
  barBg.style.overflow = "hidden";
  const bar = document.createElement("div");
  bar.style.height = "100%";
  bar.style.width = `${Math.min(100, Math.max(0, n))}%`;
  bar.style.background = scoringMeterColor(n);
  bar.style.borderRadius = "999px";
  barBg.appendChild(bar);
  wrap.appendChild(top);
  wrap.appendChild(barBg);
  return wrap;
}

function appendChipRow(parent, items, tone = "neutral") {
  if (!Array.isArray(items) || !items.length) return;
  const row = document.createElement("div");
  row.style.display = "flex";
  row.style.flexWrap = "wrap";
  row.style.gap = "6px";
  row.style.marginTop = "6px";
  const bg =
    tone === "good" ? "rgba(34,197,94,0.15)" : tone === "warn" ? "rgba(251,191,36,0.15)" : "#1e293b";
  const color = tone === "good" ? "#86efac" : tone === "warn" ? "#fde68a" : "#cbd5e1";
  items.forEach((t) => {
    const chip = document.createElement("span");
    chip.textContent = String(t);
    Object.assign(chip.style, {
      fontSize: "11px",
      padding: "4px 8px",
      borderRadius: "999px",
      background: bg,
      color,
      border: "1px solid #334155"
    });
    row.appendChild(chip);
  });
  parent.appendChild(row);
}

function looksLikeAiScoringResultJson(obj) {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return false;
  return Boolean(obj.scores && typeof obj.scores === "object") || Boolean(obj.image_summary);
}

function renderAiScoringResultRich(obj) {
  const root = document.createElement("div");
  Object.assign(root.style, {
    display: "flex",
    flexDirection: "column",
    fontFamily: 'system-ui, "Segoe UI", Roboto, "Helvetica Neue", sans-serif'
  });

  let isFirst = true;

  if (obj.image_summary) {
    const card = document.createElement("div");
    Object.assign(card.style, {
      background: "linear-gradient(135deg, rgba(5,150,105,0.2), rgba(13,148,136,0.12))",
      border: "1px solid #334155",
      borderRadius: "12px",
      padding: "14px 16px",
      marginBottom: "14px"
    });
    const lab = document.createElement("div");
    lab.textContent = "Ringkasan gambar";
    lab.style.fontSize = "11px";
    lab.style.fontWeight = "800";
    lab.style.color = "#6ee7b7";
    lab.style.marginBottom = "6px";
    const p = document.createElement("div");
    p.textContent = String(obj.image_summary);
    p.style.fontSize = "14px";
    p.style.lineHeight = "1.55";
    p.style.color = "#f8fafc";
    card.appendChild(lab);
    card.appendChild(p);
    root.appendChild(card);
    isFirst = false;
  }

  const scores = obj.scores || {};
  const scoreEntries = [
    ["Overall opportunity", scores.overall_opportunity],
    ["Commercial intent", scores.commercial_intent],
    ["Trend relevance", scores.trend_relevance],
    ["Stock usability", scores.stock_usability],
    ["Visual quality", scores.visual_quality],
    ["Originality", scores.originality],
    ["Saturation risk", scores.saturation_risk],
    ["Thumbnail CTR", scores.thumbnail_ctr]
  ].filter(([, v]) => v != null && v !== "");

  if (scoreEntries.length) {
    root.appendChild(createRejectAnalyzerSectionLabel("Skor estimasi (0–100)", isFirst));
    isFirst = false;
    const grid = document.createElement("div");
    grid.style.display = "grid";
    grid.style.gridTemplateColumns = "repeat(auto-fill, minmax(160px, 1fr))";
    grid.style.gap = "8px";
    scoreEntries.forEach(([lab, val]) => grid.appendChild(createScoreMeter(lab, val)));
    root.appendChild(grid);
  }

  if (Array.isArray(obj.detected_subjects) && obj.detected_subjects.length) {
    root.appendChild(createRejectAnalyzerSectionLabel("Subjek terdeteksi", isFirst));
    isFirst = false;
    appendChipRow(root, obj.detected_subjects, "good");
  }

  if (Array.isArray(obj.visual_style) && obj.visual_style.length) {
    root.appendChild(createRejectAnalyzerSectionLabel("Gaya visual", isFirst));
    isFirst = false;
    appendChipRow(root, obj.visual_style);
  }

  const ma = obj.market_analysis;
  if (ma && typeof ma === "object") {
    root.appendChild(createRejectAnalyzerSectionLabel("Analisis pasar", isFirst));
    isFirst = false;
    const block = document.createElement("div");
    block.style.fontSize = "13px";
    block.style.lineHeight = "1.55";
    block.style.color = "#cbd5e1";
    [
      ["Kekuatan komersial", ma.commercial_strength],
      ["Kesesuaian tren", ma.trend_alignment],
      ["Saturasi pasar", ma.market_saturation],
      ["Potensi pembeli", ma.buyer_potential]
    ].forEach(([k, v]) => {
      if (!v) return;
      const p = document.createElement("p");
      p.style.margin = "0 0 10px";
      p.innerHTML = `<strong style="color:#94a3b8">${k}:</strong> ${String(v)}`;
      block.appendChild(p);
    });
    if (Array.isArray(ma.best_use_cases) && ma.best_use_cases.length) {
      appendChipRow(block, ma.best_use_cases, "good");
    }
    root.appendChild(block);
  }

  const rec = obj.recommendations;
  if (rec && typeof rec === "object") {
    root.appendChild(createRejectAnalyzerSectionLabel("Rekomendasi", isFirst));
    isFirst = false;
    const block = document.createElement("div");
    block.style.fontSize = "13px";
    block.style.color = "#cbd5e1";
    if (rec.should_upload != null) {
      const up = document.createElement("p");
      up.style.margin = "0 0 8px";
      up.innerHTML = `<strong>Upload:</strong> ${rec.should_upload ? "Ya (estimasi)" : "Kurang disarankan"}`;
      block.appendChild(up);
    }
    if (rec.priority_level) {
      const pr = document.createElement("p");
      pr.style.margin = "0 0 8px";
      pr.innerHTML = `<strong>Prioritas:</strong> ${String(rec.priority_level)}`;
      block.appendChild(pr);
    }
    if (Array.isArray(rec.best_marketplaces) && rec.best_marketplaces.length) {
      const l = document.createElement("div");
      l.textContent = "Marketplace terbaik:";
      l.style.fontSize = "12px";
      l.style.color = "#94a3b8";
      l.style.marginBottom = "4px";
      block.appendChild(l);
      appendChipRow(block, rec.best_marketplaces, "good");
    }
    if (Array.isArray(rec.improvement_suggestions) && rec.improvement_suggestions.length) {
      const ul = document.createElement("ul");
      ul.style.margin = "10px 0 0";
      ul.style.paddingLeft = "18px";
      rec.improvement_suggestions.forEach((s) => {
        const li = document.createElement("li");
        li.textContent = String(s);
        li.style.marginBottom = "4px";
        ul.appendChild(li);
      });
      block.appendChild(ul);
    }
    root.appendChild(block);
  }

  const kw = obj.keywords;
  if (kw && typeof kw === "object") {
    root.appendChild(createRejectAnalyzerSectionLabel("Keyword", isFirst));
    isFirst = false;
    if (Array.isArray(kw.primary) && kw.primary.length) {
      const l = document.createElement("div");
      l.textContent = "Primary";
      l.style.fontSize = "11px";
      l.style.color = "#94a3b8";
      l.style.marginBottom = "4px";
      root.appendChild(l);
      appendChipRow(root, kw.primary, "good");
    }
    if (Array.isArray(kw.long_tail) && kw.long_tail.length) {
      const l = document.createElement("div");
      l.textContent = "Long-tail";
      l.style.fontSize = "11px";
      l.style.color = "#94a3b8";
      l.style.margin = "12px 0 4px";
      root.appendChild(l);
      appendChipRow(root, kw.long_tail);
    }
    if (Array.isArray(kw.avoid_keywords) && kw.avoid_keywords.length) {
      const l = document.createElement("div");
      l.textContent = "Hindari";
      l.style.fontSize = "11px";
      l.style.color = "#94a3b8";
      l.style.margin = "12px 0 4px";
      root.appendChild(l);
      appendChipRow(root, kw.avoid_keywords, "warn");
    }
  }

  const risk = obj.risk_analysis;
  if (risk && typeof risk === "object") {
    root.appendChild(createRejectAnalyzerSectionLabel("Risiko", isFirst));
    const block = document.createElement("div");
    block.style.fontSize = "13px";
    block.style.lineHeight = "1.55";
    block.style.color = "#fca5a5";
    [
      ["AI detection", risk.ai_detection_risk],
      ["Duplikasi gaya", risk.duplicate_style_risk],
      ["Penolakan", risk.rejection_risk]
    ].forEach(([k, v]) => {
      if (!v) return;
      const p = document.createElement("p");
      p.style.margin = "0 0 8px";
      p.innerHTML = `<strong style="color:#fecaca">${k}:</strong> ${String(v)}`;
      block.appendChild(p);
    });
    root.appendChild(block);
  }

  const note = document.createElement("p");
  note.textContent =
    "Skor bersifat estimasi inferensi visual — bukan data volume/kompetisi marketplace secara real-time.";
  Object.assign(note.style, {
    margin: "16px 0 0",
    fontSize: "11px",
    color: "#64748b",
    lineHeight: "1.45"
  });
  root.appendChild(note);
  return root;
}

function looksLikeCommercialIntentResultJson(obj) {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return false;
  return Boolean(obj.primary_commercial_intent || obj.buyer_personas || obj.industries);
}

function renderCommercialIntentResultRich(obj) {
  const root = document.createElement("div");
  Object.assign(root.style, {
    display: "flex",
    flexDirection: "column",
    fontFamily: 'system-ui, "Segoe UI", Roboto, "Helvetica Neue", sans-serif'
  });

  let isFirst = true;

  if (obj.primary_commercial_intent) {
    const hero = document.createElement("div");
    Object.assign(hero.style, {
      background: "linear-gradient(135deg, rgba(124,58,237,0.28), rgba(79,70,229,0.16))",
      border: "1px solid #4c1d95",
      borderRadius: "12px",
      padding: "14px 16px",
      marginBottom: "14px"
    });
    const lab = document.createElement("div");
    lab.textContent = "Tujuan komersial utama";
    lab.style.fontSize = "11px";
    lab.style.fontWeight = "800";
    lab.style.color = "#c4b5fd";
    lab.style.marginBottom = "6px";
    const p = document.createElement("div");
    p.textContent = String(obj.primary_commercial_intent);
    p.style.fontSize = "15px";
    p.style.lineHeight = "1.5";
    p.style.fontWeight = "800";
    p.style.color = "#f8fafc";
    hero.appendChild(lab);
    hero.appendChild(p);
    if (obj.intent_confidence) {
      const conf = document.createElement("div");
      conf.textContent = `Keyakinan: ${String(obj.intent_confidence)}`;
      conf.style.marginTop = "8px";
      conf.style.fontSize = "11px";
      conf.style.color = "#a78bfa";
      hero.appendChild(conf);
    }
    root.appendChild(hero);
    isFirst = false;
  }

  if (obj.image_summary) {
    const card = document.createElement("div");
    Object.assign(card.style, {
      background: "#0f172a",
      border: "1px solid #334155",
      borderRadius: "12px",
      padding: "12px 14px",
      marginBottom: "12px"
    });
    const lab = document.createElement("div");
    lab.textContent = "Ringkasan visual";
    lab.style.fontSize = "11px";
    lab.style.fontWeight = "800";
    lab.style.color = "#94a3b8";
    lab.style.marginBottom = "6px";
    const p = document.createElement("div");
    p.textContent = String(obj.image_summary);
    p.style.fontSize = "13px";
    p.style.lineHeight = "1.55";
    p.style.color = "#e2e8f0";
    card.appendChild(lab);
    card.appendChild(p);
    root.appendChild(card);
    isFirst = false;
  }

  if (Array.isArray(obj.buyer_personas) && obj.buyer_personas.length) {
    root.appendChild(createRejectAnalyzerSectionLabel("Siapa pembeli (persona)", isFirst));
    isFirst = false;
    obj.buyer_personas.forEach((bp) => {
      if (!bp || typeof bp !== "object") return;
      const row = document.createElement("div");
      Object.assign(row.style, {
        border: "1px solid #1e293b",
        borderRadius: "10px",
        padding: "10px 12px",
        marginBottom: "8px",
        background: "#0b1220"
      });
      const t = document.createElement("div");
      t.textContent = String(bp.persona || "Persona");
      t.style.fontWeight = "800";
      t.style.color = "#e9d5ff";
      t.style.fontSize = "13px";
      t.style.marginBottom = "4px";
      const w = document.createElement("div");
      w.textContent = String(bp.why_they_buy || "");
      w.style.fontSize = "12px";
      w.style.color = "#cbd5e1";
      w.style.lineHeight = "1.45";
      row.appendChild(t);
      row.appendChild(w);
      root.appendChild(row);
    });
  }

  const chipSections = [
    ["Industri", obj.industries, "good"],
    ["Jenis kampanye", obj.campaign_types],
    ["Channel pemasaran", obj.marketing_channels],
    ["Pemicu emosi", obj.emotional_triggers],
    ["Tema pesan", obj.message_themes],
    ["Format konten cocok", obj.content_format_fit, "good"],
    ["Kurang cocok untuk", obj.not_suitable_for, "warn"],
    ["Klise visual serupa", obj.competing_visual_cliches, "warn"]
  ];
  chipSections.forEach(([label, items, tone]) => {
    if (!Array.isArray(items) || !items.length) return;
    root.appendChild(createRejectAnalyzerSectionLabel(label, isFirst));
    isFirst = false;
    appendChipRow(root, items, tone || "neutral");
  });

  const st = obj.seasonal_timing;
  if (st && typeof st === "object" && (st.relevance || st.notes)) {
    root.appendChild(createRejectAnalyzerSectionLabel("Waktu / musim", isFirst));
    isFirst = false;
    const block = document.createElement("div");
    block.style.fontSize = "13px";
    block.style.color = "#cbd5e1";
    block.style.lineHeight = "1.55";
    if (st.relevance) {
      const p = document.createElement("p");
      p.style.margin = "0 0 8px";
      p.innerHTML = `<strong style="color:#94a3b8">Relevansi:</strong> ${String(st.relevance)}`;
      block.appendChild(p);
    }
    if (st.notes) {
      const p = document.createElement("p");
      p.style.margin = "0";
      p.innerHTML = `<strong style="color:#94a3b8">Catatan:</strong> ${String(st.notes)}`;
      block.appendChild(p);
    }
    root.appendChild(block);
  }

  const meta = obj.metadata_angle;
  if (meta && typeof meta === "object") {
    root.appendChild(createRejectAnalyzerSectionLabel("Sudut metadata", isFirst));
    isFirst = false;
    const block = document.createElement("div");
    block.style.fontSize = "13px";
    block.style.lineHeight = "1.55";
    block.style.color = "#cbd5e1";
    [
      ["Arah judul", meta.title_direction],
      ["Arah deskripsi", meta.description_angle]
    ].forEach(([k, v]) => {
      if (!v) return;
      const p = document.createElement("p");
      p.style.margin = "0 0 10px";
      p.innerHTML = `<strong style="color:#94a3b8">${k}:</strong> ${String(v)}`;
      block.appendChild(p);
    });
    if (Array.isArray(meta.keyword_themes) && meta.keyword_themes.length) {
      appendChipRow(block, meta.keyword_themes, "good");
    }
    root.appendChild(block);
  }

  if (obj.disclaimer) {
    const note = document.createElement("p");
    note.textContent = String(obj.disclaimer);
    Object.assign(note.style, {
      margin: "16px 0 0",
      fontSize: "11px",
      color: "#64748b",
      lineHeight: "1.45"
    });
    root.appendChild(note);
  }

  return root;
}

function looksLikeEventKeywordResearchJson(obj) {
  return Boolean(
    obj &&
      typeof obj === "object" &&
      (Array.isArray(obj.current_month) || Array.isArray(obj.next_month))
  );
}

function appendKeywordAiChipRow(parent, items, tone = "default") {
  if (!Array.isArray(items) || !items.length) return;
  const row = document.createElement("div");
  row.style.display = "flex";
  row.style.flexWrap = "wrap";
  row.style.gap = "6px";
  row.style.marginTop = "6px";
  for (const item of items) {
    const t = String(item || "").trim();
    if (!t) continue;
    const chip = document.createElement("span");
    chip.textContent = t;
    Object.assign(chip.style, {
      fontSize: "11px",
      padding: "4px 8px",
      borderRadius: "999px",
      border: "1px solid #334155",
      background: tone === "warn" ? "rgba(127,29,29,0.25)" : "#1e293b",
      color: tone === "warn" ? "#fecaca" : "#cbd5e1"
    });
    row.appendChild(chip);
  }
  parent.appendChild(row);
}

function renderEventKeywordResearchItem(item, index) {
  const card = document.createElement("div");
  Object.assign(card.style, {
    border: "1px solid #1e293b",
    borderRadius: "12px",
    padding: "12px 14px",
    marginBottom: "12px",
    background: "#0f172a"
  });

  const title = document.createElement("div");
  title.textContent = `${index + 1}. ${String(item?.event || "Event").trim()}`;
  Object.assign(title.style, {
    fontSize: "14px",
    fontWeight: "800",
    color: "#f8fafc",
    marginBottom: "8px"
  });
  card.appendChild(title);

  const meta = document.createElement("div");
  meta.style.fontSize = "12px";
  meta.style.color = "#94a3b8";
  meta.style.marginBottom = "8px";
  meta.textContent = `Trend ${item?.trend_score ?? "—"} · Kompetisi ${item?.competition_level || "—"}`;
  card.appendChild(meta);

  if (item?.search_intent) {
    const intent = document.createElement("p");
    intent.style.margin = "0 0 10px";
    intent.style.fontSize = "12px";
    intent.style.lineHeight = "1.5";
    intent.style.color = "#cbd5e1";
    intent.innerHTML = `<strong style="color:#93c5fd">Intent:</strong> ${String(item.search_intent)}`;
    card.appendChild(intent);
  }

  const addList = (label, arr) => {
    if (!Array.isArray(arr) || !arr.length) return;
    const l = document.createElement("div");
    l.textContent = label;
    l.style.fontSize = "11px";
    l.style.fontWeight = "700";
    l.style.color = "#94a3b8";
    l.style.marginTop = "8px";
    card.appendChild(l);
    appendKeywordAiChipRow(card, arr);
  };

  addList("Keyword bernilai tinggi", item?.high_value_keywords);
  addList("Ide konten", item?.content_ideas);
  addList("Use case komersial", item?.commercial_use_cases);
  addList("Gaya disarankan", item?.recommended_styles);

  return card;
}

function renderEventKeywordResearchRich(parsed) {
  const root = document.createElement("div");

  const addSection = (heading, items) => {
    const h = document.createElement("div");
    h.textContent = heading;
    Object.assign(h.style, {
      fontSize: "13px",
      fontWeight: "800",
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      color: "#93c5fd",
      margin: "18px 0 10px"
    });
    root.appendChild(h);
    const list = Array.isArray(items) ? items : [];
    if (!list.length) {
      const empty = document.createElement("p");
      empty.textContent = "(Tidak ada data)";
      empty.style.fontSize = "12px";
      empty.style.color = "#64748b";
      root.appendChild(empty);
      return;
    }
    list.forEach((item, i) => root.appendChild(renderEventKeywordResearchItem(item, i)));
  };

  addSection("Bulan ini", parsed.current_month);
  addSection("Bulan depan", parsed.next_month);

  const note = document.createElement("p");
  note.textContent =
    "Riset tren berbasis inferensi AI — bukan data volume keyword real-time dari marketplace.";
  Object.assign(note.style, {
    margin: "16px 0 0",
    fontSize: "11px",
    color: "#64748b",
    lineHeight: "1.45"
  });
  root.appendChild(note);
  return root;
}

function buildEventKeywordResearchBody(bodyText) {
  const raw = String(bodyText ?? "").trim();
  const parsed = safeJsonParse(raw);
  if (parsed && looksLikeEventKeywordResearchJson(parsed)) {
    return { rich: true, node: renderEventKeywordResearchRich(parsed) };
  }
  const pre = document.createElement("pre");
  pre.textContent = raw || "(Kosong)";
  Object.assign(pre.style, {
    margin: "0",
    whiteSpace: "pre-wrap",
    wordBreak: "break-word",
    fontSize: "12px",
    lineHeight: "1.5",
    color: "#cbd5e1",
    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace'
  });
  return { rich: false, node: pre };
}

function showKeywordAiResultPanel(title, bodyText) {
  const existing = document.getElementById("nerona-keyword-ai-panel");
  if (existing) existing.remove();

  const isErrorState = /error/i.test(String(title || ""));
  const overlay = document.createElement("div");
  overlay.id = "nerona-keyword-ai-panel";
  overlay.setAttribute("data-nerona-overlay", "1");
  Object.assign(overlay.style, {
    position: "fixed",
    inset: "0",
    zIndex: "2147483646",
    background: "rgba(8, 15, 34, 0.78)",
    backdropFilter: "blur(3px)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "16px"
  });

  const panel = document.createElement("div");
  Object.assign(panel.style, {
    width: "min(920px, 96vw)",
    maxHeight: "88vh",
    overflow: "auto",
    background: "linear-gradient(180deg, #0f172a 0%, #0b1220 100%)",
    border: isErrorState ? "1px solid #b91c1c" : "1px solid #334155",
    borderRadius: "16px",
    padding: "18px 20px 20px"
  });

  const head = document.createElement("div");
  Object.assign(head.style, {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: "14px",
    paddingBottom: "12px",
    borderBottom: "1px solid #1e293b"
  });

  const h = document.createElement("div");
  h.textContent = title || "Keyword AI";
  h.style.fontSize = "16px";
  h.style.fontWeight = "900";
  h.style.color = "#f1f5f9";

  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "Tutup";
  Object.assign(close.style, {
    background: "#1e293b",
    color: "#e2e8f0",
    border: "1px solid #334155",
    borderRadius: "9px",
    padding: "7px 14px",
    cursor: "pointer"
  });
  close.addEventListener("click", () => overlay.remove());

  head.appendChild(h);
  head.appendChild(close);

  const body = buildEventKeywordResearchBody(bodyText);
  const bodyWrap = document.createElement("div");
  if (body.rich) {
    bodyWrap.appendChild(body.node);
  } else {
    Object.assign(bodyWrap.style, {
      background: isErrorState ? "rgba(127,29,29,0.12)" : "#0b1220",
      border: "1px solid #1e293b",
      borderRadius: "10px",
      padding: "12px 14px"
    });
    bodyWrap.appendChild(body.node);
  }

  panel.appendChild(head);
  panel.appendChild(bodyWrap);
  overlay.appendChild(panel);
  overlay.addEventListener("click", (ev) => {
    if (ev.target === overlay) overlay.remove();
  });
  document.body.appendChild(overlay);
}

async function runEventKeywordResearch(cfg, progressCallback) {
  const months = getEventKeywordResearchMonthContext();

  progressCallback?.("license", months);
  await ensureNeronaLicenseAccess(cfg.marketplaceKey);

  progressCallback?.("prepare", months);
  const marketplaceLabel = cfg.aiLabel || cfg.marketplaceKey || "microstock";

  progressCallback?.("ai", months);
  const aiResult = await callGenerate({
    feature: "keyword",
    marketplace: marketplaceLabel,
    monthsCurrent: months.current,
    monthsNext: months.next
  });

  progressCallback?.("usage", months, aiResult.usage);
  progressCallback?.("parse", months);
  return aiResult;
}

function buildAiScoringResultBody(bodyText) {
  const raw = String(bodyText ?? "").trim();
  const parsed = safeJsonParse(raw);
  if (parsed && typeof parsed === "object" && looksLikeAiScoringResultJson(parsed)) {
    return { rich: true, node: renderAiScoringResultRich(parsed) };
  }
  const pre = document.createElement("pre");
  pre.textContent = raw || "(Kosong)";
  Object.assign(pre.style, {
    margin: "0",
    whiteSpace: "pre-wrap",
    wordBreak: "break-word",
    fontSize: "12px",
    lineHeight: "1.5",
    color: "#cbd5e1",
    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace'
  });
  return { rich: false, node: pre };
}

function showAiScoringResultPanel(title, bodyText) {
  const existing = document.getElementById("nerona-ai-scoring-panel");
  if (existing) existing.remove();

  const isErrorState = /error/i.test(String(title || ""));
  const overlay = document.createElement("div");
  overlay.id = "nerona-ai-scoring-panel";
  overlay.setAttribute("data-nerona-overlay", "1");
  Object.assign(overlay.style, {
    position: "fixed",
    inset: "0",
    zIndex: "2147483646",
    background: "rgba(8, 15, 34, 0.78)",
    backdropFilter: "blur(3px)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "16px"
  });

  const panel = document.createElement("div");
  Object.assign(panel.style, {
    width: "min(900px, 96vw)",
    maxHeight: "86vh",
    overflow: "auto",
    background: "linear-gradient(180deg, #0f172a 0%, #0b1220 100%)",
    border: isErrorState ? "1px solid #b91c1c" : "1px solid #334155",
    borderRadius: "16px",
    padding: "18px 20px 20px"
  });

  const head = document.createElement("div");
  Object.assign(head.style, {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: "14px",
    paddingBottom: "12px",
    borderBottom: "1px solid #1e293b"
  });

  const h = document.createElement("div");
  h.textContent = title || "AI Scoring Agent";
  h.style.fontSize = "16px";
  h.style.fontWeight = "900";
  h.style.color = "#f1f5f9";

  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "Tutup";
  Object.assign(close.style, {
    background: "#1e293b",
    color: "#e2e8f0",
    border: "1px solid #334155",
    borderRadius: "9px",
    padding: "7px 14px",
    cursor: "pointer"
  });
  close.addEventListener("click", () => overlay.remove());

  head.appendChild(h);
  head.appendChild(close);

  const body = buildAiScoringResultBody(bodyText);
  const bodyWrap = document.createElement("div");
  if (body.rich) {
    bodyWrap.appendChild(body.node);
  } else {
    Object.assign(bodyWrap.style, {
      background: isErrorState ? "rgba(127,29,29,0.12)" : "#0b1220",
      border: "1px solid #1e293b",
      borderRadius: "10px",
      padding: "12px 14px"
    });
    bodyWrap.appendChild(body.node);
  }

  panel.appendChild(head);
  panel.appendChild(bodyWrap);
  overlay.appendChild(panel);
  overlay.addEventListener("click", (ev) => {
    if (ev.target === overlay) overlay.remove();
  });
  document.body.appendChild(overlay);
}

async function runAiScoringAgent(cfg) {
  await ensureNeronaLicenseAccess(cfg.marketplaceKey);
  const selected = getContributorSelectionImagesOrFallback();
  if (!selected.length) {
    throw new Error("Pilih atau centang gambar dulu untuk AI Scoring Agent.");
  }
  const inlineData = await imageElementToInlineData(selected[0]);
  const marketplaceLabel = cfg.aiLabel || cfg.marketplaceKey || "stock";
  return callGenerate({
    feature: "scoring",
    marketplace: marketplaceLabel,
    image: { mime: inlineData.mimeType, dataBase64: inlineData.data }
  });
}

function buildCommercialIntentResultBody(bodyText) {
  const raw = String(bodyText ?? "").trim();
  const parsed = safeJsonParse(raw);
  if (parsed && typeof parsed === "object" && looksLikeCommercialIntentResultJson(parsed)) {
    return { rich: true, node: renderCommercialIntentResultRich(parsed) };
  }
  const pre = document.createElement("pre");
  pre.textContent = raw || "(Kosong)";
  Object.assign(pre.style, {
    margin: "0",
    whiteSpace: "pre-wrap",
    wordBreak: "break-word",
    fontSize: "12px",
    lineHeight: "1.5",
    color: "#cbd5e1",
    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace'
  });
  return { rich: false, node: pre };
}

function showCommercialIntentResultPanel(title, bodyText) {
  const existing = document.getElementById("nerona-commercial-intent-panel");
  if (existing) existing.remove();

  const isErrorState = /error/i.test(String(title || ""));
  const overlay = document.createElement("div");
  overlay.id = "nerona-commercial-intent-panel";
  overlay.setAttribute("data-nerona-overlay", "1");
  Object.assign(overlay.style, {
    position: "fixed",
    inset: "0",
    zIndex: "2147483646",
    background: "rgba(8, 15, 34, 0.78)",
    backdropFilter: "blur(3px)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "16px"
  });

  const panel = document.createElement("div");
  Object.assign(panel.style, {
    width: "min(900px, 96vw)",
    maxHeight: "86vh",
    overflow: "auto",
    background: "linear-gradient(180deg, #0f172a 0%, #0b1220 100%)",
    border: isErrorState ? "1px solid #b91c1c" : "1px solid #5b21b6",
    borderRadius: "16px",
    padding: "18px 20px 20px"
  });

  const head = document.createElement("div");
  Object.assign(head.style, {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: "14px",
    paddingBottom: "12px",
    borderBottom: "1px solid #1e293b"
  });

  const h = document.createElement("div");
  h.textContent = title || "Commercial Intent Analyzer";
  h.style.fontSize = "16px";
  h.style.fontWeight = "900";
  h.style.color = "#f1f5f9";

  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "Tutup";
  Object.assign(close.style, {
    background: "#1e293b",
    color: "#e2e8f0",
    border: "1px solid #334155",
    borderRadius: "9px",
    padding: "7px 14px",
    cursor: "pointer"
  });
  close.addEventListener("click", () => overlay.remove());

  head.appendChild(h);
  head.appendChild(close);

  const body = buildCommercialIntentResultBody(bodyText);
  const bodyWrap = document.createElement("div");
  if (body.rich) {
    bodyWrap.appendChild(body.node);
  } else {
    Object.assign(bodyWrap.style, {
      background: isErrorState ? "rgba(127,29,29,0.12)" : "#0b1220",
      border: "1px solid #1e293b",
      borderRadius: "10px",
      padding: "12px 14px"
    });
    bodyWrap.appendChild(body.node);
  }

  panel.appendChild(head);
  panel.appendChild(bodyWrap);
  overlay.appendChild(panel);
  overlay.addEventListener("click", (ev) => {
    if (ev.target === overlay) overlay.remove();
  });
  document.body.appendChild(overlay);
}

async function runCommercialIntentAnalyzer(cfg) {
  await ensureNeronaLicenseAccess(cfg.marketplaceKey);
  const selected = getContributorSelectionImagesOrFallback();
  if (!selected.length) {
    throw new Error("Pilih atau centang gambar dulu untuk Commercial Intent Analyzer.");
  }
  const inlineData = await imageElementToInlineData(selected[0]);
  const marketplaceLabel = cfg.aiLabel || cfg.marketplaceKey || "stock";
  return callGenerate({
    feature: "commercial_intent",
    marketplace: marketplaceLabel,
    image: { mime: inlineData.mimeType, dataBase64: inlineData.data }
  });
}

function createRejectAnalyzerSectionLabel(label, isFirst) {
  const el = document.createElement("div");
  el.textContent = label;
  el.style.fontSize = "11px";
  el.style.fontWeight = "800";
  el.style.letterSpacing = "0.07em";
  el.style.textTransform = "uppercase";
  el.style.color = "#94a3b8";
  el.style.marginBottom = "8px";
  el.style.marginTop = isFirst ? "0" : "18px";
  return el;
}

/** Render JSON hasil Reject Analyzer jadi UI terbaca (bukan dump mentah). */
function renderRejectAnalyzerResultRich(obj) {
  const root = document.createElement("div");
  Object.assign(root.style, {
    display: "flex",
    flexDirection: "column",
    gap: "0",
    fontFamily: 'system-ui, "Segoe UI", Roboto, "Helvetica Neue", sans-serif'
  });

  let isFirstSectionLabel = !obj.summary;

  if (obj.summary) {
    const card = document.createElement("div");
    Object.assign(card.style, {
      background: "linear-gradient(135deg, rgba(37,99,235,0.18), rgba(124,58,237,0.12))",
      border: "1px solid #334155",
      borderRadius: "12px",
      padding: "14px 16px"
    });
    const lab = document.createElement("div");
    lab.textContent = "Ringkasan";
    lab.style.fontSize = "11px";
    lab.style.fontWeight = "800";
    lab.style.color = "#93c5fd";
    lab.style.marginBottom = "6px";
    const p = document.createElement("div");
    p.textContent = String(obj.summary);
    p.style.fontSize = "14px";
    p.style.lineHeight = "1.55";
    p.style.color = "#f8fafc";
    p.style.fontWeight = "600";
    card.appendChild(lab);
    card.appendChild(p);
    root.appendChild(card);
  }

  const evidence = obj.evidenceFromPage;
  if (Array.isArray(evidence) && evidence.length) {
    root.appendChild(createRejectAnalyzerSectionLabel("Bukti dari halaman", isFirstSectionLabel));
    isFirstSectionLabel = false;
    const ul = document.createElement("ul");
    ul.style.margin = "0";
    ul.style.paddingLeft = "20px";
    ul.style.color = "#cbd5e1";
    ul.style.fontSize = "13px";
    ul.style.lineHeight = "1.55";
    evidence.forEach((e) => {
      const li = document.createElement("li");
      li.textContent = String(e);
      li.style.marginBottom = "5px";
      ul.appendChild(li);
    });
    root.appendChild(ul);
  }

  const reasons = obj.likelyRejectionReasons;
  if (Array.isArray(reasons) && reasons.length) {
    root.appendChild(createRejectAnalyzerSectionLabel("Alasan yang mungkin & mitigasi", isFirstSectionLabel));
    isFirstSectionLabel = false;
    reasons.forEach((item) => {
      const c = document.createElement("div");
      Object.assign(c.style, {
        background: "#0f172a",
        border: "1px solid #1e293b",
        borderRadius: "10px",
        padding: "12px 14px",
        marginBottom: "8px"
      });
      const top = document.createElement("div");
      Object.assign(top.style, {
        display: "flex",
        alignItems: "flex-start",
        justifyContent: "space-between",
        gap: "10px",
        marginBottom: item?.mitigation ? "8px" : "0"
      });
      const reasonEl = document.createElement("div");
      reasonEl.textContent = String(item?.reason || "—");
      Object.assign(reasonEl.style, {
        fontSize: "13px",
        fontWeight: "700",
        color: "#e2e8f0",
        flex: "1",
        lineHeight: "1.45"
      });
      const conf = String(item?.confidence || "").toLowerCase();
      const badge = document.createElement("span");
      badge.textContent = conf || "—";
      Object.assign(badge.style, {
        fontSize: "10px",
        fontWeight: "800",
        textTransform: "uppercase",
        padding: "4px 9px",
        borderRadius: "999px",
        flexShrink: "0",
        letterSpacing: "0.04em"
      });
      if (conf === "high") {
        badge.style.background = "#7f1d1d";
        badge.style.color = "#fecaca";
      } else if (conf === "medium") {
        badge.style.background = "#78350f";
        badge.style.color = "#fde68a";
      } else {
        badge.style.background = "#1e293b";
        badge.style.color = "#94a3b8";
      }
      top.appendChild(reasonEl);
      top.appendChild(badge);
      c.appendChild(top);
      if (item?.mitigation) {
        const m = document.createElement("div");
        m.style.fontSize = "12px";
        m.style.lineHeight = "1.55";
        m.style.color = "#a8b2c9";
        const strong = document.createElement("span");
        strong.textContent = "Mitigasi: ";
        strong.style.color = "#64748b";
        strong.style.fontWeight = "700";
        m.appendChild(strong);
        m.appendChild(document.createTextNode(String(item.mitigation)));
        c.appendChild(m);
      }
      root.appendChild(c);
    });
  }

  if (obj.suggestedTitle) {
    root.appendChild(createRejectAnalyzerSectionLabel("Judul yang disarankan", isFirstSectionLabel));
    isFirstSectionLabel = false;
    const b = document.createElement("div");
    b.textContent = String(obj.suggestedTitle);
    Object.assign(b.style, {
      fontSize: "14px",
      fontWeight: "700",
      color: "#f8fafc",
      background: "#111827",
      border: "1px solid #374151",
      borderRadius: "8px",
      padding: "11px 14px",
      lineHeight: "1.4"
    });
    root.appendChild(b);
  }

  if (obj.suggestedDescription) {
    root.appendChild(createRejectAnalyzerSectionLabel("Deskripsi yang disarankan", isFirstSectionLabel));
    isFirstSectionLabel = false;
    const b = document.createElement("div");
    b.textContent = String(obj.suggestedDescription);
    Object.assign(b.style, {
      fontSize: "13px",
      lineHeight: "1.58",
      color: "#cbd5e1",
      background: "#111827",
      border: "1px solid #374151",
      borderRadius: "8px",
      padding: "11px 14px",
      whiteSpace: "pre-wrap"
    });
    root.appendChild(b);
  }

  const kws = obj.suggestedKeywords;
  if (Array.isArray(kws) && kws.length) {
    root.appendChild(createRejectAnalyzerSectionLabel("Keyword", isFirstSectionLabel));
    isFirstSectionLabel = false;
    const wrap = document.createElement("div");
    Object.assign(wrap.style, {
      display: "flex",
      flexWrap: "wrap",
      gap: "7px"
    });
    kws.forEach((kw) => {
      const chip = document.createElement("span");
      chip.textContent = String(kw).trim();
      Object.assign(chip.style, {
        display: "inline-block",
        fontSize: "11px",
        fontWeight: "600",
        color: "#e0e7ff",
        background: "rgba(99,102,241,0.22)",
        border: "1px solid rgba(129,140,248,0.38)",
        borderRadius: "999px",
        padding: "5px 11px"
      });
      wrap.appendChild(chip);
    });
    root.appendChild(wrap);
  }

  const notePairs = [
    ["legalAndIpNotes", "Hukum & kekayaan intelektual"],
    ["technicalQualityNotes", "Kualitas teknis"]
  ];
  for (const [key, lab] of notePairs) {
    const arr = obj[key];
    if (Array.isArray(arr) && arr.length) {
      root.appendChild(createRejectAnalyzerSectionLabel(lab, isFirstSectionLabel));
      isFirstSectionLabel = false;
      const ul = document.createElement("ul");
      ul.style.margin = "0";
      ul.style.paddingLeft = "20px";
      ul.style.color = "#a8b2c9";
      ul.style.fontSize = "12px";
      ul.style.lineHeight = "1.5";
      arr.forEach((e) => {
        const li = document.createElement("li");
        li.textContent = String(e);
        li.style.marginBottom = "4px";
        ul.appendChild(li);
      });
      root.appendChild(ul);
    }
  }

  if (obj.disclaimer) {
    const d = document.createElement("div");
    d.textContent = String(obj.disclaimer);
    Object.assign(d.style, {
      marginTop: "18px",
      paddingTop: "14px",
      borderTop: "1px solid #1e293b",
      fontSize: "11px",
      lineHeight: "1.5",
      color: "#64748b",
      fontStyle: "italic"
    });
    root.appendChild(d);
  }

  return root;
}

function looksLikeRejectAnalyzerResultJson(obj) {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return false;
  const keys = Object.keys(obj);
  if (keys.length === 0) return false;
  return keys.some((k) =>
    [
      "summary",
      "evidenceFromPage",
      "likelyRejectionReasons",
      "suggestedTitle",
      "suggestedDescription",
      "suggestedKeywords"
    ].includes(k)
  );
}

function buildRejectAnalyzerResultBody(bodyText) {
  const raw = String(bodyText ?? "").trim();
  const parsed = safeJsonParse(raw);
  if (parsed && typeof parsed === "object" && looksLikeRejectAnalyzerResultJson(parsed)) {
    return { rich: true, node: renderRejectAnalyzerResultRich(parsed) };
  }
  const pre = document.createElement("pre");
  pre.textContent = raw || "(Kosong)";
  Object.assign(pre.style, {
    margin: "0",
    whiteSpace: "pre-wrap",
    wordBreak: "break-word",
    fontSize: "12px",
    lineHeight: "1.5",
    color: "#cbd5e1",
    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace'
  });
  return { rich: false, node: pre };
}

function showRejectAnalyzerResultPanel(title, bodyText) {
  const existing = document.getElementById("nerona-reject-analyzer-panel");
  if (existing) existing.remove();

  const isErrorState = /error/i.test(String(title || ""));

  const overlay = document.createElement("div");
  overlay.id = "nerona-reject-analyzer-panel";
  overlay.setAttribute("data-nerona-overlay", "1");
  overlay.style.position = "fixed";
  overlay.style.inset = "0";
  overlay.style.zIndex = "2147483646";
  overlay.style.background = "rgba(8, 15, 34, 0.78)";
  overlay.style.backdropFilter = "blur(3px)";
  overlay.style.display = "flex";
  overlay.style.alignItems = "center";
  overlay.style.justifyContent = "center";
  overlay.style.padding = "16px";

  const panel = document.createElement("div");
  panel.style.width = "min(820px, 96vw)";
  panel.style.maxHeight = "82vh";
  panel.style.overflow = "auto";
  panel.style.background = "linear-gradient(180deg, #0f172a 0%, #0b1220 100%)";
  panel.style.border = isErrorState ? "1px solid #b91c1c" : "1px solid #334155";
  panel.style.boxShadow = isErrorState
    ? "0 24px 60px rgba(185,28,28,0.25), 0 30px 80px rgba(0,0,0,0.55)"
    : "0 30px 80px rgba(0,0,0,0.55)";
  panel.style.borderRadius = "16px";
  panel.style.padding = "18px 20px 20px";

  const head = document.createElement("div");
  head.style.display = "flex";
  head.style.alignItems = "flex-start";
  head.style.justifyContent = "space-between";
  head.style.gap = "12px";
  head.style.marginBottom = "14px";
  head.style.paddingBottom = "12px";
  head.style.borderBottom = "1px solid #1e293b";

  const h = document.createElement("div");
  h.textContent = title || "Reject Analyzer";
  h.style.fontSize = "16px";
  h.style.fontWeight = "900";
  h.style.color = "#f1f5f9";
  h.style.lineHeight = "1.3";
  h.style.letterSpacing = "-0.02em";

  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "Tutup";
  close.style.flexShrink = "0";
  close.style.background = "#1e293b";
  close.style.color = "#e2e8f0";
  close.style.border = "1px solid #334155";
  close.style.borderRadius = "9px";
  close.style.padding = "7px 14px";
  close.style.cursor = "pointer";
  close.style.fontWeight = "700";
  close.style.fontSize = "12px";
  close.addEventListener("click", () => overlay.remove());

  head.appendChild(h);
  head.appendChild(close);

  const body = buildRejectAnalyzerResultBody(bodyText);
  const bodyWrap = document.createElement("div");
  bodyWrap.style.maxHeight = "none";
  if (body.rich) {
    bodyWrap.appendChild(body.node);
  } else {
    Object.assign(bodyWrap.style, {
      background: isErrorState ? "rgba(127,29,29,0.12)" : "#0b1220",
      border: "1px solid #1e293b",
      borderRadius: "10px",
      padding: "12px 14px"
    });
    bodyWrap.appendChild(body.node);
  }

  panel.appendChild(head);
  panel.appendChild(bodyWrap);
  overlay.appendChild(panel);
  overlay.addEventListener("click", (ev) => {
    if (ev.target === overlay) overlay.remove();
  });
  document.body.appendChild(overlay);
}


async function generateRejectAnalysisFromImage(aiLabel, imageEl, contextSnippet) {
  const inlineData = await imageElementToInlineData(imageEl);
  return callGenerate({
    feature: "reject",
    marketplace: aiLabel,
    contextSnippet,
    image: { mime: inlineData.mimeType, dataBase64: inlineData.data }
  });
}

function ensureRejectAnalyzerButton(imgEl, dedupeKey, cfg) {
  const scope = findContributorAssetScopeForImage(imgEl);
  if (!scopeEligibleForRejectAnalyzer(scope)) return;

  const anchor = getRejectAnalyzerButtonAnchor(imgEl, cfg);
  if (!anchor || isInsideNeronaOverlay(anchor)) return;

  for (const b of anchor.querySelectorAll('[data-nerona-reject-analyzer="1"]')) {
    if (b.getAttribute("data-target-key") === dedupeKey) return;
  }

  const computed = window.getComputedStyle(anchor);
  if (computed.position === "static") {
    anchor.style.position = "relative";
  }

  const btn = document.createElement("button");
  btn.type = "button";
  btn.textContent = "Reject Analyzer";
  btn.setAttribute("data-nerona-overlay", "1");
  btn.setAttribute("data-nerona-reject-analyzer", "1");
  btn.setAttribute("data-target-key", dedupeKey);
  btn.style.position = "absolute";
  btn.style.right = "4px";
  btn.style.bottom = "4px";
  btn.style.zIndex = "80";
  btn.style.pointerEvents = "auto";
  styleRejectAnalyzerButton(btn);

  btn.addEventListener("click", async (ev) => {
    ev.preventDefault();
    ev.stopPropagation();
    if (btn.disabled) return;
    const scope = findContributorAssetScopeForImage(imgEl);
    let snippet = collectRejectContextSnippet(scope);
    if (cfg?.marketplaceKey === "canva") {
      const mid = extractCanvaMediaElementIdFromContext(imgEl);
      if (mid) {
        showNeronaToast("Canva: mengambil /_ajax/media…");
        snippet = `${snippet}${await fetchCanvaMediaAjaxContextForReject(mid)}`.slice(0, 20000);
      }
    }
    btn.disabled = true;
    btn.style.opacity = "0.65";
    showNeronaToast("Reject Analyzer: memanggil AI…");
    try {
      await ensureNeronaLicenseAccess(cfg?.marketplaceKey, {
        requireRejectAnalyzer: true
      });
      const aiOut = await generateRejectAnalysisFromImage(cfg.aiLabel || "Stock", imgEl, snippet);
      const tokenHint = formatTokenUsageForUi(aiOut.usage);
      showNeronaToast(
        tokenHint ? `Reject Analyzer selesai — ${tokenHint}` : "Reject Analyzer selesai."
      );
      showRejectAnalyzerResultPanel("Reject Analyzer — hasil", aiOut.text || "");
    } catch (error) {
      const msg = String(error?.message || "Gagal analisa.");
      showNeronaToast(msg);
      showRejectAnalyzerResultPanel("Reject Analyzer — error", msg);
    } finally {
      btn.disabled = false;
      btn.style.opacity = "1";
    }
  });

  anchor.appendChild(btn);
}

function pruneRejectAnalyzerButtons(validKeys) {
  const valid = validKeys instanceof Set ? validKeys : new Set(validKeys || []);
  document.querySelectorAll('[data-nerona-reject-analyzer="1"]').forEach((btn) => {
    const k = btn.getAttribute("data-target-key");
    if (!k || !valid.has(k)) btn.remove();
  });
}

function removeAllRejectAnalyzerButtons() {
  document.querySelectorAll('[data-nerona-reject-analyzer="1"]').forEach((btn) => btn.remove());
}

function stopRejectAnalyzerUi() {
  removeAllRejectAnalyzerButtons();
  if (globalThis.__NERONA_REJECT_MO__) {
    try {
      globalThis.__NERONA_REJECT_MO__.disconnect();
    } catch (_e) {
      /* ignore */
    }
    globalThis.__NERONA_REJECT_MO__ = null;
  }
  if (globalThis.__NERONA_REJECT_SYNC_T__) {
    window.clearTimeout(globalThis.__NERONA_REJECT_SYNC_T__);
    globalThis.__NERONA_REJECT_SYNC_T__ = 0;
  }
  globalThis.__NERONA_REJECT_UI_STARTED__ = false;
  globalThis.__NERONA_REJECT_CFG__ = null;
  globalThis.__NERONA_REJECT_ALLOWED__ = false;
}

async function maybeStartRejectAnalyzerUi(cfg) {
  let allowed = false;
  if (globalThis.NeronaAccess?.canUseRejectAnalyzer) {
    allowed = await NeronaAccess.canUseRejectAnalyzer(cfg?.marketplaceKey || "");
  }
  globalThis.__NERONA_REJECT_ALLOWED__ = allowed;
  if (!allowed) {
    stopRejectAnalyzerUi();
    return;
  }
  startRejectAnalyzerUi(cfg);
}

function syncRejectAnalyzerButtons() {
  const cfg = globalThis.__NERONA_REJECT_CFG__;
  if (!cfg || globalThis.__NERONA_REJECT_ALLOWED__ !== true) return;

  const imgs = gatherRejectAnalyzerEligibleThumbnailImages();

  const validKeys = new Set();
  for (const img of imgs) {
    const k = imgDomDedupeKey(img);
    if (!k) continue;
    validKeys.add(k);
    ensureRejectAnalyzerButton(img, k, cfg);
  }
  pruneRejectAnalyzerButtons(validKeys);
}

function scheduleRejectAnalyzerButtonSync() {
  if (globalThis.__NERONA_REJECT_SYNC_T__) {
    window.clearTimeout(globalThis.__NERONA_REJECT_SYNC_T__);
  }
  globalThis.__NERONA_REJECT_SYNC_T__ = window.setTimeout(() => {
    globalThis.__NERONA_REJECT_SYNC_T__ = 0;
    try {
      syncRejectAnalyzerButtons();
    } catch (_e) {
      /* ignore */
    }
  }, 450);
}

function startRejectAnalyzerUi(cfg) {
  if (globalThis.__NERONA_REJECT_UI_STARTED__) return;
  globalThis.__NERONA_REJECT_UI_STARTED__ = true;
  globalThis.__NERONA_REJECT_CFG__ = cfg;

  scheduleRejectAnalyzerButtonSync();

  try {
    const mo = new MutationObserver(() => scheduleRejectAnalyzerButtonSync());
    mo.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "aria-label", "title", "data-status", "aria-checked", "aria-selected"]
    });
    globalThis.__NERONA_REJECT_MO__ = mo;
  } catch (_e) {
    /* ignore */
  }

  window.addEventListener("scroll", scheduleRejectAnalyzerButtonSync, { passive: true });
  window.addEventListener("resize", scheduleRejectAnalyzerButtonSync, { passive: true });
}

function applyMarketplaceMetadataInScope(scopeEl, metadata, marketplaceKey) {
  if (!scopeEl || !metadata) return { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false };

  const sels = marketplaceSelectors[marketplaceKey];
  if (!sels) return { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false };

  const norm = normalizeMetadataForMarketplace(metadata, marketplaceKey);
  const normalizedKeywords = formatKeywordsForStockInput(norm.keywords, marketplaceKey);

  const titleEl = firstMatchInScope(scopeEl, sels.title);
  const descEl = firstMatchInScope(scopeEl, sels.description);
  let kwEl =
    marketplaceKey === "adobe"
      ? findAdobeKeywordsField(scopeEl)
      : firstMatchInScope(scopeEl, sels.keywords);

  if (!kwEl && marketplaceKey !== "adobe") {
    const probes = Array.from(
      scopeEl.querySelectorAll('textarea, input[type="text"], input:not([type])')
    ).filter(
      (el) => isFormFieldVisible(el) && !isInsideNeronaOverlay(el) && !isLikelyNoiseMetadataField(el)
    );
    const hintOfLocal = (el) =>
      `${el.name || ""} ${el.id || ""} ${el.placeholder || ""} ${el.getAttribute("aria-label") || ""}`.toLowerCase();
    kwEl =
      probes.find((el) =>
        /(keyword|key word|tag|comma|separate|paste|;|태그|키워드|키\s*워드)/.test(hintOfLocal(el))
      ) || null;
  }

  let fileNameDone = false;
  let descriptionDone = false;
  let keywordDone = false;

  if (marketplaceKey === "miricanvas" && norm.fileName) {
    fileNameDone = fillMiricanvasElementName(norm.fileName, scopeEl);
  } else if (titleEl && norm.fileName) {
    if (titleEl.isContentEditable) {
      titleEl.textContent = norm.fileName;
      dispatchTypingEvents(titleEl);
      fileNameDone = true;
    } else if (setNativeValue(titleEl, norm.fileName)) {
      dispatchTypingEvents(titleEl);
      fileNameDone = true;
    }
  }

  if (descEl && norm.description) {
    if (descEl.isContentEditable) {
      descEl.textContent = norm.description;
      dispatchTypingEvents(descEl);
      descriptionDone = true;
    } else if (setNativeValue(descEl, norm.description)) {
      dispatchTypingEvents(descEl);
      descriptionDone = true;
    }
  }

  // Miricanvas / Magnific: chip Enter per kata (batch lewat apply*MetadataToSingleAsset).
  if (marketplaceKey === "miricanvas" && normalizedKeywords) {
    keywordDone = miricanvasHasChipKeywordUi(scopeEl)
      ? fillMiricanvasKeywordTags(norm.keywords, scopeEl)
      : fillMiricanvasKeywordsCommaField(norm.keywords, scopeEl);
  } else if (marketplaceKey === "magnific" && normalizedKeywords) {
    keywordDone = magnificHasChipKeywordUi(scopeEl)
      ? fillMagnificKeywordTags(norm.keywords, scopeEl)
      : false;
  } else if (marketplaceKey === "shutterstock" && normalizedKeywords) {
    keywordDone = shutterstockHasChipKeywordUi(scopeEl)
      ? fillShutterstockKeywordTags(norm.keywords, scopeEl)
      : false;
  } else if (kwEl && normalizedKeywords && marketplaceKey !== "vecteezy" && marketplaceKey !== "miricanvas" && marketplaceKey !== "magnific" && marketplaceKey !== "shutterstock") {
    if (marketplaceKey === "adobe") {
      keywordDone = fillAdobeKeywordsField(kwEl, normalizedKeywords);
    } else if (kwEl.isContentEditable) {
      kwEl.textContent = normalizedKeywords;
      dispatchTypingEvents(kwEl);
      keywordDone = true;
    } else if (setNativeValue(kwEl, normalizedKeywords)) {
      dispatchTypingEvents(kwEl);
      keywordDone = true;
    }
  }

  return {
    ok: fileNameDone || descriptionDone || keywordDone,
    fileNameDone,
    descriptionDone,
    keywordDone
  };
}

/** Kosongkan metadata di satu scope baris/kartu (tanpa merge keyword). */
function clearMarketplaceMetadataInScope(scopeEl, marketplaceKey) {
  if (!scopeEl) return { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false };

  const sels = marketplaceSelectors[marketplaceKey];
  if (!sels) return { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false };

  const titleEl = firstMatchInScope(scopeEl, sels.title);
  const descEl = firstMatchInScope(scopeEl, sels.description);
  let kwEl =
    marketplaceKey === "adobe"
      ? findAdobeKeywordsField(scopeEl)
      : firstMatchInScope(scopeEl, sels.keywords);

  if (!kwEl && marketplaceKey !== "adobe") {
    const probes = Array.from(
      scopeEl.querySelectorAll('textarea, input[type="text"], input:not([type])')
    ).filter((el) => isFormFieldVisible(el) && !isInsideNeronaOverlay(el));
    const hintOfLocal = (el) =>
      `${el.name || ""} ${el.id || ""} ${el.placeholder || ""} ${el.getAttribute("aria-label") || ""}`.toLowerCase();
    kwEl =
      probes.find((el) =>
        /(keyword|key word|tag|comma|separate|;|태그|키워드|키\s*워드)/.test(hintOfLocal(el))
      ) || null;
  }

  let fileNameDone = false;
  let descriptionDone = false;
  let keywordDone = false;

  if (titleEl) {
    if (titleEl.isContentEditable) {
      titleEl.textContent = "";
      dispatchTypingEvents(titleEl);
      fileNameDone = true;
    } else if (setNativeValue(titleEl, "")) {
      flushNativeFieldValueCommitted(titleEl);
      dispatchTypingEvents(titleEl);
      fileNameDone = true;
    }
  }

  if (descEl) {
    if (descEl.isContentEditable) {
      descEl.textContent = "";
      dispatchTypingEvents(descEl);
      descriptionDone = true;
    } else if (setNativeValue(descEl, "")) {
      flushNativeFieldValueCommitted(descEl);
      dispatchTypingEvents(descEl);
      descriptionDone = true;
    }
  }

  if (kwEl) {
    if (marketplaceKey === "adobe") {
      keywordDone = clearAdobeKeywordsField(kwEl);
    } else if (kwEl.isContentEditable) {
      kwEl.textContent = "";
      dispatchTypingEvents(kwEl);
      keywordDone = true;
    } else if (setNativeValue(kwEl, "")) {
      flushNativeFieldValueCommitted(kwEl);
      dispatchTypingEvents(kwEl);
      keywordDone = true;
    }
  }

  return {
    ok: fileNameDone || descriptionDone || keywordDone,
    fileNameDone,
    descriptionDone,
    keywordDone
  };
}

function applyAdobeMetadataInScope(scopeEl, metadata) {
  return applyMarketplaceMetadataInScope(scopeEl, metadata, "adobe");
}

function isMagnificContributorHost() {
  const h = String(location.hostname || "").toLowerCase();
  return h === "contributor.magnific.com" || h === "contributors.magnific.com";
}

const MAGNIFIC_ASSET_ITEM_SEL = '[data-cy="preitem"].catalog__item';
const MAGNIFIC_ASSET_ITEM_SELECTED_SEL = '[data-cy="preitem"].catalog__item.selected';
const MAGNIFIC_ASSET_CHECKBOX_SEL = "label.checkbox input[type=\"checkbox\"]";
const MAGNIFIC_ASSET_IMG_SEL = 'img[data-cy="preitemImg-grid"]';

function findMagnificCatalogItemForImage(imgEl) {
  if (!imgEl) return null;
  return imgEl.closest?.('[data-cy="preitem"], .catalog__item') || null;
}

function isMagnificCatalogItemSelected(item) {
  if (!item || isInsideNeronaOverlay(item)) return false;
  if (item.classList?.contains("selected")) return true;
  const cb = item.querySelector?.(MAGNIFIC_ASSET_CHECKBOX_SEL);
  if (cb instanceof HTMLInputElement && cb.checked) return true;
  return false;
}

function sortMagnificCatalogItemsDomOrder(items) {
  return [...items].sort((a, b) => {
    const ra = a.getBoundingClientRect();
    const rb = b.getBoundingClientRect();
    if (Math.abs(ra.top - rb.top) > 10) return ra.top - rb.top;
    return ra.left - rb.left;
  });
}

function getMagnificSelectedCatalogItems() {
  const rows = new Set();
  document.querySelectorAll(MAGNIFIC_ASSET_ITEM_SELECTED_SEL).forEach((el) => {
    if (!isInsideNeronaOverlay(el)) rows.add(el);
  });
  if (!rows.size) {
    document.querySelectorAll(MAGNIFIC_ASSET_ITEM_SEL).forEach((el) => {
      if (isInsideNeronaOverlay(el)) return;
      if (isMagnificCatalogItemSelected(el)) rows.add(el);
    });
  }
  return sortMagnificCatalogItemsDomOrder(Array.from(rows));
}

function getMagnificSelectedImages() {
  const picked = [];
  const seen = new Set();
  for (const item of getMagnificSelectedCatalogItems()) {
    const img =
      item.querySelector?.(`${MAGNIFIC_ASSET_IMG_SEL}[src]`) ||
      item.querySelector?.(".thumbnail img[src]") ||
      item.querySelector?.("img[src]");
    if (!img || isInsideNeronaOverlay(img) || !isElementVisible(img)) continue;
    const k = imgDomDedupeKey(img);
    if (!k || seen.has(k)) continue;
    seen.add(k);
    picked.push(img);
  }
  return picked;
}

function pickMagnificThumbnailResourceUrl(imageEl) {
  if (!imageEl || !isMagnificContributorHost()) return "";
  const item = findMagnificCatalogItemForImage(imageEl);
  const img =
    item?.querySelector?.(MAGNIFIC_ASSET_IMG_SEL) ||
    item?.querySelector?.(".thumbnail img[src]") ||
    imageEl;
  return resolveBestImageUrlFromElement(img);
}

function countMagnificSelectedItems() {
  return getMagnificSelectedCatalogItems().length;
}

function isMagnificExclusiveSelectionForImage(imgEl) {
  if (countMagnificSelectedItems() !== 1) return false;
  const item = findMagnificCatalogItemForImage(imgEl);
  return Boolean(item && isMagnificCatalogItemSelected(item));
}

async function deselectAllMagnificGridAssets() {
  if (!isMagnificContributorHost()) return;

  for (let round = 0; round < 4; round += 1) {
    const toggles = new Set();
    getMagnificSelectedCatalogItems().forEach((item) => {
      const cb = item.querySelector?.(MAGNIFIC_ASSET_CHECKBOX_SEL);
      const label = item.querySelector?.("label.checkbox");
      if (cb instanceof HTMLElement) toggles.add(cb);
      else if (label instanceof HTMLElement) toggles.add(label);
    });

    for (const el of toggles) {
      try {
        el.click();
      } catch (_e) {
        /* ignore */
      }
    }

    if (getMagnificSelectedCatalogItems().length === 0) break;
    await sleep(120);
  }

  await sleep(160);
}

async function selectExclusiveMagnificAsset(imgEl) {
  if (!imgEl || !isMagnificContributorHost()) return false;

  try {
    imgEl.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "instant" });
  } catch (_e) {
    try {
      imgEl.scrollIntoView({ block: "nearest", inline: "nearest" });
    } catch (_e2) {
      /* ignore */
    }
  }

  for (let attempt = 0; attempt < 5; attempt += 1) {
    await deselectAllMagnificGridAssets();
    await sleep(180 + attempt * 60);

    const item = findMagnificCatalogItemForImage(imgEl);
    const cb = item?.querySelector?.(MAGNIFIC_ASSET_CHECKBOX_SEL);
    const label = item?.querySelector?.("label.checkbox");

    if (cb instanceof HTMLInputElement && !cb.checked) {
      cb.click();
    } else if (label instanceof HTMLElement) {
      label.click();
    } else if (item instanceof HTMLElement) {
      dispatchPlainClick(item);
    }

    await sleep(280 + attempt * 80);

    if (isMagnificExclusiveSelectionForImage(imgEl)) return true;
  }

  return isMagnificExclusiveSelectionForImage(imgEl);
}

/** Magnific: pilih 1 catalog item → isi metadata panel. */
async function applyMagnificMetadataToSingleAsset(imgEl, metadata) {
  if (!metadata) {
    return { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false };
  }

  if (!isMagnificExclusiveSelectionForImage(imgEl)) {
    await selectExclusiveMagnificAsset(imgEl);
    await sleep(200);
  }

  await removeVecteezyMergedCommaTagsAsync(document);

  const result = applyGeneric(marketplaceSelectors.magnific, metadata, "magnific");
  if (magnificHasChipKeywordUi() && metadata.keywords) {
    const tagOk = await applyMagnificTagsAfterMetadata(metadata, null);
    if (tagOk) {
      result.keywordDone = true;
      result.ok = result.ok || tagOk;
    }
  }
  return result;
}

function expandShutterstockKeywordsToChipList(text) {
  return sanitizeKeywordListForMarketplace(text, "shutterstock", { max: SHUTTERSTOCK_KEYWORD_MAX });
}

function findShutterstockKeywordTagInput(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  const sels = marketplaceSelectors.shutterstock?.keywords || [
    '[data-testid="keyword-input-text"] input',
    '[data-testid="keyword-input"] input'
  ];
  for (const sel of sels) {
    let list;
    try {
      list = Array.from(root.querySelectorAll(sel));
    } catch (_e) {
      continue;
    }
    const hit = list.find(
      (el) => !isInsideNeronaOverlay(el) && isFormFieldVisible(el) && !isLikelyNoiseMetadataField(el)
    );
    if (hit) return hit;
  }
  return null;
}

function shutterstockHasChipKeywordUi(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  if (root.querySelector('[data-testid="keyword-input"]')) return true;
  if (root.querySelector('[data-testid="keywords-block-all"]')) return true;
  return Boolean(findShutterstockKeywordTagInput(root));
}

function getShutterstockExistingTags(scopeRoot = document) {
  const tags = new Set();
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  root.querySelectorAll('[data-testid^="selected-keyword-"] .MuiChip-label').forEach((el) => {
    if (isInsideNeronaOverlay(el)) return;
    const t = String(el.textContent || "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
    if (t) tags.add(t);
  });
  return tags;
}

async function clearShutterstockKeywordTags(scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  for (let round = 0; round < 60; round += 1) {
    const chips = Array.from(root.querySelectorAll('[data-testid^="selected-keyword-"]')).filter(
      (el) => !isInsideNeronaOverlay(el)
    );
    if (!chips.length) break;
    let removed = false;
    for (const chip of chips) {
      if (clickVecteezyTagRemoveButton(chip)) {
        removed = true;
        await sleep(45);
        break;
      }
    }
    if (!removed) break;
  }
}

function fillShutterstockMuiField(value, selectors, scopeRoot = document) {
  if (!value) return false;
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  const el = firstMetadataField(selectors, root) || firstMatchInScope(root, selectors);
  if (!el) return false;
  return setVecteezyTagInputValue(el, value);
}

function fillShutterstockKeywordTags(value, scopeRoot = document) {
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  const keywords = expandShutterstockKeywordsToChipList(value);
  if (!keywords.length) return false;

  const input = findShutterstockKeywordTagInput(root);
  if (!input) return false;

  let inserted = 0;
  for (const keyword of keywords) {
    if (getShutterstockExistingTags(root).size >= SHUTTERSTOCK_KEYWORD_MAX) break;
    if (getShutterstockExistingTags(root).has(keyword.toLowerCase())) continue;
    setVecteezyTagInputValue(input, keyword);
    for (const key of [",", ";", "Enter"]) {
      input.dispatchEvent(new KeyboardEvent("keydown", { key, bubbles: true }));
      input.dispatchEvent(new KeyboardEvent("keypress", { key, bubbles: true }));
      input.dispatchEvent(new KeyboardEvent("keyup", { key, bubbles: true }));
      if (getShutterstockExistingTags(root).has(keyword.toLowerCase())) {
        inserted += 1;
        setNativeValue(input, "");
        break;
      }
    }
  }

  return inserted > 0 || getShutterstockExistingTags(root).size >= 7;
}

async function fillShutterstockKeywordTagsAsync(value, options = {}) {
  const scopeRoot = options.scopeRoot;
  const root = scopeRoot && scopeRoot.nodeType === 1 ? scopeRoot : document;
  const keywords = expandShutterstockKeywordsToChipList(value);
  if (!keywords.length) return false;

  if (options.replace !== false) {
    await clearShutterstockKeywordTags(root);
  }

  const resolveInput = () =>
    findShutterstockKeywordTagInput(root) || findShutterstockKeywordTagInput(document);

  if (!resolveInput()) return false;

  let inserted = 0;
  for (const keyword of keywords) {
    if (getShutterstockExistingTags(root).size >= SHUTTERSTOCK_KEYWORD_MAX) break;
    if (getShutterstockExistingTags(root).has(keyword.toLowerCase())) continue;

    const input = resolveInput();
    if (!input) break;

    setVecteezyTagInputValue(input, keyword);
    await sleep(45);

    let committed = false;
    for (const key of [",", ";", "Enter"]) {
      input.dispatchEvent(new KeyboardEvent("keydown", { key, bubbles: true }));
      input.dispatchEvent(new KeyboardEvent("keypress", { key, bubbles: true }));
      input.dispatchEvent(new KeyboardEvent("keyup", { key, bubbles: true }));
      await sleep(70);
      if (getShutterstockExistingTags(root).has(keyword.toLowerCase())) {
        committed = true;
        break;
      }
    }

    if (committed) {
      inserted += 1;
      setNativeValue(input, "");
      flushNativeFieldValueCommitted(input);
    }
  }

  return inserted > 0 || getShutterstockExistingTags(root).size >= 7;
}

function isShutterstockContributorHost() {
  const h = String(location.hostname || "").toLowerCase();
  return (
    h === "contributors.shutterstock.com" ||
    h === "contributor.shutterstock.com" ||
    h === "submit.shutterstock.com"
  );
}

const SHUTTERSTOCK_ASSET_CARD_SEL = '[data-testid="asset-card"]';
const SHUTTERSTOCK_ASSET_CARD_SELECTED_SEL = '[data-testid="asset-card"][aria-checked="true"]';
const SHUTTERSTOCK_ASSET_THUMB_SEL =
  'img[data-testid^="card-media-"][src], img.MuiCardMedia-img[src]';
const SHUTTERSTOCK_ASSET_CHECKBOX_SEL = '[data-testid="asset-checkbox"] input[type="checkbox"]';

function findShutterstockAssetCardForImage(imgEl) {
  if (!imgEl) return null;
  return imgEl.closest?.(SHUTTERSTOCK_ASSET_CARD_SEL) || null;
}

function isShutterstockAssetCardSelected(card) {
  if (!(card instanceof HTMLElement) || isInsideNeronaOverlay(card)) return false;
  if (card.getAttribute("aria-checked") === "true") return true;
  const cb = card.querySelector?.(SHUTTERSTOCK_ASSET_CHECKBOX_SEL);
  if (cb instanceof HTMLInputElement && cb.checked) return true;
  const checkedRoot = card.querySelector?.('[data-testid="asset-checkbox"].Mui-checked');
  return Boolean(checkedRoot);
}

function sortShutterstockAssetCardsDomOrder(cards) {
  return [...cards].sort((a, b) => {
    const ra = a.getBoundingClientRect();
    const rb = b.getBoundingClientRect();
    if (Math.abs(ra.top - rb.top) > 10) return ra.top - rb.top;
    return ra.left - rb.left;
  });
}

function getShutterstockSelectedAssetCards() {
  const cards = new Set();
  document.querySelectorAll(SHUTTERSTOCK_ASSET_CARD_SELECTED_SEL).forEach((el) => {
    if (!isInsideNeronaOverlay(el)) cards.add(el);
  });
  if (!cards.size) {
    document.querySelectorAll(SHUTTERSTOCK_ASSET_CARD_SEL).forEach((el) => {
      if (isInsideNeronaOverlay(el)) return;
      if (isShutterstockAssetCardSelected(el)) cards.add(el);
    });
  }
  return sortShutterstockAssetCardsDomOrder(Array.from(cards));
}

function getShutterstockSelectedImages() {
  const imgs = [];
  const seen = new Set();
  for (const card of getShutterstockSelectedAssetCards()) {
    const img =
      card.querySelector?.(`${SHUTTERSTOCK_ASSET_THUMB_SEL}`) ||
      card.querySelector?.("img[src]");
    if (!img || isInsideNeronaOverlay(img) || !isElementVisible(img)) continue;
    const key = imgDomDedupeKey(img);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    imgs.push(img);
  }
  return imgs;
}

function pickShutterstockThumbnailResourceUrl(imageEl) {
  if (!imageEl || !isShutterstockContributorHost()) return "";
  const card = findShutterstockAssetCardForImage(imageEl);
  const img =
    card?.querySelector?.(SHUTTERSTOCK_ASSET_THUMB_SEL) ||
    card?.querySelector?.("img[src]") ||
    imageEl;
  return resolveBestImageUrlFromElement(img);
}

function findShutterstockAssetCardByThumbSrc(thumbSrc) {
  const want = String(thumbSrc || "").trim();
  if (!want) return null;
  const wantKey = imgDomDedupeKey({ currentSrc: want, src: want });
  for (const card of document.querySelectorAll(SHUTTERSTOCK_ASSET_CARD_SEL)) {
    if (isInsideNeronaOverlay(card)) continue;
    const img = card.querySelector?.("img[src]");
    if (!img) continue;
    const src = img.currentSrc || img.src || "";
    if (!src) continue;
    if (src === want || imgDomDedupeKey(img) === wantKey) return card;
  }
  return null;
}

function snapshotShutterstockBatchImages(imgs) {
  return (Array.isArray(imgs) ? imgs : []).map((imgEl) => {
    const card = findShutterstockAssetCardForImage(imgEl);
    const pinnedUrl = pickShutterstockThumbnailResourceUrl(imgEl);
    const thumbImg = card?.querySelector?.(SHUTTERSTOCK_ASSET_THUMB_SEL) || imgEl;
    const mediaTestId = thumbImg?.getAttribute?.("data-testid") || "";
    const thumbSrc = thumbImg?.currentSrc || thumbImg?.src || pinnedUrl || "";
    return { imgEl, card, pinnedUrl, mediaTestId, thumbSrc };
  });
}

function resolveShutterstockBatchTarget(job) {
  if (!job) return { imgEl: null, card: null };
  if (job.mediaTestId) {
    try {
      const img = document.querySelector(`img[data-testid="${CSS.escape(job.mediaTestId)}"]`);
      if (img) {
        const card = findShutterstockAssetCardForImage(img);
        return { imgEl: img, card };
      }
    } catch (_e) {
      const img = document.querySelector(`img[data-testid="${job.mediaTestId}"]`);
      if (img) {
        const card = findShutterstockAssetCardForImage(img);
        return { imgEl: img, card };
      }
    }
  }
  if (job.thumbSrc) {
    const card = findShutterstockAssetCardByThumbSrc(job.thumbSrc);
    if (card) {
      const img =
        card.querySelector?.(SHUTTERSTOCK_ASSET_THUMB_SEL) ||
        card.querySelector?.("img[src]");
      return { imgEl: img, card };
    }
  }
  const card = job.card || findShutterstockAssetCardForImage(job.imgEl);
  const imgEl =
    card?.querySelector?.(SHUTTERSTOCK_ASSET_THUMB_SEL) ||
    card?.querySelector?.("img[src]") ||
    job.imgEl;
  return { imgEl, card };
}

function clickShutterstockAssetCheckbox(card) {
  if (!(card instanceof HTMLElement)) return false;
  const input = card.querySelector?.(SHUTTERSTOCK_ASSET_CHECKBOX_SEL);
  const root = card.querySelector?.('[data-testid="asset-checkbox"]');
  if (input instanceof HTMLElement) {
    input.click();
    return true;
  }
  if (root instanceof HTMLElement) {
    root.click();
    return true;
  }
  dispatchPlainClick(card);
  return true;
}

function isShutterstockExclusiveSelectionForCard(card) {
  if (!card || !isShutterstockAssetCardSelected(card)) return false;
  return getShutterstockSelectedAssetCards().length === 1;
}

async function deselectAllShutterstockAssetCards() {
  if (!isShutterstockContributorHost()) return;
  for (let round = 0; round < 14; round += 1) {
    const selected = getShutterstockSelectedAssetCards();
    if (!selected.length) break;
    for (const card of selected) {
      clickShutterstockAssetCheckbox(card);
      await sleep(65);
    }
    await sleep(120);
  }
  await sleep(140);
}

async function selectExclusiveShutterstockAssetCard(imgEl, job = null) {
  if (!isShutterstockContributorHost()) return false;

  const target = resolveShutterstockBatchTarget(job || { imgEl });
  const card = target.card || findShutterstockAssetCardForImage(imgEl);
  if (!card) return false;

  try {
    card.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "instant" });
  } catch (_e) {
    try {
      card.scrollIntoView({ block: "nearest", inline: "nearest" });
    } catch (_e2) {
      /* ignore */
    }
  }

  await deselectAllShutterstockAssetCards();

  if (!isShutterstockAssetCardSelected(card)) {
    clickShutterstockAssetCheckbox(card);
    await sleep(280);
  }
  if (isShutterstockExclusiveSelectionForCard(card)) return true;

  clickShutterstockAssetCheckbox(card);
  await sleep(220);
  return isShutterstockExclusiveSelectionForCard(card);
}

/** Shutterstock: pilih 1 asset-card → isi title/keyword → deselect. */
async function applyShutterstockMetadataToSingleAsset(imgEl, metadata, job = null) {
  if (!metadata) {
    return { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false };
  }

  const target = resolveShutterstockBatchTarget(job || { imgEl });
  const card = target.card || findShutterstockAssetCardForImage(imgEl);
  if (!isShutterstockExclusiveSelectionForCard(card)) {
    const selected = await selectExclusiveShutterstockAssetCard(imgEl, job);
    if (!selected) {
      return { ok: false, fileNameDone: false, descriptionDone: false, keywordDone: false };
    }
    await sleep(260);
  }

  const norm = normalizeMetadataForMarketplace(metadata, "shutterstock");
  const ssSels = marketplaceSelectors.shutterstock;
  let result = applyGeneric(ssSels, norm, "shutterstock");
  if (!result.ok) {
    result = applyMarketplaceMetadataInScope(document.body, norm, "shutterstock");
  }

  if (!result.fileNameDone && norm.fileName && ssSels?.title) {
    const titleOk = fillShutterstockMuiField(norm.fileName, ssSels.title);
    if (titleOk) {
      result.fileNameDone = true;
      result.ok = true;
    }
  }
  if (!result.descriptionDone && norm.description && ssSels?.description) {
    const descOk = fillShutterstockMuiField(norm.description, ssSels.description);
    if (descOk) {
      result.descriptionDone = true;
      result.ok = true;
    }
  }
  if (!result.keywordDone && norm.keywords && shutterstockHasChipKeywordUi()) {
    const tagOk = await fillShutterstockKeywordTagsAsync(norm.keywords, { replace: true });
    if (tagOk) {
      result.keywordDone = true;
      result.ok = true;
    }
  }

  const freshCard = resolveShutterstockBatchTarget(job || { imgEl }).card || card;
  if (freshCard && isShutterstockAssetCardSelected(freshCard)) {
    clickShutterstockAssetCheckbox(freshCard);
    await sleep(180);
  }

  return result;
}

function getContributorSelectionImagesOrFallback() {
  if (isAdobeContributorHost()) {
    const selected = findAdobeExplicitlyCheckedImageElements().filter(isLikelyAdobeGridThumbnail);
    if (selected.length) {
      return sortAdobeCheckedImagesDomOrder(selected).slice(0, NERONA_PICKER_IMAGE_CAP);
    }
    return [];
  }

  if (isMiricanvasContributorHost()) {
    const mcSelected = getMiricanvasSelectedImages();
    if (mcSelected.length) return mcSelected.slice(0, NERONA_PICKER_IMAGE_CAP);
  }

  if (isMagnificContributorHost()) {
    const mfSelected = getMagnificSelectedImages();
    if (mfSelected.length) return mfSelected.slice(0, NERONA_PICKER_IMAGE_CAP);
    return [];
  }

  if (isVecteezyContributorHost()) {
    const vzSelected = getVecteezySelectedImages();
    if (vzSelected.length) return vzSelected.slice(0, NERONA_PICKER_IMAGE_CAP);
    return [];
  }

  if (isShutterstockContributorHost()) {
    const ssSelected = getShutterstockSelectedImages();
    if (ssSelected.length) return ssSelected.slice(0, NERONA_PICKER_IMAGE_CAP);
    return [];
  }

  const selected = findAdobeSelectedImageElements();
  if (selected.length) return rankAdobeSelectedImages(selected).slice(0, NERONA_PICKER_IMAGE_CAP);

  const candidates = getAnalyzableImageCandidates().filter(
    (img) => !isAdobeContributorHost() || isLikelyAdobeGridThumbnail(img)
  );
  if (candidates.length) {
    const pick = isAdobeContributorHost()
      ? sortImagesByViewportCenterProximity(candidates)[0]
      : candidates[0];
    return pick ? [pick] : [];
  }
  return [];
}

/** Setelah title/deskripsi/keyword teks — isi chip keyword Vecteezy (bisa per baris jika scopeEl ada). */
async function applyVecteezyTagsAfterMetadata(metadata, scopeEl) {
  const norm = normalizeMetadataForMarketplace(metadata, "vecteezy");
  const scope = scopeEl || undefined;
  const tagInput = findVecteezyKeywordTagInput(scope ?? document);
  if (tagInput instanceof HTMLElement) {
    if (!tagInput.isContentEditable) {
      setNativeValue(tagInput, "");
      flushNativeFieldValueCommitted(tagInput);
    } else {
      tagInput.textContent = "";
    }
    dispatchTypingEvents(tagInput);
  }
  return fillVecteezyKeywordTagsAsync(scrubVecteezyKeywordComma(norm.keywords), {
    scopeRoot: scope
  });
}

async function ensureNeronaLicenseAccess(marketplaceKey, options = {}) {
  if (!globalThis.NeronaAccess?.assertAccess) return { ok: true, devBypass: true };
  const access = await NeronaAccess.assertAccess(marketplaceKey || "", {
    forceRefresh: Boolean(options.forceRefresh)
  });
  if (
    options.requireRejectAnalyzer &&
    !globalThis.NeronaAccess?.isRejectAnalyzerGranted?.(access)
  ) {
    throw new Error("Fitur Reject Analyzer tidak termasuk paket lisensi Anda.");
  }
  // Nilai awal saldo, gratis: payload ini sudah di-fetch sebagai gerbang akses.
  // Bisa basi sampai cacheTtlMs, lalu tergantikan angka server di generate pertama.
  // setNeronaProgressPoints yang memvalidasi, jadi tidak perlu dijaga di sini.
  setNeronaProgressPoints(access?.pointsBalance);
  return access;
}

/** Maksimum gambar yang diproses dalam satu batch generate. */
const BATCH_MAX_ITEMS = 50;
/** Berapa banyak generate AI yang boleh jalan/menunggu di depan loop apply. */
const BATCH_GENERATE_CONCURRENCY = 3;

/**
 * Prefetch pool untuk generate AI batch.
 *
 * Loop apply tetap serial satu-per-satu (marketplace seperti Miricanvas/Vecteezy/
 * Shutterstock butuh gambar ter-select eksklusif saat mengisi form), tapi panggilan
 * AI yang lambat dijalankan lebih dulu — maksimal `concurrency` hasil yang belum
 * diambil. `take(i)` menunggu hasil gambar ke-i lalu memicu prefetch berikutnya.
 */
function createGeneratePrefetcher({ count, concurrency, startOne, shouldStop }) {
  const slots = new Array(count).fill(null);
  let nextToStart = 0;
  let consumed = 0;
  let stopped = false;

  function startAt(index) {
    slots[index] = Promise.resolve()
      .then(() => startOne(index))
      .then(
        (value) => ({ ok: true, value }),
        (error) => ({ ok: false, error })
      );
  }

  function pump() {
    while (
      !stopped &&
      nextToStart < count &&
      nextToStart - consumed < concurrency &&
      !shouldStop?.()
    ) {
      startAt(nextToStart);
      nextToStart += 1;
    }
  }

  pump();

  return {
    async take(index) {
      if (!slots[index]) startAt(index);
      const settled = await slots[index];
      slots[index] = null;
      consumed = Math.max(consumed, index + 1);
      pump();
      if (!settled.ok) throw settled.error;
      return settled.value;
    },
    stop() {
      stopped = true;
    }
  };
}

/** Opsi generate per gambar — sama persis dengan yang dipakai tiap cabang marketplace. */
function buildBatchGenerateOptions({
  marketplaceKey,
  promptMode,
  imgEl,
  index,
  mcJob,
  vzJob,
  ssJob
}) {
  if (marketplaceKey === "miricanvas") {
    return {
      promptMode,
      marketplaceKey,
      pinnedImageUrl: mcJob?.pinnedUrl || pickMiricanvasThumbnailResourceUrl(imgEl),
      pinnedInlineData: mcJob?.inlineData,
      fallbackUrls: mcJob?.rawUrl ? [mcJob.rawUrl] : [],
      preferPinnedUrlFetch: true,
      batchIndex: index
    };
  }
  if (marketplaceKey === "vecteezy") {
    return {
      promptMode,
      marketplaceKey,
      pinnedImageUrl: vzJob?.pinnedUrl || pickVecteezyThumbnailResourceUrl(imgEl),
      batchIndex: index
    };
  }
  if (marketplaceKey === "shutterstock") {
    return {
      promptMode,
      marketplaceKey,
      pinnedImageUrl: ssJob?.pinnedUrl || pickShutterstockThumbnailResourceUrl(imgEl),
      batchIndex: index
    };
  }
  const adobePinnedUrl = marketplaceKey === "adobe" ? pickAdobeThumbnailResourceUrl(imgEl) : "";
  const magnificPinnedUrl =
    marketplaceKey === "magnific" ? pickMagnificThumbnailResourceUrl(imgEl) : "";
  return {
    promptMode,
    marketplaceKey,
    pinnedImageUrl: adobePinnedUrl || magnificPinnedUrl
  };
}

/** True kalau error berasal dari poin tenant yang habis. */
function isNeronaNoPointsError(error) {
  return String(error?.neronaCode || "") === "no_points";
}

async function generateAndApplyContributorRows({
  button,
  marketplaceKey,
  aiLabel,
  promptMode = "advanced"
}) {
  await ensureNeronaLicenseAccess(marketplaceKey);

  const selectedAll = getContributorSelectionImagesOrFallback();
  if (!selectedAll.length) {
    throw new Error("Gambar tidak terdeteksi. Pilih atau centang aset dulu, lalu klik Generate.");
  }

  const selected = selectedAll.slice(0, BATCH_MAX_ITEMS);
  const overflowCount = selectedAll.length - selected.length;
  if (overflowCount > 0) {
    showNeronaToast(
      `Maksimum ${BATCH_MAX_ITEMS} gambar per batch — ${overflowCount} gambar sisanya dilewati.`
    );
  }

  const miricanvasJobs =
    marketplaceKey === "miricanvas" ? snapshotMiricanvasBatchImages(selected) : null;
  const vecteezyJobs =
    marketplaceKey === "vecteezy" ? snapshotVecteezyBatchImages(selected) : null;
  const shutterstockJobs =
    marketplaceKey === "shutterstock" ? snapshotShutterstockBatchImages(selected) : null;

  ensureNeronaProgressPanel();
  setNeronaProgressSubtext(
    marketplaceKey === "miricanvas"
      ? `Antrian: ${selected.length} gambar — satu per satu (select → isi → deselect).`
      : marketplaceKey === "vecteezy" && selected.length > 1
        ? `Antrian: ${selected.length} gambar — satu per satu (select → isi → deselect).`
        : marketplaceKey === "shutterstock" && selected.length > 1
          ? `Antrian: ${selected.length} gambar — satu per satu (metadata unik per aset).`
          : `Antrian: ${selected.length} gambar (diproses satu per satu).`
  );
  setNeronaProgressBar(0, selected.length);

  showNeronaToast(`Memproses ${selected.length} gambar...`);

  if (marketplaceKey === "miricanvas") {
    await deselectAllMiricanvasGridAssets();
  }

  if (marketplaceKey === "vecteezy" && selected.length > 1) {
    showNeronaToast(`Vecteezy: ${selected.length} gambar — satu per satu (metadata unik per aset).`);
    await deselectAllVecteezyResourceCards();
  }

  if (marketplaceKey === "shutterstock" && selected.length > 1) {
    showNeronaToast(`Shutterstock: ${selected.length} gambar — satu per satu (metadata unik per aset).`);
    await deselectAllShutterstockAssetCards();
  }

  if (marketplaceKey === "adobe" && selected.length > 1) {
    showNeronaToast(
      `Adobe: ${selected.length} gambar — satu per satu (keyword unik per aset).`
    );
  }

  if (marketplaceKey === "magnific" && selected.length > 1) {
    showNeronaToast(`Magnific: ${selected.length} gambar — satu per satu.`);
  }

  if (marketplaceKey === "magnific") {
    await deselectAllMagnificGridAssets();
  }

  let appliedRows = 0;
  let lastMetadata = null;
  const usedScopes = new WeakSet();
  const vecteezyUsedTitleKeys = marketplaceKey === "vecteezy" ? new Set() : null;
  let batchTokenSum = 0;
  let failedCount = 0;
  let skippedNoPoints = 0;
  let pointsExhausted = false;

  // Generate AI dijalankan di depan (maks BATCH_GENERATE_CONCURRENCY sekaligus);
  // pengisian form tetap serial di loop bawah.
  const generatePool = createGeneratePrefetcher({
    count: selected.length,
    concurrency: BATCH_GENERATE_CONCURRENCY,
    shouldStop: () => pointsExhausted || neronaBatchControl.isAborted(),
    startOne: (index) => {
      const job = {
        mcJob: miricanvasJobs?.[index] || null,
        vzJob: vecteezyJobs?.[index] || null,
        ssJob: shutterstockJobs?.[index] || null
      };
      const targetImg =
        job.mcJob?.imgEl || job.vzJob?.imgEl || job.ssJob?.imgEl || selected[index];
      return generateMetadataFromImage(
        aiLabel,
        targetImg,
        (phase, detail) => {
          if (phase === "encode") {
            upsertProgressItem(targetImg, index, { status: "Menyiapkan data gambar..." });
          } else if (phase === "ai") {
            upsertProgressItem(targetImg, index, { status: "Generate: title + keywords..." });
          } else if (phase === "usage") {
            const tok = formatTokenUsageForUi(detail);
            if (tok) upsertProgressItem(targetImg, index, { tokens: tok });
          }
        },
        buildBatchGenerateOptions({
          marketplaceKey,
          promptMode,
          imgEl: targetImg,
          index,
          ...job
        })
      );
    }
  });

  for (let i = 0; i < selected.length; i += 1) {
    const mcJob = miricanvasJobs?.[i] || null;
    const vzJob = vecteezyJobs?.[i] || null;
    const ssJob = shutterstockJobs?.[i] || null;
    const imgEl = mcJob?.imgEl || vzJob?.imgEl || ssJob?.imgEl || selected[i];

    if (neronaBatchControl.isAborted()) {
      upsertProgressItem(imgEl, i, { status: "Dihentikan (Stop)." });
      for (let j = i + 1; j < selected.length; j += 1) {
        upsertProgressItem(selected[j], j, { status: "Dibatalkan (Stop)." });
      }
      setNeronaProgressSubtext(`Dihentikan di gambar ${i + 1}/${selected.length}.`);
      setNeronaProgressBar(i, selected.length);
      break;
    }

    upsertProgressItem(imgEl, i, { status: `Antri (${i + 1}/${selected.length})...`, title: "", keywords: "" });

    setGenerateProgress(button, `${i + 1}/${selected.length} proses gambar`);
    showNeronaToast(`Memproses gambar ${i + 1} dari ${selected.length}...`);
    setNeronaProgressBar(i, selected.length);

    try {
      upsertProgressItem(imgEl, i, { status: "Menyiapkan data gambar..." });

      // ── Miricanvas: generate dulu → select eksklusif → fill → deselect ────────
      // Flow per gambar:
      //   1. Generate AI (tidak butuh gambar ter-select — hanya baca imgEl)
      //   2. Select hanya gambar ini (aggressive isolation jika perlu)
      //   3. Isi field name + keyword
      //   4. Deselect gambar ini (klik langsung, karena diketahui ter-select)
      if (marketplaceKey === "miricanvas") {
        // ── STEP 1: Ambil hasil generate AI (sudah/sedang diproses oleh prefetch pool) ──
        upsertProgressItem(imgEl, i, { status: "Menyiapkan data gambar..." });
        let mcMetadata = await generatePool.take(i);

        if (neronaBatchControl.isAborted()) {
          upsertProgressItem(imgEl, i, { status: "Dihentikan (Stop)." });
          for (let j = i + 1; j < selected.length; j += 1) {
            upsertProgressItem(selected[j], j, { status: "Dibatalkan (Stop)." });
          }
          setNeronaProgressSubtext(`Dihentikan setelah AI — gambar ${i + 1}/${selected.length}.`);
          break;
        }

        lastMetadata = mcMetadata;
        batchTokenSum = addTokenUsageTotals(batchTokenSum, mcMetadata.tokenUsage);
        const mcTokenLine = formatTokenUsageForUi(mcMetadata.tokenUsage);
        if (batchTokenSum > 0) {
          setNeronaProgressSubtext(
            `Antrian: ${selected.length} gambar · Σ token (terlapor API): ${batchTokenSum}`
          );
        }

        // ── STEP 2: Select hanya gambar ini (cari ulang tile via snapshot URL/nama/indeks) ──
        upsertProgressItem(imgEl, i, { status: "Memilih gambar..." });
        const mcTarget = resolveMiricanvasBatchTarget(mcJob);
        const mcRow = mcTarget.row || findMiricanvasTileRowByJob(mcJob);
        const mcTargetImg = mcTarget.imgEl || mcRow?.querySelector?.("img[src]") || imgEl;
        const mcCb = findMiricanvasSelectionControlForRow(mcRow);
        const mcDoClick = () => {
          if (mcCb instanceof HTMLElement) mcCb.click();
          else dispatchPlainClick(mcRow || mcTargetImg);
        };

        // Percobaan 1: klik langsung (berhasil jika sebelumnya 0 gambar ter-select)
        mcDoClick();
        await sleep(500);
        let mcPanelReady = await waitForMiricanvasSingleAssetPanel(3000);
        if (mcPanelReady && readMiricanvasToolbarSelectedCount() > 1) mcPanelReady = false;

        // Percobaan 2: mungkin klik 1 malah meng-deselect (gambar sudah ter-select) — klik lagi
        if (!mcPanelReady) {
          mcDoClick();
          await sleep(500);
          mcPanelReady = await waitForMiricanvasSingleAssetPanel(2000);
          if (mcPanelReady && readMiricanvasToolbarSelectedCount() > 1) mcPanelReady = false;
        }

        // Percobaan 3: isolasi agresif — klik semua gambar LAIN di batch untuk deselect mereka.
        // Gambar ini kemungkinan masih ter-select (net 2 klik = deselect+reselect).
        // Gambar lain yang ter-select akan ter-deselect ketika diklik.
        if (!mcPanelReady && selected.length > 1 && miricanvasJobs?.length) {
          upsertProgressItem(imgEl, i, { status: "Memilih (isolasi)..." });
          for (let j = 0; j < miricanvasJobs.length; j += 1) {
            if (j === i) continue;
            const otherTarget = resolveMiricanvasBatchTarget(miricanvasJobs[j]);
            const otherRow = otherTarget.row || findMiricanvasTileRowByJob(miricanvasJobs[j]);
            const otherCb = findMiricanvasSelectionControlForRow(otherRow);
            if (otherCb instanceof HTMLElement) {
              otherCb.click();
              await sleep(60);
            }
          }
          await sleep(400);
          mcPanelReady = await waitForMiricanvasSingleAssetPanel(2000);
          if (!mcPanelReady) {
            // Jika gambar i ter-deselect setelah isolasi, klik untuk select
            mcDoClick();
            await sleep(400);
            mcPanelReady = await waitForMiricanvasSingleAssetPanel(1500);
          }
        }

        if (!mcPanelReady) {
          upsertProgressItem(imgEl, i, { status: "Panel tidak muncul, lewati." });
          setNeronaProgressBar(i + 1, selected.length);
          continue;
        }

        const freshTarget = resolveMiricanvasBatchTarget(mcJob);
        const freshRow = freshTarget.row || mcRow || findMiricanvasTileRowByJob(mcJob);
        await waitForMiricanvasPanelSynced(mcJob, freshRow, 2800);

        // ── STEP 3: Isi form ─────────────────────────────────────────────────
        upsertProgressItem(imgEl, i, {
          status: "Apply ke form...",
          title: mcMetadata?.fileName || "",
          keywords: formatKeywordsProgressSnippet(mcMetadata?.keywords),
          tokens: mcTokenLine || ""
        });
        const mcNorm = normalizeMetadataForMarketplace(mcMetadata, "miricanvas");
        const mcNameDone = await fillMiricanvasElementNameWithCommit(mcNorm.fileName, document);
        await sleep(160);
        await waitForMiricanvasKeywordInputReady(document, 2000);
        await waitForMiricanvasPanelSynced(mcJob, freshRow, 2200);
        const mcKwDone = await fillMiricanvasKeywordsEnterPerWordAsync(mcNorm.keywords, document, {
          job: mcJob,
          gridRow: freshRow
        });

        // ── STEP 4: Deselect gambar ini ─────────────────────────────────────
        // Panel single-mode baru saja dikonfirmasi → gambar ini PASTI ter-select
        // → satu klik langsung meng-deselect tanpa perlu deteksi state.
        await commitMiricanvasMetadataPanel();
        mcDoClick();
        await sleep(300);

        if (mcNameDone || mcKwDone) {
          appliedRows += 1;
          upsertProgressItem(imgEl, i, {
            status: `Selesai (1 aset${mcKwDone ? ", keyword" : ""}).`
          });
        } else {
          upsertProgressItem(imgEl, i, { status: "Selesai (field tidak ditemukan)." });
        }
        setNeronaProgressBar(i + 1, selected.length);
        continue;
      }

      if (marketplaceKey === "vecteezy") {
        upsertProgressItem(imgEl, i, { status: "Menyiapkan data gambar..." });
        let metadata = await generatePool.take(i);

        if (neronaBatchControl.isAborted()) {
          upsertProgressItem(imgEl, i, { status: "Dihentikan (Stop)." });
          for (let j = i + 1; j < selected.length; j += 1) {
            upsertProgressItem(selected[j], j, { status: "Dibatalkan (Stop)." });
          }
          setNeronaProgressSubtext(`Dihentikan setelah AI — gambar ${i + 1}/${selected.length}.`);
          break;
        }

        if (vecteezyUsedTitleKeys) {
          metadata = applyVecteezyUniqueFileName(metadata, vecteezyUsedTitleKeys, imgEl, i);
        }

        lastMetadata = metadata;
        batchTokenSum = addTokenUsageTotals(batchTokenSum, metadata.tokenUsage);
        const vzTokenLine = formatTokenUsageForUi(metadata.tokenUsage);
        if (batchTokenSum > 0) {
          setNeronaProgressSubtext(
            `Antrian: ${selected.length} gambar · Σ token (terlapor API): ${batchTokenSum}`
          );
        }

        upsertProgressItem(imgEl, i, {
          status: "Memilih gambar...",
          title: metadata?.fileName || "",
          keywords: formatKeywordsProgressSnippet(metadata?.keywords, 18, "vecteezy"),
          tokens: vzTokenLine || ""
        });

        upsertProgressItem(imgEl, i, { status: "Apply ke form..." });
        const vzResult = await applyVecteezyMetadataToSingleAsset(imgEl, metadata, vzJob);
        if (vzResult.ok) {
          appliedRows += 1;
          upsertProgressItem(imgEl, i, { status: "Selesai (1 aset, metadata unik)." });
        } else {
          upsertProgressItem(imgEl, i, { status: "Selesai (field tidak ditemukan)." });
        }
        setNeronaProgressBar(i + 1, selected.length);
        continue;
      }

      if (marketplaceKey === "shutterstock") {
        upsertProgressItem(imgEl, i, { status: "Menyiapkan data gambar..." });
        let metadata = await generatePool.take(i);

        if (neronaBatchControl.isAborted()) {
          upsertProgressItem(imgEl, i, { status: "Dihentikan (Stop)." });
          for (let j = i + 1; j < selected.length; j += 1) {
            upsertProgressItem(selected[j], j, { status: "Dibatalkan (Stop)." });
          }
          setNeronaProgressSubtext(`Dihentikan setelah AI — gambar ${i + 1}/${selected.length}.`);
          break;
        }

        lastMetadata = metadata;
        batchTokenSum = addTokenUsageTotals(batchTokenSum, metadata.tokenUsage);
        const ssTokenLine = formatTokenUsageForUi(metadata.tokenUsage);
        if (batchTokenSum > 0) {
          setNeronaProgressSubtext(
            `Antrian: ${selected.length} gambar · Σ token (terlapor API): ${batchTokenSum}`
          );
        }

        upsertProgressItem(imgEl, i, {
          status: "Memilih gambar...",
          title: metadata?.fileName || "",
          keywords: formatKeywordsProgressSnippet(metadata?.keywords, 18, "shutterstock"),
          tokens: ssTokenLine || ""
        });

        upsertProgressItem(imgEl, i, { status: "Apply ke form..." });
        const ssResult = await applyShutterstockMetadataToSingleAsset(imgEl, metadata, ssJob);
        if (ssResult.ok) {
          appliedRows += 1;
          upsertProgressItem(imgEl, i, { status: "Selesai (1 aset, metadata unik)." });
        } else {
          upsertProgressItem(imgEl, i, { status: "Selesai (field tidak ditemukan)." });
        }
        setNeronaProgressBar(i + 1, selected.length);
        continue;
      }
      // ────────────────────────────────────────────────────────────────────────

      let metadata = await generatePool.take(i);

      if (neronaBatchControl.isAborted()) {
        upsertProgressItem(imgEl, i, { status: "Dihentikan (Stop)." });
        for (let j = i + 1; j < selected.length; j += 1) {
          upsertProgressItem(selected[j], j, { status: "Dibatalkan (Stop)." });
        }
        setNeronaProgressSubtext(`Dihentikan setelah AI — gambar ${i + 1}/${selected.length}.`);
        break;
      }

      if (vecteezyUsedTitleKeys) {
        metadata = applyVecteezyUniqueFileName(metadata, vecteezyUsedTitleKeys, imgEl, i);
      }
      lastMetadata = metadata;
      batchTokenSum = addTokenUsageTotals(batchTokenSum, metadata.tokenUsage);
      const tokenLine = formatTokenUsageForUi(metadata.tokenUsage);
      if (batchTokenSum > 0) {
        setNeronaProgressSubtext(
          `Antrian: ${selected.length} gambar · Σ token (terlapor API): ${batchTokenSum}`
        );
      }
      upsertProgressItem(imgEl, i, {
        status: "Apply ke form...",
        title: metadata?.fileName || "",
        keywords: formatKeywordsProgressSnippet(metadata?.keywords),
        tokens: tokenLine || ""
      });

      if (marketplaceKey === "adobe") {
        const adobeResult = await applyAdobeMetadataToSingleAsset(imgEl, metadata);
        if (adobeResult.ok) {
          appliedRows += 1;
          upsertProgressItem(imgEl, i, { status: "Selesai (1 aset, keyword unik)." });
        } else {
          upsertProgressItem(imgEl, i, { status: "Selesai (field tidak ditemukan)." });
        }
        continue;
      }

      if (marketplaceKey === "magnific") {
        const mfResult = await applyMagnificMetadataToSingleAsset(imgEl, metadata);
        if (mfResult.ok) {
          appliedRows += 1;
          upsertProgressItem(imgEl, i, { status: "Selesai (1 aset)." });
        } else {
          upsertProgressItem(imgEl, i, { status: "Selesai (field tidak ditemukan)." });
        }
        continue;
      }

      let scope = findAdobeRowForImage(imgEl);
      if (scope && usedScopes.has(scope)) {
        scope = null;
      }
      if (scope && marketplaceKey !== "adobe") {
        const r = applyMarketplaceMetadataInScope(scope, metadata, marketplaceKey);
        if (r.ok) {
          usedScopes.add(scope);
          appliedRows += 1;
          if (marketplaceKey === "vecteezy" || marketplaceKey === "miricanvas") {
            if (neronaBatchControl.isAborted()) {
              upsertProgressItem(imgEl, i, { status: "Dihentikan (Stop)." });
              for (let j = i + 1; j < selected.length; j += 1) {
                upsertProgressItem(selected[j], j, { status: "Dibatalkan (Stop)." });
              }
              break;
            }
            upsertProgressItem(imgEl, i, { status: "Mengisi tag keyword..." });
            if (marketplaceKey === "vecteezy") {
              await applyVecteezyTagsAfterMetadata(metadata, scope);
            } else {
              await applyMiricanvasTagsAfterMetadata(metadata, scope);
            }
          }
          upsertProgressItem(imgEl, i, { status: "Selesai (terisi per item)." });
          continue;
        }
      }

      const result = applyGeneric(marketplaceSelectors[marketplaceKey], metadata, marketplaceKey);
      if (result.ok) {
        if (marketplaceKey === "vecteezy" || marketplaceKey === "miricanvas") {
          if (neronaBatchControl.isAborted()) {
            upsertProgressItem(imgEl, i, { status: "Dihentikan (Stop)." });
            for (let j = i + 1; j < selected.length; j += 1) {
              upsertProgressItem(selected[j], j, { status: "Dibatalkan (Stop)." });
            }
            break;
          }
          upsertProgressItem(imgEl, i, { status: "Mengisi tag keyword..." });
          if (marketplaceKey === "vecteezy") {
            await applyVecteezyTagsAfterMetadata(metadata, null);
          } else {
            await applyMiricanvasTagsAfterMetadata(metadata, null);
          }
        }
        upsertProgressItem(imgEl, i, { status: "Selesai (terisi ke bulk-edit)." });
      } else {
        upsertProgressItem(imgEl, i, { status: "Selesai (field tidak ditemukan)." });
      }
    } catch (error) {
      const msg = String(error?.message || "Gagal memproses gambar.");
      if (isNeronaNoPointsError(error)) {
        // Poin tenant habis: hentikan antrian sisanya (yang sudah in-flight tetap selesai).
        pointsExhausted = true;
        generatePool.stop();
        failedCount += 1;
        upsertProgressItem(imgEl, i, { status: "Poin habis." });
        showNeronaToast("Poin Nerona habis. Sisa gambar dilewati.");
        for (let j = i + 1; j < selected.length; j += 1) {
          skippedNoPoints += 1;
          upsertProgressItem(selected[j], j, { status: "Dilewati (poin habis)." });
        }
        setNeronaProgressBar(selected.length, selected.length);
        break;
      }
      if (isQuotaLimitError(0, msg)) {
        generatePool.stop();
        failedCount += 1;
        upsertProgressItem(imgEl, i, { status: "Dihentikan: limit API/kuota tercapai." });
        showNeronaToast("Limit API AI habis. Proses dihentikan.");
        for (let j = i + 1; j < selected.length; j += 1) {
          upsertProgressItem(selected[j], j, { status: "Dihentikan: limit API/kuota." });
        }
        setNeronaProgressSubtext(`Berhenti di gambar ${i + 1}/${selected.length} karena limit API/kuota.`);
        setNeronaProgressBar(i + 1, selected.length);
        break;
      }
      failedCount += 1;
      upsertProgressItem(imgEl, i, { status: `Error: ${msg.slice(0, 120)}` });
    }
  }

  generatePool.stop();
  setNeronaProgressBar(selected.length, selected.length);

  const summary =
    `Selesai: ${appliedRows} berhasil, ${failedCount} gagal` +
    (skippedNoPoints > 0 ? ` (${skippedNoPoints} dilewati karena poin habis)` : "") +
    ` dari ${selected.length}.` +
    (overflowCount > 0 ? ` ${overflowCount} gambar di luar batas ${BATCH_MAX_ITEMS} tidak diproses.` : "");
  setNeronaProgressSubtext(summary);
  showNeronaToast(summary);

  return {
    appliedRows,
    total: selected.length,
    lastMetadata,
    failedCount,
    skippedNoPoints,
    overflowCount,
    summary
  };
}

async function removeMetadataContributorRows({ removeButton, marketplaceKey }) {
  const selected = getContributorSelectionImagesOrFallback();
  if (!selected.length) {
    throw new Error("Gambar tidak terdeteksi. Pilih atau centang aset dulu, lalu klik Remove Metadata.");
  }

  ensureNeronaProgressPanel();
  setNeronaProgressSubtext(`Menghapus metadata: ${selected.length} gambar…`);
  setNeronaProgressBar(0, selected.length);

  let clearedRows = 0;
  const usedScopes = new WeakSet();

  for (let i = 0; i < selected.length; i += 1) {
    const imgEl = selected[i];

    if (neronaBatchControl.isAborted()) {
      upsertProgressItem(imgEl, i, { status: "Dihentikan (Stop)." });
      for (let j = i + 1; j < selected.length; j += 1) {
        upsertProgressItem(selected[j], j, { status: "Dibatalkan (Stop)." });
      }
      setNeronaProgressSubtext(`Penghapusan dihentikan — gambar ${i + 1}/${selected.length}.`);
      setNeronaProgressBar(i, selected.length);
      break;
    }

    upsertProgressItem(imgEl, i, {
      status: `Menghapus (${i + 1}/${selected.length})…`,
      title: "",
      keywords: ""
    });
    setRemoveProgress(removeButton, `${i + 1}/${selected.length}`);
    showNeronaToast(`Menghapus metadata gambar ${i + 1}/${selected.length}…`);
    setNeronaProgressBar(i, selected.length);

    let scope = findAdobeRowForImage(imgEl);
    if (scope && usedScopes.has(scope)) {
      scope = null;
    }

    if (scope) {
      const r = clearMarketplaceMetadataInScope(scope, marketplaceKey);
      if (r.ok) {
        clearedRows += 1;
        usedScopes.add(scope);

        if (marketplaceKey === "vecteezy") {
          upsertProgressItem(imgEl, i, { status: "Menghapus tag keyword…" });
          await removeAllVecteezyTagsAsync(scope, () => !neronaBatchControl.isAborted());
        } else if (marketplaceKey === "miricanvas") {
          upsertProgressItem(imgEl, i, { status: "Menghapus tag keyword…" });
          await removeAllMiricanvasTagsAsync(scope, () => !neronaBatchControl.isAborted());
        }

        if (neronaBatchControl.isAborted()) {
          upsertProgressItem(imgEl, i, { status: "Dihentikan (Stop)." });
          for (let j = i + 1; j < selected.length; j += 1) {
            upsertProgressItem(selected[j], j, { status: "Dibatalkan (Stop)." });
          }
          break;
        }

        upsertProgressItem(imgEl, i, { status: "Metadata dikosongkan (baris)." });
        continue;
      }
      /* Kosongkan per-baris gagal — coba fallback form global seperti saat tidak ada scope. */
    }

    const bulk = clearGenericMetadata(marketplaceSelectors[marketplaceKey], marketplaceKey);
    if (bulk.ok) clearedRows += 1;

    if (marketplaceKey === "vecteezy") {
      upsertProgressItem(imgEl, i, { status: "Menghapus tag keyword…" });
      await removeAllVecteezyTagsAsync(null, () => !neronaBatchControl.isAborted());
    } else if (marketplaceKey === "miricanvas") {
      upsertProgressItem(imgEl, i, { status: "Menghapus tag keyword…" });
      await removeAllMiricanvasTagsAsync(null, () => !neronaBatchControl.isAborted());
    }

    if (neronaBatchControl.isAborted()) {
      upsertProgressItem(imgEl, i, { status: "Dihentikan (Stop)." });
      for (let j = i + 1; j < selected.length; j += 1) {
        upsertProgressItem(selected[j], j, { status: "Dibatalkan (Stop)." });
      }
      break;
    }

    upsertProgressItem(imgEl, i, {
      status: bulk.ok ? "Metadata dikosongkan." : "Gagal mengosongkan (field tidak terdeteksi)."
    });
  }

  setNeronaProgressBar(selected.length, selected.length);
  return { clearedRows, total: selected.length };
}

async function generateAndApplyAdobePerImage(button) {
  const buildPickerState = () => {
    const nextCandidates = getAnalyzableImageCandidates();
    const preselectSrcKeys = isAdobeContributorHost()
      ? new Set(
          findAdobeExplicitlyCheckedImageElements()
            .map((img) => img.currentSrc || img.src)
            .filter(Boolean)
        )
      : null;
    return { candidates: nextCandidates, preselectSrcKeys };
  };

  const initial = buildPickerState();
  const selected = await askUserToPickImages(initial.candidates, {
    preselectSrcKeys: initial.preselectSrcKeys,
    refreshPickerState: buildPickerState
  });
  if (!selected.length) {
    throw new Error("Belum ada gambar dipilih untuk dianalisa.");
  }

  let appliedRows = 0;
  let lastMetadata = null;
  const usedScopes = new WeakSet();

  for (let i = 0; i < selected.length; i += 1) {
    const imgEl = selected[i];
    setGenerateProgress(button, `${i + 1}/${selected.length} proses gambar`);
    showNeronaToast(`Memproses gambar ${i + 1} dari ${selected.length}...`);

    const metadata = await generateMetadataFromImage("Adobe Stock", imgEl, (phase) => {
      if (phase === "encode") {
        showNeronaToast(`Gambar ${i + 1}/${selected.length}: menyiapkan data gambar...`);
      } else if (phase === "ai") {
        showNeronaToast(`Gambar ${i + 1}/${selected.length}: generate keyword + title...`);
      }
    }, { marketplaceKey: "adobe" });
    const tk = formatTokenUsageForUi(metadata.tokenUsage);
    if (tk) showNeronaToast(`${tk} · selesai ${i + 1}/${selected.length}`);
    lastMetadata = metadata;

    const adobeResult = await applyAdobeMetadataToSingleAsset(imgEl, metadata);
    if (adobeResult.ok) {
      appliedRows += 1;
    }
  }

  return { appliedRows, total: selected.length, lastMetadata };
}

function getAdobeSelectedImagesOrFallback() {
  return getContributorSelectionImagesOrFallback();
}

async function generateAndApplyAdobeFromCurrentSelection(button) {
  return generateAndApplyContributorRows({ button, marketplaceKey: "adobe", aiLabel: "Adobe Stock" });
}

async function generateFromPickedImages(marketplace, button, options = {}) {
  const aiDisplayName = options.aiDisplayName || marketplace;
  const useProgressPanel = Boolean(options.useProgressPanel && button);

  const buildPickerState = () => {
    const nextCandidates = getAnalyzableImageCandidates();
    const preselectSrcKeys =
      marketplace === "Adobe Stock" && isAdobeContributorHost()
        ? new Set(
            findAdobeExplicitlyCheckedImageElements()
              .map((img) => img.currentSrc || img.src)
              .filter(Boolean)
          )
        : marketplace === "Shutterstock" && isShutterstockContributorHost()
          ? new Set(
              getShutterstockSelectedImages()
                .map((img) => img.currentSrc || img.src)
                .filter(Boolean)
            )
          : null;
    return { candidates: nextCandidates, preselectSrcKeys };
  };

  const initial = buildPickerState();
  const selected = await askUserToPickImages(initial.candidates, {
    preselectSrcKeys: initial.preselectSrcKeys,
    refreshPickerState: buildPickerState
  });
  if (!selected.length) {
    throw new Error("Belum ada gambar dipilih untuk dianalisa.");
  }

  if (useProgressPanel) {
    ensureNeronaProgressPanel();
    setNeronaProgressSubtext(`Antrian: ${selected.length} gambar (picker).`);
    setNeronaProgressBar(0, selected.length);
  }

  let mergedMetadata = null;
  const vecteezyPickerTitleKeys = /vecteezy/i.test(String(aiDisplayName)) ? new Set() : null;
  let pickerTokenSum = 0;

  for (let i = 0; i < selected.length; i += 1) {
    setGenerateProgress(button, `${i + 1}/${selected.length} proses gambar`);
    showNeronaToast(`Memproses gambar ${i + 1} dari ${selected.length}...`);

    if (useProgressPanel) {
      setNeronaProgressBar(i, selected.length);
      upsertProgressItem(selected[i], i, { status: `Antri (${i + 1}/${selected.length})...`, title: "", keywords: "" });
    }

    try {
      if (useProgressPanel) {
        upsertProgressItem(selected[i], i, { status: "Menyiapkan data gambar..." });
      }

      let metadata = await generateMetadataFromImage(
        aiDisplayName,
        selected[i],
        (phase, detail) => {
          if (phase === "encode") {
            showNeronaToast(`Gambar ${i + 1}/${selected.length}: menyiapkan data gambar...`);
            if (useProgressPanel) {
              upsertProgressItem(selected[i], i, { status: "Menyiapkan data gambar..." });
            }
          } else if (phase === "ai") {
            showNeronaToast(`Gambar ${i + 1}/${selected.length}: generate keyword + title...`);
            if (useProgressPanel) {
              upsertProgressItem(selected[i], i, { status: "Generate title + keywords..." });
            }
          } else if (phase === "usage" && useProgressPanel) {
            const tok = formatTokenUsageForUi(detail);
            if (tok) upsertProgressItem(selected[i], i, { tokens: tok });
          }
        },
        { marketplaceKey: resolveMarketplaceKeyFromLabel(aiDisplayName) }
      );

      if (vecteezyPickerTitleKeys) {
        metadata = applyVecteezyUniqueFileName(metadata, vecteezyPickerTitleKeys, selected[i], i);
      }

      /** Satu form — ambil metadata gambar terakhir saja agar keyword tidak tercampur antar gambar */
      mergedMetadata = metadata;

      if (useProgressPanel) {
        pickerTokenSum = addTokenUsageTotals(pickerTokenSum, metadata.tokenUsage);
        const tokenLine = formatTokenUsageForUi(metadata.tokenUsage);
        if (pickerTokenSum > 0) {
          setNeronaProgressSubtext(
            `Antrian: ${selected.length} gambar (picker) · Σ token (terlapor API): ${pickerTokenSum}`
          );
        }
        upsertProgressItem(selected[i], i, {
          status: "Selesai",
          title: metadata?.fileName || "",
          keywords: formatKeywordsProgressSnippet(metadata?.keywords),
          tokens: tokenLine || ""
        });
      }
    } catch (error) {
      const msg = String(error?.message || "Gagal memproses gambar.");
      if (useProgressPanel) {
        upsertProgressItem(selected[i], i, { status: `Error: ${msg.slice(0, 120)}` });
      }
      if (isQuotaLimitError(0, msg)) {
        showNeronaToast("Limit API AI habis.");
        break;
      }
      throw error;
    }
  }

  if (useProgressPanel) {
    setNeronaProgressBar(selected.length, selected.length);
  }

  return mergedMetadata;
}

function detectCheckedAssetsCount() {
  const selectors = [
    'input[type="checkbox"][aria-checked="true"]',
    'input[type="checkbox"]:checked',
    '[role="checkbox"][aria-checked="true"]'
  ];
  let count = 0;
  for (const selector of selectors) {
    count = Math.max(count, document.querySelectorAll(selector).length);
  }
  return count;
}

async function toastAfterRowBasedGenerate(cfg, { appliedRows, total, lastMetadata }) {
  const selectors = marketplaceSelectors[cfg.marketplaceKey];
  if (!selectors) return;

  if (cfg.marketplaceKey === "adobe") {
    if (appliedRows >= total && appliedRows > 0) {
      showNeronaToast(
        `Adobe Stock: metadata + keyword unik per aset (${appliedRows}/${total}). Setiap gambar diproses satu per satu.`
      );
    } else if (appliedRows > 0) {
      showNeronaToast(
        `Adobe Stock: ${appliedRows}/${total} aset terisi. Sisanya gagal — pastikan grid upload terbuka, lalu coba lagi.`
      );
    } else {
      showNeronaToast(
        "Adobe Stock: field metadata tidak ditemukan. Buka halaman upload, pilih satu aset di grid, lalu Generate lagi."
      );
    }
    return;
  }

  if (appliedRows >= total && appliedRows > 0) {
    if (cfg.marketplaceKey === "vecteezy") {
      const tagCount = getVecteezyExistingTags().size;
      showNeronaToast(`Vecteezy: ${appliedRows}/${total} gambar selesai. Tag: ${tagCount}.`);
    } else if (cfg.marketplaceKey === "miricanvas") {
      const tagCount = getMiricanvasExistingTags().size;
      showNeronaToast(`Miricanvas: ${appliedRows}/${total} gambar selesai. Tag: ${tagCount}.`);
    } else {
      showNeronaToast(`Metadata AI terisi per gambar (${appliedRows}/${total}).`);
    }
  } else if (appliedRows > 0 && lastMetadata) {
    showNeronaToast(
      `Metadata AI terisi ${appliedRows}/${total} gambar. Mengisi form dengan metadata gambar terakhir...`
    );
    applyGeneric(selectors, lastMetadata, cfg.marketplaceKey);
    if (cfg.marketplaceKey === "vecteezy") {
      await applyVecteezyTagsAfterMetadata(lastMetadata, null);
      showNeronaToast(`Vecteezy: tag diperbarui (${getVecteezyExistingTags().size}).`);
    } else if (cfg.marketplaceKey === "miricanvas") {
      await applyMiricanvasTagsAfterMetadata(lastMetadata, null);
      showNeronaToast(`Miricanvas: tag diperbarui (${getMiricanvasExistingTags().size}).`);
    }
  } else if (lastMetadata) {
    showNeronaToast("Mengisi metadata ke formulir...");
    const result = applyGeneric(selectors, lastMetadata, cfg.marketplaceKey);
    if (result.ok) {
      if (cfg.marketplaceKey === "vecteezy") {
        await applyVecteezyTagsAfterMetadata(lastMetadata, null);
        showNeronaToast(`Vecteezy: formulir OK. Tag: ${getVecteezyExistingTags().size}.`);
      } else if (cfg.marketplaceKey === "miricanvas") {
        await applyMiricanvasTagsAfterMetadata(lastMetadata, null);
        showNeronaToast(`Miricanvas: formulir OK. Tag: ${getMiricanvasExistingTags().size}.`);
      } else {
        showNeronaToast("Metadata AI berhasil diisi ke formulir.");
      }
    } else {
      showNeronaToast("Field metadata tidak ditemukan. Scroll ke form judul/keyword lalu coba lagi.");
    }
  } else {
    showNeronaToast("Field metadata tidak ditemukan.");
  }
}

function setContributorGenerateButtonsDisabled(disabled) {
  for (const id of [
    "nerona-generate-advanced-btn",
    "nerona-ai-scoring-btn",
    "nerona-keyword-ai-btn",
    "nerona-commercial-intent-btn"
  ]) {
    const b = document.getElementById(id);
    if (!b) continue;
    b.disabled = disabled;
    b.style.opacity = disabled ? "0.75" : "1";
  }
}

async function runContributorMetadataGenerate(btn, cfg, promptMode) {
  if (!btn || btn.disabled) return;
  neronaBatchControl.reset();
  showStopOperationButton();
  try {
    closeVecteezyBlockingModalIfAny();
    setGenerateProgress(btn, "persiapan");
    showNeronaToast("Menyiapkan proses generate metadata...");
    setContributorGenerateButtonsDisabled(true);

    const payload = await generateAndApplyContributorRows({
      button: btn,
      marketplaceKey: cfg.marketplaceKey,
      aiLabel: cfg.aiLabel,
      promptMode
    });
    setGenerateProgress(btn, "apply");
    await toastAfterRowBasedGenerate(cfg, payload);
    if (neronaBatchControl.isAborted()) {
      showNeronaToast(`${cfg.aiLabel}: generate dihentikan (Stop).`);
    }
  } catch (error) {
    if (isQuotaLimitError(0, error?.message || "")) {
      showNeronaToast("Limit API AI habis.");
    } else {
      showNeronaToast(error?.message || "Gagal generate metadata otomatis.");
    }
  } finally {
    hideStopOperationButton();
    neronaBatchControl.reset();
    setContributorGenerateButtonsDisabled(false);
    resetGenerateProgress(btn);
  }
}

function ensureGenerateActionsRow(parent) {
  let row = document.getElementById("nerona-generate-actions-row");
  if (!row) {
    row = document.createElement("div");
    row.id = "nerona-generate-actions-row";
    row.style.display = "flex";
    row.style.flexDirection = "column";
    row.style.gap = "8px";
    row.style.width = "100%";
    parent.appendChild(row);
  } else if (row.parentElement !== parent) {
    parent.appendChild(row);
  }
  return row;
}

function ensureCommercialIntentActionsRow(parent) {
  let row = document.getElementById("nerona-commercial-intent-row");
  if (!row) {
    row = document.createElement("div");
    row.id = "nerona-commercial-intent-row";
    row.style.display = "flex";
    row.style.width = "100%";
    parent.appendChild(row);
  } else if (row.parentElement !== parent) {
    parent.appendChild(row);
  }
  return row;
}

function installCommercialIntentButton(parent, cfg) {
  const row = ensureCommercialIntentActionsRow(parent);
  let btn = document.getElementById("nerona-commercial-intent-btn");
  if (!btn) {
    btn = document.createElement("button");
    btn.id = "nerona-commercial-intent-btn";
    btn.type = "button";
    styleCommercialIntentButton(btn);
    decorateNeronaActionButton(btn, {
      label: "Commercial Intent Analyzer",
      iconType: "commercial"
    });
    btn.addEventListener("click", async () => {
      if (btn.disabled) return;
      btn.disabled = true;
      btn.style.opacity = "0.85";
      setContributorGenerateButtonsDisabled(true);
      setNeronaActionButtonProgress(btn, "menganalisis");
      showNeronaToast("Commercial Intent: menganalisis tujuan komersial gambar…");
      try {
        const aiOut = await runCommercialIntentAnalyzer(cfg);
        const tokenHint = formatTokenUsageForUi(aiOut.usage);
        showNeronaToast(
          tokenHint
            ? `Commercial Intent selesai — ${tokenHint}`
            : "Commercial Intent Analyzer selesai."
        );
        showCommercialIntentResultPanel("Commercial Intent Analyzer — hasil", aiOut.text || "");
      } catch (error) {
        const msg = String(error?.message || "Gagal analisis commercial intent.");
        showNeronaToast(msg);
        showCommercialIntentResultPanel("Commercial Intent Analyzer — error", msg);
      } finally {
        btn.disabled = false;
        btn.style.opacity = "1";
        setContributorGenerateButtonsDisabled(false);
        resetNeronaActionButton(btn);
      }
    });
    row.appendChild(btn);
  } else {
    styleCommercialIntentButton(btn);
    decorateNeronaActionButton(btn, {
      label: "Commercial Intent Analyzer",
      iconType: "commercial"
    });
    if (btn.parentElement !== row) row.appendChild(btn);
  }
  return btn;
}

function installAiScoringButton(row, cfg) {
  let scoringBtn = document.getElementById("nerona-ai-scoring-btn");
  if (!scoringBtn) {
    scoringBtn = document.createElement("button");
    scoringBtn.id = "nerona-ai-scoring-btn";
    scoringBtn.type = "button";
    styleScoringAgentButton(scoringBtn);
    decorateNeronaActionButton(scoringBtn, {
      label: "AI Scoring Agent",
      iconType: "scoring"
    });
    scoringBtn.addEventListener("click", async () => {
      if (scoringBtn.disabled) return;
      scoringBtn.disabled = true;
      scoringBtn.style.opacity = "0.7";
      showNeronaToast("AI Scoring Agent: menganalisa gambar…");
      try {
        const aiOut = await runAiScoringAgent(cfg);
        const tokenHint = formatTokenUsageForUi(aiOut.usage);
        showNeronaToast(
          tokenHint ? `AI Scoring selesai — ${tokenHint}` : "AI Scoring selesai."
        );
        showAiScoringResultPanel("AI Scoring Agent — hasil", aiOut.text || "");
      } catch (error) {
        const msg = String(error?.message || "Gagal analisa skor.");
        showNeronaToast(msg);
        showAiScoringResultPanel("AI Scoring Agent — error", msg);
      } finally {
        scoringBtn.disabled = false;
        scoringBtn.style.opacity = "1";
      }
    });
    row.appendChild(scoringBtn);
  } else {
    styleScoringAgentButton(scoringBtn);
    decorateNeronaActionButton(scoringBtn, {
      label: "AI Scoring Agent",
      iconType: "scoring"
    });
    scoringBtn.style.width = "100%";
    if (scoringBtn.parentElement !== row) row.appendChild(scoringBtn);
  }
  return scoringBtn;
}

function installKeywordAiButton(row, cfg) {
  let kwBtn = document.getElementById("nerona-keyword-ai-btn");
  if (!kwBtn) {
    kwBtn = document.createElement("button");
    kwBtn.id = "nerona-keyword-ai-btn";
    kwBtn.type = "button";
    styleKeywordAiButton(kwBtn);
    decorateNeronaActionButton(kwBtn, {
      label: "Keyword AI",
      iconType: "keyword"
    });
    kwBtn.addEventListener("click", async () => {
      if (kwBtn.disabled) return;
      const months = getEventKeywordResearchMonthContext();
      kwBtn.disabled = true;
      kwBtn.style.opacity = "0.85";
      setContributorGenerateButtonsDisabled(true);
      setNeronaActionButtonProgress(kwBtn, "memulai");
      beginKeywordAiProgressPanel(months);
      showNeronaToast(`Keyword AI: riset ${months.current} & ${months.next}…`);

      try {
        const aiOut = await runEventKeywordResearch(cfg, (phase, monthCtx, usage) => {
          if (phase === "usage") {
            const tokenLine = formatTokenUsageForUi(usage);
            setKeywordAiProgressPanel("ai", monthCtx, tokenLine);
            if (tokenLine) setNeronaActionButtonProgress(kwBtn, tokenLine.replace(/^Token:\s*/i, ""));
            return;
          }
          const stepLabels = {
            license: "lisensi",
            prepare: "menyiapkan",
            ai: "riset AI",
            parse: "memproses"
          };
          setKeywordAiProgressPanel(phase, monthCtx, "");
          setNeronaActionButtonProgress(kwBtn, stepLabels[phase] || "memproses");
          if (phase === "ai") {
            showNeronaToast(`Keyword AI: menganalisis ${monthCtx.current} & ${monthCtx.next}…`);
          }
        });

        setKeywordAiProgressPanel("done", months, formatTokenUsageForUi(aiOut.usage));
        const tokenHint = formatTokenUsageForUi(aiOut.usage);
        showNeronaToast(
          tokenHint
            ? `Keyword AI selesai — ${tokenHint}`
            : "Keyword AI selesai."
        );
        showKeywordAiResultPanel(
          `Keyword AI — ${months.current} & ${months.next}`,
          aiOut.text || ""
        );
        endKeywordAiProgressPanel(true);
      } catch (error) {
        const msg = String(error?.message || "Gagal riset keyword.");
        setKeywordAiProgressPanel("error", { ...months, error: msg }, "");
        showNeronaToast(msg);
        showKeywordAiResultPanel("Keyword AI — error", msg);
        endKeywordAiProgressPanel(true);
      } finally {
        kwBtn.disabled = false;
        kwBtn.style.opacity = "1";
        setContributorGenerateButtonsDisabled(false);
        resetNeronaActionButton(kwBtn);
      }
    });
    row.appendChild(kwBtn);
  } else {
    styleKeywordAiButton(kwBtn);
    decorateNeronaActionButton(kwBtn, {
      label: "Keyword AI",
      iconType: "keyword"
    });
    if (kwBtn.parentElement !== row) row.appendChild(kwBtn);
  }
  return kwBtn;
}

function installMarketplaceGenerateButtons(bar, cfg) {
  document.getElementById("nerona-quick-generate-btn")?.remove();
  document.getElementById("nerona-generate-quick-btn")?.remove();

  const wrap = ensureFloatingActionsWrap(bar);
  const genSpec = {
    id: "nerona-generate-advanced-btn",
    label: "Generate Metadata",
    promptMode: "advanced",
    style: styleGenerateAdvancedButton
  };

  let genBtn = document.getElementById(genSpec.id);
  if (!genBtn) {
    genBtn = document.createElement("button");
    genBtn.id = genSpec.id;
    genBtn.type = "button";
    genSpec.style(genBtn);
    decorateGenerateButtonContents(genBtn, genSpec.label);
    genBtn.style.width = "100%";
    genBtn.addEventListener("click", () => {
      runContributorMetadataGenerate(genBtn, cfg, genSpec.promptMode);
    });
    wrap.insertBefore(genBtn, wrap.firstChild);
  } else {
    decorateGenerateButtonContents(genBtn, genSpec.label);
    genBtn.style.width = "100%";
    genBtn.style.flex = "";
    if (genBtn.parentElement !== wrap) {
      wrap.insertBefore(genBtn, wrap.firstChild);
    } else if (wrap.firstChild !== genBtn) {
      wrap.insertBefore(genBtn, wrap.firstChild);
    }
  }

  const row = ensureGenerateActionsRow(wrap);
  installAiScoringButton(row, cfg);
  installKeywordAiButton(row, cfg);
  installCommercialIntentButton(wrap, cfg);
}

function installMarketplaceQuickGenerateButton() {
  const cfg = resolveQuickGenerateMarketplace();
  if (!cfg) return;

  let bar = document.getElementById("nerona-floating-bar");
  if (bar) {
    bar.querySelector("#nerona-remove-metadata-btn")?.remove();
  } else {
    bar = document.createElement("div");
    bar.id = "nerona-floating-bar";
    bar.setAttribute("data-nerona-overlay", "1");
    document.body.appendChild(bar);
  }
  styleFloatingActionBar(bar);

  installFloatingBarToggle(bar);
  installMarketplaceGenerateButtons(bar, cfg);

  void maybeStartRejectAnalyzerUi(cfg);
}

(() => {
  const rt = extensionRuntime();
  if (!rt?.onMessage?.addListener) return;

  rt.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "CLEAR_MARKETPLACE_METADATA") {
    const { marketplace } = message.payload || {};
    const key = marketplace;
    const selectors = marketplaceSelectors[key];

    const runClear = async () => {
      if (!selectors) {
        sendResponse({
          ok: false,
          reason: `Marketplace "${key}" tidak didukung. Pakai: adobe | magnific | vecteezy | shutterstock | canva | miricanvas | designbundle | dreamstime.`
        });
        return;
      }
      closeVecteezyBlockingModalIfAny();
      const bulk = clearGenericMetadata(selectors, key);
      let tagStripped = false;
      if (key === "vecteezy") {
        await removeAllVecteezyTagsAsync(null, () => true);
        tagStripped = getVecteezyExistingTags().size === 0;
      } else if (key === "miricanvas") {
        await removeAllMiricanvasTagsAsync(null, () => true);
        tagStripped = getMiricanvasExistingTags().size === 0;
      }
      sendResponse({
        ...bulk,
        marketplace: key,
        vecteezyTagsCleared: key === "vecteezy" ? tagStripped : undefined,
        miricanvasTagsCleared: key === "miricanvas" ? tagStripped : undefined
      });
    };

    runClear().catch((e) =>
      sendResponse({ ok: false, reason: String(e?.message || e), marketplace: key })
    );
    return true;
  }

  if (message?.type !== "APPLY_MARKETPLACE_METADATA") return false;

  const { metadata, marketplace } = message.payload || {};
  const selectors = marketplaceSelectors[marketplace];
  if (!selectors) {
    sendResponse({ ok: false, reason: "Marketplace tidak didukung." });
    return false;
  }

  if (marketplace === "vecteezy") {
    closeVecteezyBlockingModalIfAny();
  }
  const normalized = normalizeMetadataForMarketplace(metadata, marketplace);
  const result = applyGeneric(selectors, normalized, marketplace);
  sendResponse({ ...result, marketplace });
  return false;
});
})();

/** Canva / Miricanvas / Shutterstock / Dreamstime SPA: navigasi client-side tidak memuat ulang content script — pasang UI saat URL berubah. */
(function neronaWatchContributorsSpaNavigation() {
  const h = String(location.hostname || "").toLowerCase();
  const path = String(location.pathname || "").toLowerCase();
  const onCanva = /\.canva\.com$/i.test(h);
  const onMiri =
    /\.miricanvas\.com$/i.test(h) || /^miricanvas\.com$/i.test(h);
  const onShutterstockSubmit = h === "submit.shutterstock.com";
  const onDreamstimeUpload =
    (h === "www.dreamstime.com" || h === "dreamstime.com") &&
    (path.startsWith("/upload") || path.includes("/upload/"));
  if (!onCanva && !onMiri && !onShutterstockSubmit && !onDreamstimeUpload) return;
  let last = location.href;
  setInterval(() => {
    try {
      if (location.href === last) return;
      last = location.href;
      if (typeof resolveQuickGenerateMarketplace === "function" && resolveQuickGenerateMarketplace()) {
        installMarketplaceQuickGenerateButton();
      }
    } catch (_e) {
      /* ignore */
    }
  }, 700);
})();

if (resolveQuickGenerateMarketplace()) {
  installMarketplaceQuickGenerateButton();
}
