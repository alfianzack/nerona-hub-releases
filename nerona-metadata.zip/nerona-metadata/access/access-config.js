/**
 * Konfigurasi akses lisensi Nerona.
 */
globalThis.NERONA_ACCESS_CONFIG = {
  /** true = wajib lisensi valid; false = lewati cek (dev lokal) */
  enforce: true,
  /** Cache hasil verifikasi per lisensi (ms) */
  cacheTtlMs: 15 * 60 * 1000,

  /**
   * URL nerona-web (tempat akun & poin).
   *
   * Nilai ini TIDAK bisa dipindah ke database — inilah alamat yang dipakai untuk
   * menghubungi database itu sendiri, jadi menyimpannya di sana melingkar.
   * Karena itu diganti manual per rilis.
   *
   * Produksi: https://nerona-web.vercel.app
   * Dev lokal: http://localhost:3000  ← tukar ke ini kalau kembali ngoprek lokal,
   * lalu reload extension di chrome://extensions.
   */
  neronaWebBaseUrl: "https://nerona-web.vercel.app"
};
