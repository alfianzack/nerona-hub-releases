/**
 * Perbandingan nomor versi extension.
 *
 * Kembaran dari `bandingkanVersi`/`butuhPembaruan`/`diBawahMinimum` di
 * `nerona-web/src/lib/unduhan.ts`, dan memang harus sama persis: server yang
 * berwenang memblokir, sisi ini yang menolak lebih dulu supaya poin tidak
 * terlanjur terbakar. Dua jawaban yang berbeda atas pertanyaan yang sama akan
 * muncul sebagai "kata extension boleh, kata server tidak" — bug yang sangat
 * sulit dilacak dari laporan pengguna.
 *
 * Dimuat di TIGA konteks: service worker, popup, dan content script.
 */
(function () {
  /** Versi yang benar-benar terpasang, atau "" kalau `chrome.runtime` tak terbaca. */
  function terpasang() {
    try {
      if (typeof chrome !== "undefined" && chrome.runtime?.getManifest) {
        return String(chrome.runtime.getManifest().version || "").trim();
      }
      if (typeof browser !== "undefined" && browser.runtime?.getManifest) {
        return String(browser.runtime.getManifest().version || "").trim();
      }
    } catch (_e) {
      /* ignore */
    }
    return "";
  }

  function tidakDiketahui(versi) {
    const teks = String(versi || "").trim();
    return !teks || teks === "?";
  }

  /**
   * Negatif kalau `a` lebih tua, 0 kalau setara, positif kalau `a` lebih baru.
   *
   * Per ruas angka, bukan per abjad: perbandingan abjad bilang "1.10" < "1.9",
   * dan kesalahan itu memblokir orang yang justru sudah memperbarui.
   */
  function bandingkan(a, b) {
    const ruas = (versi) =>
      String(versi || "")
        .trim()
        .split(".")
        .map((bagian) => {
          const angka = parseInt(bagian, 10);
          return Number.isNaN(angka) ? 0 : angka;
        });

    const kiri = ruas(a);
    const kanan = ruas(b);
    const panjang = Math.max(kiri.length, kanan.length);
    for (let i = 0; i < panjang; i += 1) {
      const selisih = (kiri[i] || 0) - (kanan[i] || 0);
      if (selisih !== 0) return selisih;
    }
    return 0;
  }

  /** Versi yang tidak diketahui di sisi mana pun tidak pernah berarti "basi". */
  function butuhPembaruan(terpasangVersi, terbaru) {
    if (tidakDiketahui(terpasangVersi) || tidakDiketahui(terbaru)) return false;
    return bandingkan(terpasangVersi, terbaru) < 0;
  }

  /**
   * Batas kosong meloloskan semua orang; versi yang tidak diketahui TIDAK lolos.
   * Aturan kedua berlawanan dengan `butuhPembaruan`, dan disengaja — lihat
   * `diBawahMinimum` di nerona-web.
   */
  function diBawahMinimum(terpasangVersi, minimum) {
    if (tidakDiketahui(minimum)) return false;
    if (tidakDiketahui(terpasangVersi)) return true;
    return bandingkan(terpasangVersi, minimum) < 0;
  }

  globalThis.NeronaVersi = { terpasang, bandingkan, butuhPembaruan, diBawahMinimum };
})();
