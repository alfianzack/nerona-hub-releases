/**
 * Klien akses Nerona — verifikasi lisensi via nerona-web (NeronaWebClient).
 */
(function () {
  const STORAGE_KEYS = {
    license: "neronaLicense",
    cache: "neronaAccessCache"
  };

  /**
   * CADANGAN, bukan lagi sumber kebenaran.
   *
   * Sejak `/api/extension/me` membawa `allMarketplaces`, daftar yang dipakai
   * datang dari server — lihat `nerona-web-client.js`. Yang di bawah ini hanya
   * terpakai kalau server belum mengirimnya (deploy lama) atau kolomnya gagal
   * dibaca, supaya kegagalan satu kolom tidak mengunci pengguna dari seluruh
   * marketplace-nya.
   *
   * Karena itu daftar ini boleh basi tanpa merusak apa pun — dan jangan
   * dijadikan alasan menambah marketplace baru di sini saja.
   */
  const ALL_MARKETPLACES = [
    "adobe",
    "magnific",
    "vecteezy",
    "shutterstock",
    "canva",
    "miricanvas",
    "designbundle",
    "dreamstime"
  ];

  function extensionStorageLocal() {
    try {
      if (typeof chrome !== "undefined" && chrome.storage?.local) return chrome.storage.local;
      if (typeof browser !== "undefined" && browser.storage?.local) return browser.storage.local;
    } catch (_e) {
      /* ignore */
    }
    return null;
  }

  function cfg() {
    return globalThis.NERONA_ACCESS_CONFIG || {};
  }

  function isAccessConfigured() {
    return Boolean(String(cfg().neronaWebBaseUrl || "").trim());
  }

  async function getStoredLicense() {
    const storage = extensionStorageLocal();
    if (!storage) return { email: "", licenseKey: "" };
    const data = await storage.get([STORAGE_KEYS.license]);
    const lic = data[STORAGE_KEYS.license] || {};
    const email = String(lic.email || "").trim();
    let licenseKey = String(lic.licenseKey || lic.license_key || "").trim();
    if (!licenseKey && globalThis.NeronaWebClient?.getToken) {
      licenseKey = await globalThis.NeronaWebClient.getToken();
    }
    return { email, licenseKey };
  }

  async function clearAccessCache() {
    const storage = extensionStorageLocal();
    if (!storage) return;
    await storage.remove([STORAGE_KEYS.cache]);
  }

  function normalizeMarketplaceList(raw) {
    if (!raw) return [...ALL_MARKETPLACES];
    if (Array.isArray(raw)) {
      if (raw.includes("*") || raw.includes("all")) return [...ALL_MARKETPLACES];
      return raw.map((x) => String(x).trim().toLowerCase()).filter(Boolean);
    }
    const s = String(raw).trim().toLowerCase();
    if (!s || s === "*" || s === "all") return [...ALL_MARKETPLACES];
    return s
      .split(/[,;|]+/)
      .map((x) => x.trim().toLowerCase())
      .filter(Boolean);
  }

  function formatAccessFailureMessage(code, resp) {
    const parts = [accessErrorMessage(code, resp?.message)];
    if (resp?.hint) parts.push(String(resp.hint));
    return parts.filter(Boolean).join(" ");
  }

  function accessErrorMessage(code, detail) {
    const map = {
      invalid_key: "Kode lisensi tidak ditemukan.",
      email_mismatch: "Email tidak cocok dengan lisensi.",
      expired: "Lisensi sudah kedaluwarsa.",
      banned: "Akun diblokir.",
      revoked: "Lisensi dicabut.",
      marketplace_locked: "Marketplace ini tidak termasuk paket lisensi Anda.",
      outdated:
        "Versi extension ini sudah terlalu lama dan tidak dilayani lagi. Buka halaman Unduh di nerona-web untuk memasang versi terbaru.",
      unauthorized: "Server lisensi menolak permintaan (token salah).",
      server_not_configured: "URL nerona-web / token belum diatur.",
      network: "Tidak dapat menghubungi server lisensi.",
      missing_license: "Masukkan email dan kode lisensi di popup Nerona Metadata."
    };
    return detail || map[code] || map.invalid_key;
  }

  async function fetchAccessFromServer({ email, licenseKey, marketplaceKey }) {
    // nerona-web (akun & poin) menggantikan Google Sheet sebagai sumber akses.
    if (globalThis.NeronaWebClient) {
      return globalThis.NeronaWebClient.fetchAccountState(licenseKey);
    }
    return { ok: false, error: "server_not_configured" };
  }

  async function readCache(marketplaceKey) {
    const storage = extensionStorageLocal();
    if (!storage) return null;
    const { neronaAccessCache } = await storage.get([STORAGE_KEYS.cache]);
    if (!neronaAccessCache?.payload || !neronaAccessCache.checkedAt) return null;
    const ttl = Number(neronaAccessCache.ttlMs || cfg().cacheTtlMs || 900000);
    if (Date.now() - neronaAccessCache.checkedAt > ttl) return null;
    const lic = await getStoredLicense();
    if (
      neronaAccessCache.licenseKey &&
      lic.licenseKey &&
      neronaAccessCache.licenseKey !== lic.licenseKey
    ) {
      return null;
    }
    const payload = neronaAccessCache.payload;
    if (!payload.ok) return null;
    if (marketplaceKey && payload.marketplaces?.length) {
      const allowed = normalizeMarketplaceList(payload.marketplaces);
      if (!allowed.includes(String(marketplaceKey).toLowerCase())) {
        return null;
      }
    }
    return payload;
  }

  async function writeCache(payload, licenseKey) {
    const storage = extensionStorageLocal();
    if (!storage) return;
    await storage.set({
      [STORAGE_KEYS.cache]: {
        checkedAt: Date.now(),
        ttlMs: cfg().cacheTtlMs || 900000,
        licenseKey,
        payload
      }
    });
  }

  /**
   * Lapis pertama dari dua gerbang versi. Yang berwenang tetap
   * `/api/extension/generate`; ini ada supaya pengguna melihat sebabnya sebelum
   * satu poin pun terbakar, persis seperti kedaluwarsa sudah bekerja.
   *
   * Dipanggil di kedua jalur — payload segar DAN payload dari cache. Kalau cuma
   * di jalur segar, extension yang basi tetap bekerja selama TTL cache dan
   * pengguna melihat kegagalan 403 dari server tanpa penjelasan.
   */
  function pastikanTidakBasi(payload) {
    const versi = globalThis.NeronaVersi;
    if (!versi?.diBawahMinimum) return;
    if (versi.diBawahMinimum(versi.terpasang(), payload?.update?.min)) {
      throw new Error(formatAccessFailureMessage("outdated", payload));
    }
  }

  /**
   * Verifikasi akses. Mengembalikan payload server jika ok.
   * @throws Error dengan pesan bahasa Indonesia
   */
  async function assertAccess(marketplaceKey, options = {}) {
    const enforce = cfg().enforce !== false;
    if (!isAccessConfigured()) {
      if (!enforce) return { ok: true, devBypass: true };
      throw new Error(accessErrorMessage("server_not_configured"));
    }

    const { email, licenseKey } = await getStoredLicense();
    if (!licenseKey) {
      throw new Error(accessErrorMessage("missing_license"));
    }

    if (!options.forceRefresh) {
      const cached = await readCache(marketplaceKey);
      if (cached) {
        pastikanTidakBasi(cached);
        return cached;
      }
    }

    const resp = await fetchAccessFromServer({
      email,
      licenseKey,
      marketplaceKey
    });

    if (!resp?.ok) {
      const code = resp?.error || "invalid_key";
      throw new Error(formatAccessFailureMessage(code, resp));
    }

    pastikanTidakBasi(resp);

    if (
      marketplaceKey &&
      Array.isArray(resp.marketplaces) &&
      resp.marketplaces.length &&
      !normalizeMarketplaceList(resp.marketplaces).includes(String(marketplaceKey).toLowerCase())
    ) {
      throw new Error(formatAccessFailureMessage("marketplace_locked", resp));
    }

    await writeCache(resp, licenseKey);
    return resp;
  }

  /** Hanya true jika sheet/API secara eksplisit mengizinkan (reject_analyzer = TRUE). */
  function isRejectAnalyzerGranted(payload) {
    return Boolean(payload?.ok && payload.rejectAnalyzer === true);
  }

  async function canUseRejectAnalyzer(marketplaceKey, options = {}) {
    try {
      const access = await assertAccess(marketplaceKey || "", options);
      return isRejectAnalyzerGranted(access);
    } catch (_e) {
      return false;
    }
  }

  globalThis.NeronaAccess = {
    ALL_MARKETPLACES,
    getStoredLicense,
    clearAccessCache,
    assertAccess,
    canUseRejectAnalyzer,
    isRejectAnalyzerGranted,
    fetchAccessFromServer,
    accessErrorMessage,
    isAccessConfigured
  };
})();
