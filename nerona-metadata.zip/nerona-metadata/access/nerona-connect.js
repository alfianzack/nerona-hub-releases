/**
 * Jembatan penyambungan akun — HANYA berjalan di halaman nerona-web.
 *
 * Sengaja BUKAN bagian dari entri content_scripts marketplace: kelima belas
 * skrip marketplace tidak punya urusan berjalan di dasbor kita sendiri, dan
 * menjalankannya di sana cuma menambah permukaan galat.
 *
 * Kenapa postMessage aman di sini: token dilewatkan di halaman yang
 * penggunanya SUDAH login. Siapa pun yang bisa menjalankan skrip di halaman itu
 * sudah memegang cookie sesinya, jadi tidak ada kemampuan baru yang diberikan.
 * Karena itu origin pengirim dikunci — halaman marketplace mana pun tidak boleh
 * ikut bicara.
 */
(function () {
  const ASAL = location.origin;
  const KUNCI_INSTALASI = "neronaInstalasi";

  /** chrome.storage.local — Firefox MV3 memakai browser.storage.local */
  function penyimpanan() {
    try {
      if (typeof chrome !== "undefined" && chrome.storage?.local) return chrome.storage.local;
      if (typeof browser !== "undefined" && browser.storage?.local) return browser.storage.local;
    } catch (_e) {
      /* ignore */
    }
    return null;
  }

  function idAcak() {
    const b = new Uint8Array(4);
    crypto.getRandomValues(b);
    return Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
  }

  /**
   * Id instalasi: dibuat SEKALI lalu menetap di chrome.storage.local, jadi ia
   * selamat dari muat ulang halaman maupun browser ditutup.
   *
   * Yang dijawabnya: nama browser saja BUKAN penanda perangkat. `Extension ·
   * Chrome` sama persis di PC kantor, PC rumah, dan profil Chrome kedua di
   * komputer yang sama. Tanpa pembeda ini, "cabut token lama berlabel sama"
   * saat menyambung di mesin kedua akan mencabut token mesin PERTAMA yang masih
   * dipakai — dan pemiliknya tidak punya cara tahu perangkat mana yang barusan
   * kehilangan akses.
   */
  async function idInstalasi() {
    const simpanan = penyimpanan();
    if (!simpanan) return "";
    try {
      const ada = String((await simpanan.get([KUNCI_INSTALASI]))[KUNCI_INSTALASI] || "").trim();
      if (ada) return ada;
      await simpanan.set({ [KUNCI_INSTALASI]: idAcak() });
      // Dibaca ULANG, bukan memakai nilai yang barusan ditulis: dua tab dasbor
      // yang dimuat berbarengan sama-sama melihat kunci kosong dan sama-sama
      // menulis. Membaca kembali membuat keduanya memakai pemenang tulisan yang
      // sama, jadi satu instalasi tidak pernah punya dua id.
      return String((await simpanan.get([KUNCI_INSTALASI]))[KUNCI_INSTALASI] || "").trim();
    } catch (_e) {
      // Tanpa id, dasbor tidak akan mencabut apa pun (lihat `issueExtensionToken`).
      // Arah kegagalannya sengaja begitu: menyisakan token nganggur jauh lebih
      // ringan daripada mematikan token perangkat lain yang sedang dipakai.
      return "";
    }
  }

  function versi() {
    try {
      return chrome.runtime.getManifest().version;
    } catch (_e) {
      return "?";
    }
  }

  function kirim(pesan) {
    window.postMessage({ source: "nerona-ext", ...pesan }, ASAL);
  }

  /**
   * Pesan GAGAL per sebab. `fetchAccountState` memakai satu kosakata `error`
   * untuk semuanya, dan menyamaratakannya jadi satu kalimat membuat pengguna
   * menebak: "token ditolak" dan "internet putus" butuh tindakan yang berbeda.
   */
  const PESAN_GAGAL = {
    invalid_key: "Server menolak token yang baru dibuat. Muat ulang halaman lalu coba lagi.",
    network: "Tidak bisa menghubungi server Nerona. Periksa koneksi internet lalu coba lagi.",
    server_not_configured: "Alamat server Nerona belum diatur di ekstensi.",
    missing_license: "Token kosong."
  };

  async function umumkan() {
    // Dasbor perlu tahu apakah BROWSER INI sudah memegang token, bukan cuma
    // apakah extension terpasang: keadaan tersambung di dasbor harus bertahan
    // melewati muat ulang halaman, dan daftar token milik akun saja tidak bisa
    // membedakan browser ini dari browser lain milik pengguna yang sama.
    let tersambung = false;
    try {
      tersambung = Boolean(await globalThis.NeronaWebClient?.getToken?.());
    } catch (_e) {
      /* penyimpanan tidak terbaca — perlakukan sebagai belum tersambung */
    }
    // `instalasi` ikut di HADIR, bukan menunggu sampai TOKEN dibalas: dasbor
    // butuh id-nya SEBELUM membuat token, karena id itulah yang membatasi token
    // lama mana yang boleh dicabut.
    kirim({
      type: "HADIR",
      version: versi(),
      tersambung,
      instalasi: await idInstalasi()
    });
  }

  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    if (event.origin !== ASAL) return;
    const data = event.data;
    if (!data || data.source !== "nerona-web") return;

    // Dasbor menyapa saat pendengarnya siap; kita mungkin sudah mengumumkan
    // diri sebelum React sempat memasangnya.
    if (data.type === "HALO") {
      await umumkan();
      return;
    }

    if (data.type !== "TOKEN") return;
    const token = String(data.token || "").trim();
    if (!token) {
      kirim({ type: "GAGAL", pesan: "Token kosong." });
      return;
    }

    // Dicek eksplisit (bukan cuma diserahkan ke catch di bawah): kalau salah
    // satu skrip access/*.js gagal dimuat, memanggil metodenya langsung
    // melempar TypeError generik ("Cannot read properties of undefined")
    // yang tidak bisa ditindaklanjuti pengguna. Pesan ini bisa.
    if (!globalThis.NeronaWebClient?.setToken || !globalThis.NeronaWebClient?.fetchAccountState) {
      kirim({ type: "GAGAL", pesan: "Modul akun tidak dimuat. Muat ulang ekstensi." });
      return;
    }

    try {
      await globalThis.NeronaWebClient.setToken(token);

      // Dipisah dari try/catch utama dengan sengaja: pada titik ini token
      // SUDAH tersimpan lewat setToken di atas. Kalau clearAccessCache()
      // melempar (mis. "Extension context invalidated" saat ekstensi baru
      // saja di-reload sementara instance content script lama masih hidup),
      // itu tidak boleh membatalkan verifikasi token di bawah dan membuat
      // pengguna dikira GAGAL tersambung padahal tokennya valid. Akibat
      // terburuk yang boleh terjadi hanyalah cache basi sampai 15 menit.
      try {
        await globalThis.NeronaAccess?.clearAccessCache?.();
      } catch (_e) {
        /* diabaikan — lihat penjelasan di atas */
      }

      const state = await globalThis.NeronaWebClient.fetchAccountState(token);

      // `state.ok` berarti "lisensinya aktif", BUKAN "tokennya sah" —
      // `fetchAccountState` menurunkannya dari `account.active`. Token yang
      // baru saja dicetak server itu sendiri selalu sah; pengguna yang belum
      // punya lisensi aktif dijawab `error: "expired"`. Menyebut itu GAGAL
      // berarti mengabarkan penyambungan gagal padahal berhasil — dan setiap
      // klik ulang mencetak token baru yang tidak menyelesaikan apa pun.
      // Karena itu keadaan lisensi dikirim sebagai fakta TERPISAH, bukan
      // sebagai kegagalan.
      if (state?.ok || state?.error === "expired") {
        kirim({
          type: "TERSAMBUNG",
          email: state.email || "",
          lisensiAktif: Boolean(state.ok)
        });
      } else {
        const kode = state?.error || "invalid_key";
        kirim({ type: "GAGAL", pesan: PESAN_GAGAL[kode] || PESAN_GAGAL.invalid_key });
      }
    } catch (e) {
      kirim({ type: "GAGAL", pesan: String(e?.message || e) });
    }
  });

  void umumkan();
})();
