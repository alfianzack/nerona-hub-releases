/**
 * Klien nerona-web — sumber akses/akun (menggantikan Google Sheet).
 * Memanggil GET {neronaWebBaseUrl}/api/extension/me dengan Bearer token
 * dan mengembalikan payload dalam bentuk yang sama seperti access.js lama:
 * { ok, plan, validUntil, marketplaces: string[], rejectAnalyzer, pointsBalance, email, model }
 */
(function () {
  const TOKEN_KEY = "neronaToken";

  function baseUrl() {
    const u = String(globalThis.NERONA_ACCESS_CONFIG?.neronaWebBaseUrl || "").trim();
    return u.replace(/\/+$/, "");
  }

  /**
   * Sejak Chrome 85, fetch() di dalam content script tunduk pada CORS milik HALAMAN,
   * jadi panggilan ke nerona-web dari halaman marketplace akan diblokir. Service
   * worker (background) tidak kena aturan itu karena memakai host_permissions
   * ekstensi, jadi content script menitipkan request lewat NERONA_PROXY_FETCH.
   *
   * File ini dimuat di TIGA konteks: service worker (importScripts di background.js),
   * halaman popup, dan content script. Dua yang pertama boleh fetch langsung.
   */
  function canFetchCrossOriginDirectly() {
    if (typeof window === "undefined") return true; // service worker
    try {
      return String(location?.protocol || "") === "chrome-extension:"; // popup/options
    } catch (_e) {
      return false;
    }
  }

  function runtimeApi() {
    try {
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) return chrome.runtime;
      if (typeof browser !== "undefined" && browser.runtime?.sendMessage) return browser.runtime;
    } catch (_e) {
      /* ignore */
    }
    return null;
  }

  function parseJson(text) {
    try {
      return JSON.parse(String(text || ""));
    } catch (_e) {
      return null;
    }
  }

  function fetchViaBackground(url, init) {
    return new Promise((resolve) => {
      const rt = runtimeApi();
      if (!rt) {
        resolve({ ok: false, status: 0, data: null });
        return;
      }
      let settled = false;
      const done = (value) => {
        if (settled) return;
        settled = true;
        resolve(value);
      };
      try {
        rt.sendMessage(
          {
            type: "NERONA_PROXY_FETCH",
            request: {
              url,
              method: init?.method || "GET",
              headers: init?.headers || {},
              body: init?.body
            }
          },
          (response) => {
            if (rt.lastError || !response) {
              done({ ok: false, status: 0, data: null });
              return;
            }
            done({
              ok: Boolean(response.ok),
              status: Number(response.status || 0),
              data: parseJson(response.text)
            });
          }
        );
      } catch (_e) {
        done({ ok: false, status: 0, data: null });
      }
    });
  }

  /**
   * Header versi dipasang di satu tempat, bukan per pemanggilan: begitu ada satu
   * jalur yang lupa menyebutkannya, server membacanya sebagai "versi tidak
   * diketahui" dan gerbang minimum memblokir extension yang sebenarnya mutakhir.
   */
  function denganVersi(headers) {
    const versi = globalThis.NeronaVersi?.terpasang?.() || "";
    if (!versi) return headers || {};
    return { ...(headers || {}), "X-Nerona-Ext-Version": versi };
  }

  /** Satu pintu request JSON. status 0 = gagal jaringan / proxy tidak tersedia. */
  async function requestJson(url, init) {
    const withVersion = { ...(init || {}), headers: denganVersi(init?.headers) };
    if (!canFetchCrossOriginDirectly()) return fetchViaBackground(url, withVersion);
    let res;
    try {
      res = await fetch(url, withVersion);
    } catch (_e) {
      return { ok: false, status: 0, data: null };
    }
    const text = await res.text().catch(() => "");
    return { ok: res.ok, status: res.status, data: parseJson(text) };
  }

  /**
   * Aturan penjaga unggahan, salinan terakhir dari server.
   *
   * Disimpan supaya pemeriksaan metadata tetap jalan waktu server tak
   * terjangkau. Yang TIDAK boleh terjadi adalah memeriksa dengan batas
   * marketplace usang tanpa ada yang tahu, jadi `versi` ikut tersimpan dan
   * ditampilkan di laporan.
   */
  const GUARD_KEY = "nerona_guard_rules";

  function storageLocal() {
    try {
      if (typeof chrome !== "undefined" && chrome.storage?.local) return chrome.storage.local;
      if (typeof browser !== "undefined" && browser.storage?.local) return browser.storage.local;
    } catch (_e) {
      /* ignore */
    }
    return null;
  }

  async function getToken() {
    const storage = storageLocal();
    if (!storage) return "";
    const data = await storage.get([TOKEN_KEY]);
    return String(data[TOKEN_KEY] || "").trim();
  }

  async function setToken(token) {
    const storage = storageLocal();
    if (!storage) return;
    await storage.set({ [TOKEN_KEY]: String(token || "").trim() });
  }

  // Returns the same shape the extension's access layer expects:
  // { ok, plan, validUntil, marketplaces: string[], rejectAnalyzer, pointsBalance, email, model }
  async function fetchAccountState(token) {
    const t = String(token || "").trim() || (await getToken());
    if (!t) return { ok: false, error: "missing_license" };
    const base = baseUrl();
    if (!base) return { ok: false, error: "server_not_configured" };
    const res = await requestJson(`${base}/api/extension/me`, {
      headers: { Authorization: `Bearer ${t}`, Accept: "application/json" }
    });
    if (res.status === 401) return { ok: false, error: "invalid_key" };
    if (!res.ok) return { ok: false, error: "network" };
    const acc = res.data?.account;
    if (!acc) return { ok: false, error: "invalid_key" };

    // Ditulis sambil lalu: kegagalan menyimpan aturan tidak boleh menggagalkan
    // cek lisensi, karena tanpa aturan pun metadata masih bisa di-generate.
    if (res.data?.guardRules && typeof res.data.guardRules === "object") {
      try {
        const storage = storageLocal();
        if (storage) await storage.set({ [GUARD_KEY]: res.data.guardRules });
      } catch (_e) {
        /* ignore */
      }
    }
    // Daftar dari SERVER kalau ada, daftar lokal hanya cadangan.
    //
    // Ketiganya — web, extension, Hub — dulu menyimpan salinan sendiri yang
    // disalin dengan tangan, dan tidak ada tes yang bisa menyeberangi tiga repo.
    // Itu sudah menggigit sekali: satu id yang menyimpang memblokir marketplace
    // untuk setiap lisensi berdaftar eksplisit, tanpa galat di sisi mana pun.
    //
    // Cadangannya dipertahankan supaya extension lama tetap bekerja melawan
    // server yang belum di-deploy, dan supaya kegagalan membaca satu kolom
    // tidak mengunci pengguna dari seluruh marketplace-nya.
    const semua =
      Array.isArray(res.data?.allMarketplaces) && res.data.allMarketplaces.length
        ? res.data.allMarketplaces.map((k) => String(k).trim().toLowerCase()).filter(Boolean)
        : [...(globalThis.NeronaAccess?.ALL_MARKETPLACES || [])];

    const marketplaces =
      acc.marketplaces === "*" || !acc.marketplaces
        ? semua
        : String(acc.marketplaces)
            .split(",")
            .map((s) => s.trim().toLowerCase())
            .filter(Boolean);
    return {
      ok: Boolean(acc.active),
      error: acc.active ? undefined : "expired",
      plan: acc.plan || "",
      validUntil: acc.validUntil ? new Date(acc.validUntil).toLocaleDateString("id-ID") : "",
      marketplaces,
      rejectAnalyzer: Boolean(acc.rejectAnalyzer),
      pointsBalance: Number(acc.pointsBalance || 0),
      email: acc.email || "",
      // Model AI yang berlaku untuk akun ini, sebagaimana dipilih di server.
      //
      // `ai.label` dulu, `ai.model` cadangan: label adalah nama yang dibaca
      // manusia ("Gemini 2.5 Flash"), sedangkan `ai.model` adalah id mentah
      // ("google/gemini-2.5-flash") yang tidak berarti apa-apa bagi tenant.
      // Labelnya kosong pada dua keadaan yang sah — server versi lama belum
      // mengirim field itu, dan modelnya datang dari Koneksi AI, bukan dari
      // baris registri yang punya label — dan di kedua keadaan itu id mentah
      // masih lebih baik daripada baris yang hilang.
      //
      // Tetap kosong kalau server tidak mengirim keduanya; UI menyembunyikan
      // barisnya, bukan menulis "Model: -".
      model: String(res.data?.ai?.label || res.data?.ai?.model || ""),
      // Versi yang tersedia, batas yang masih dilayani, dan ke mana pengguna
      // dikirim. Menumpang di sini alih-alih endpoint sendiri: rute ini sudah
      // dipanggil berkala, jadi badge tidak menambah satu pun permintaan.
      // Kosong kalau server versi lama belum mengirimnya.
      update: {
        latest: String(res.data?.update?.latest || ""),
        min: String(res.data?.update?.min || ""),
        url: String(res.data?.update?.url || "")
      }
    };
  }

  // Generates content via the nerona-web structured feature endpoint (metered by tenant points).
  // payload: { feature, marketplace, promptMode, batchIndex, image: { mime, dataBase64 }, imageHash, contextSnippet, monthsCurrent, monthsNext }
  // Prompts are assembled server-side from these structured inputs.
  // Returns { ok: true, content, usage, pointsBalance } or { ok: false, error, status }.
  async function generateFeature(payload) {
    const t = await getToken();
    if (!t) return { ok: false, error: "missing_license" };
    const base = baseUrl();
    if (!base) return { ok: false, error: "server_not_configured" };
    const res = await requestJson(`${base}/api/extension/generate`, {
      method: "POST",
      headers: { Authorization: `Bearer ${t}`, "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(payload)
    });
    if (res.status === 0) return { ok: false, error: "network" };
    const data = res.data;
    if (!res.ok || !data?.ok) {
      return {
        ok: false,
        error:
          data?.error ||
          (res.status === 401
            ? "unauthorized"
            : res.status === 402
            ? "no_points"
            : res.status === 403
            ? "inactive"
            : res.status === 413
            ? "payload_too_large"
            : "ai_error"),
        status: res.status,
        // Hanya terisi untuk `outdated`. Dibawa ikut supaya pemanggilnya bisa
        // menyebut versi berapa yang dituntut, bukan sekadar "terlalu tua".
        update:
          data?.error === "outdated"
            ? { latest: String(data.latest || ""), min: String(data.min || ""), url: String(data.url || "") }
            : undefined
      };
    }
    // `duplikat` cuma terisi untuk feature "metadata", dan cuma kalau server
    // sudah versi baru. Extension lama yang tidak membacanya tetap jalan.
    return {
      ok: true,
      content: data.content,
      usage: data.usage,
      pointsBalance: data.pointsBalance,
      duplikat: data.duplikat || null
    };
  }

  // Mencatat metadata final ke nerona-web (riwayat, tidak memakai poin).
  // payload: { marketplace, pageUrl, title, keywords, imageHash }
  //
  // Sengaja "kirim lalu lupakan": ini dipanggil setelah generate berhasil dan
  // metadata sudah siap dipasang ke form. Kalau pencatatan gagal — offline,
  // server mati, token dicabut — user tidak boleh melihat error apa pun untuk
  // pekerjaan yang sebetulnya sudah selesai.
  async function logMetadata(payload) {
    try {
      const t = await getToken();
      const base = baseUrl();
      if (!t || !base) return false;
      const res = await requestJson(`${base}/api/extension/metadata-log`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${t}`,
          "Content-Type": "application/json",
          Accept: "application/json"
        },
        body: JSON.stringify(payload)
      });
      return Boolean(res.ok);
    } catch (_e) {
      return false;
    }
  }

  /** null berarti belum pernah tersimpan; pemanggil harus jatuh ke bawaan, bukan mati. */
  async function getGuardRules() {
    try {
      const storage = storageLocal();
      if (!storage) return null;
      const data = await storage.get([GUARD_KEY]);
      const nilai = data[GUARD_KEY];
      return nilai && typeof nilai === "object" ? nilai : null;
    } catch (_e) {
      return null;
    }
  }

  globalThis.NeronaWebClient = {
    getToken,
    setToken,
    fetchAccountState,
    generateFeature,
    logMetadata,
    getGuardRules
  };
})();
