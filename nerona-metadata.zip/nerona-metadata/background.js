importScripts(
  "access/access-config.js",
  "access/versi.js",
  "access/nerona-web-client.js",
  "access/access.js"
);

/**
 * Badge "versi baru tersedia".
 *
 * Butuh detak sendiri: cache akses hanya disegarkan saat ada yang memintanya,
 * jadi badge yang menunggu itu baru muncul setelah pengguna membuka popup —
 * yang menghapus seluruh gunanya, karena popup itu sendiri yang menampilkan
 * spanduknya.
 *
 * Extension ini dipasang lewat Load unpacked, jadi Chrome tidak akan pernah
 * memperbaruinya sendiri. Badge inilah satu-satunya hal yang memberi tahu
 * pengguna tanpa mereka harus ingat membuka /unduh.
 */
const ALARM_VERSI = "nerona-cek-versi";
const PERIODE_CEK_MENIT = 360;

function setBadge(perlu) {
  try {
    chrome.action.setBadgeText({ text: perlu ? "!" : "" });
    if (perlu) {
      chrome.action.setBadgeBackgroundColor({ color: "#E0661C" });
      chrome.action.setTitle({ title: "Nerona Metadata — versi baru tersedia" });
    } else {
      chrome.action.setTitle({ title: "Nerona Metadata" });
    }
  } catch (_e) {
    /* ignore */
  }
}

async function cekVersi() {
  try {
    const state = await globalThis.NeronaWebClient?.fetchAccountState();
    // Tanpa token, tanpa jaringan, atau server versi lama: badge TIDAK diubah
    // ke keadaan mana pun. Membersihkannya di sini akan menghapus peringatan
    // yang benar hanya karena satu pemeriksaan kebetulan gagal.
    const terbaru = state?.update?.latest;
    if (!terbaru) return;
    setBadge(globalThis.NeronaVersi.butuhPembaruan(globalThis.NeronaVersi.terpasang(), terbaru));
  } catch (_e) {
    /* ignore */
  }
}

function jadwalkanCekVersi() {
  try {
    chrome.alarms.create(ALARM_VERSI, { periodInMinutes: PERIODE_CEK_MENIT });
  } catch (_e) {
    /* ignore */
  }
  cekVersi();
}

chrome.runtime.onInstalled.addListener(jadwalkanCekVersi);
chrome.runtime.onStartup.addListener(jadwalkanCekVersi);
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm?.name === ALARM_VERSI) cekVersi();
});

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...chunk);
  }
  return btoa(binary);
}

/**
 * Penanda "ada batch sedang berjalan".
 *
 * Ada supaya tombol Muat ulang di popup tidak membunuh batch di tengah jalan:
 * `chrome.runtime.reload()` menghentikan semuanya, dan poin untuk gambar yang
 * sudah terkirim ke server SUDAH terpakai — hasilnya tidak akan pernah sampai
 * ke form. Kerugian yang tidak bisa dibatalkan.
 *
 * Tinggal di service worker, bukan di content script: `chrome.storage.session`
 * bawaannya hanya untuk konteks terpercaya. Ini juga membuat penjaganya berada
 * di lapisan yang tidak ikut hancur saat halaman berpindah.
 *
 * Penandanya BUKAN boolean melainkan tenggat. Content script memperpanjangnya
 * tiap gambar; tab yang crash di tengah batch berhenti memperpanjang, dan
 * tombolnya bebas sendiri dalam 90 detik alih-alih terkunci selamanya.
 */
const KUNCI_BATCH = "neronaBatchHingga";
const UMUR_DENYUT_MS = 90 * 1000;

async function catatDenyutBatch() {
  try {
    await chrome.storage.session.set({ [KUNCI_BATCH]: Date.now() + UMUR_DENYUT_MS });
  } catch (_e) {
    /* ignore */
  }
}

async function hapusPenandaBatch() {
  try {
    await chrome.storage.session.remove([KUNCI_BATCH]);
  } catch (_e) {
    /* ignore */
  }
}

async function batchSedangBerjalan() {
  try {
    const data = await chrome.storage.session.get([KUNCI_BATCH]);
    return Number(data?.[KUNCI_BATCH] || 0) > Date.now();
  } catch (_e) {
    // Gagal membaca berarti tidak tahu. Menjawab "tidak ada batch" di sini akan
    // mengizinkan reload yang mungkin merusak — jadi jawabannya "ada".
    return true;
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "NERONA_BATCH_DENYUT") {
    catatDenyutBatch().then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message?.type === "NERONA_BATCH_SELESAI") {
    hapusPenandaBatch().then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message?.type === "NERONA_BATCH_STATUS") {
    batchSedangBerjalan().then((berjalan) => sendResponse({ ok: true, berjalan }));
    return true;
  }

  if (message?.type !== "NERONA_PROXY_FETCH") {
    return;
  }

  const req = message.request || {};
  fetch(req.url, {
    method: req.method || "GET",
    headers: req.headers || {},
    body: req.body || undefined,
    credentials: req.credentials || "omit"
  })
    .then(async (response) => {
      if (req.expectBinary) {
        const buffer = await response.arrayBuffer();
        sendResponse({
          ok: response.ok,
          status: response.status,
          contentType: response.headers.get("content-type") || "application/octet-stream",
          base64: arrayBufferToBase64(buffer)
        });
        return;
      }

      const text = await response.text();
      sendResponse({
        ok: response.ok,
        status: response.status,
        text
      });
    })
    .catch((error) => {
      sendResponse({
        ok: false,
        status: 0,
        text: String(error?.message || "Failed to fetch"),
        base64: ""
      });
    });

  return true;
});
