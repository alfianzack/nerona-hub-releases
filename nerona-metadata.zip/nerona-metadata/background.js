importScripts("access/access-config.js", "access/nerona-web-client.js", "access/access.js");

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...chunk);
  }
  return btoa(binary);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "NERONA_PROXY_FETCH") {
    return;
  }

  const req = message.request || {};
  fetch(req.url, {
    method: req.method || "GET",
    headers: req.headers || {},
    body: req.body || undefined,
    credentials: req.credentials || "omit"
  })
    .then(async (response) => {
      if (req.expectBinary) {
        const buffer = await response.arrayBuffer();
        sendResponse({
          ok: response.ok,
          status: response.status,
          contentType: response.headers.get("content-type") || "application/octet-stream",
          base64: arrayBufferToBase64(buffer)
        });
        return;
      }

      const text = await response.text();
      sendResponse({
        ok: response.ok,
        status: response.status,
        text
      });
    })
    .catch((error) => {
      sendResponse({
        ok: false,
        status: 0,
        text: String(error?.message || "Failed to fetch"),
        base64: ""
      });
    });

  return true;
});
