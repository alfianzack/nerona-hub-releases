const statusEl = document.getElementById("status");
const neronaTokenEl = document.getElementById("neronaToken");
const connectAccountBtn = document.getElementById("connectAccountBtn");
const accountStatusEl = document.getElementById("accountStatus");
const refreshAccountBtn = document.getElementById("refreshAccountBtn");
const forgetTokenBtn = document.getElementById("forgetTokenBtn");
const updateBannerEl = document.getElementById("updateBanner");
const updateBannerTextEl = document.getElementById("updateBannerText");
const updateBannerBtn = document.getElementById("updateBannerBtn");
const reloadExtBtn = document.getElementById("reloadExtBtn");
const reloadExtNote = document.getElementById("reloadExtNote");

/**
 * Extension ini dipasang lewat Load unpacked, jadi Chrome tidak akan pernah
 * memperbaruinya sendiri. Spanduk ini dan badge di ikon toolbar adalah satu-satunya
 * hal yang memberi tahu pengguna bahwa ada versi baru.
 *
 * Digambar dari `state.update` yang sudah ikut di setiap `/api/extension/me`,
 * jadi tidak ada permintaan jaringan tambahan.
 */
function renderUpdateBanner(state) {
  if (!updateBannerEl) return;
  const terpasang = globalThis.NeronaVersi?.terpasang?.() || "";
  const terbaru = state?.update?.latest || "";
  const perlu = Boolean(globalThis.NeronaVersi?.butuhPembaruan?.(terpasang, terbaru));
  updateBannerEl.hidden = !perlu;
  if (!perlu) return;
  updateBannerTextEl.textContent = `Versi ${terbaru} sudah tersedia — terpasang ${terpasang}.\nCara tercepat: buka folder nerona-metadata, klik dua kali perbarui.cmd, lalu tekan tombol Muat ulang di bawah.`;
  updateBannerBtn.dataset.url = state?.update?.url || "";
}

updateBannerBtn?.addEventListener("click", () => {
  const url = updateBannerBtn.dataset.url || "";
  if (!url) return;
  try {
    chrome.tabs.create({ url });
  } catch (_e) {
    window.open(url, "_blank", "noopener");
  }
});

/**
 * Memuat ulang extension supaya Chrome membaca ulang folder dari disk — itulah
 * yang menyelesaikan pembaruan setelah `perbarui.cmd` menimpa berkasnya, dan
 * itulah sebabnya `chrome://extensions` tidak perlu dibuka sama sekali.
 *
 * `chrome.runtime.reload()` MEMBUNUH semua yang sedang berjalan. Ditekan di
 * tengah batch, generate yang sedang di udara hilang — dan poin untuk gambar
 * yang sudah terkirim ke server sudah terpakai tanpa hasil yang pernah sampai
 * ke form. Karena itu ia bertanya lebih dulu, dan yang menjawab adalah service
 * worker, bukan keadaan apa pun di popup ini: popup dibuat ulang setiap kali
 * dibuka, jadi ia tidak bisa tahu apa-apa sendiri.
 */
reloadExtBtn?.addEventListener("click", () => {
  if (!reloadExtNote) return;
  reloadExtBtn.disabled = true;
  reloadExtNote.hidden = true;

  const lanjutkan = (berjalan) => {
    if (berjalan) {
      reloadExtNote.textContent =
        "Masih ada batch generate berjalan. Muat ulang sekarang akan menghentikannya, dan poin gambar yang sudah dikirim tidak kembali. Tunggu sampai selesai.";
      reloadExtNote.hidden = false;
      reloadExtBtn.disabled = false;
      return;
    }
    chrome.runtime.reload();
  };

  try {
    chrome.runtime.sendMessage({ type: "NERONA_BATCH_STATUS" }, (jawaban) => {
      // Tidak ada jawaban berarti service worker tidak menjawab, bukan berarti
      // aman. Tapi menolak selamanya juga salah — pengguna akan terjebak. Jadi
      // yang tidak diketahui diperlakukan sebagai TIDAK ada batch, dan risikonya
      // diterima: service worker yang mati juga berarti tidak ada proxy fetch,
      // yang berarti tidak ada generate yang bisa berjalan.
      void chrome.runtime.lastError;
      lanjutkan(Boolean(jawaban?.berjalan));
    });
  } catch (_e) {
    lanjutkan(false);
  }
});

/** chrome.storage.local — Firefox MV3 memakai browser.storage.local */
function extensionStorageLocal() {
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) return chrome.storage.local;
    if (typeof browser !== "undefined" && browser.storage?.local) return browser.storage.local;
  } catch (_e) {
    /* ignore */
  }
  return null;
}

function setStatus(message, isError = false) {
  statusEl.textContent = message;
  statusEl.style.color = isError ? "#fca5a5" : "#93c5fd";
}

function setAccountStatus(message, state = "") {
  if (!accountStatusEl) return;
  accountStatusEl.textContent = message;
  accountStatusEl.style.color =
    state === "ok" ? "#86efac" : state === "error" ? "#fca5a5" : "";
}

const ACCOUNT_ERROR_MESSAGES = {
  invalid_key: "Token tidak valid.",
  expired: "Paket berakhir.",
  missing_license: "Token belum diisi.",
  network: "Tidak dapat terhubung ke nerona-web.",
  server_not_configured: "URL nerona-web belum diatur."
};

/**
 * Beberapa baris, bukan satu kalimat panjang: status, paket & masa aktif, lalu
 * saldo. Dirender lewat textContent + `white-space: pre-line` di CSS — bukan
 * innerHTML, karena nama paket dan tanggal datang dari server dan tidak ada
 * alasan menyerahkannya ke parser HTML.
 *
 * Nama model AI DULU ikut di sini. Dipindah ke blok "AI" 2026-09-17: orang yang
 * ingin tahu modelnya membuka bagian yang berjudul AI, dan menemukan bagian itu
 * cuma berisi kalimat umum. Blok Akun menjawab pertanyaan yang lain.
 */
function formatAccountStatusMessage(state) {
  if (state?.ok) {
    const points = Number.isFinite(state.pointsBalance) ? state.pointsBalance : 0;
    const lines = ["✓ Akun aktif"];
    const plan = state.plan ? `Paket ${state.plan}` : "";
    // validUntil kosong berarti tanpa batas, bukan kedaluwarsa — jangan tampilkan
    // "berlaku sampai -" untuk akun yang justru tidak punya tanggal akhir.
    const until = state.validUntil ? `berlaku sampai ${state.validUntil}` : "";
    const second = [plan, until].filter(Boolean).join(" · ");
    if (second) lines.push(second);
    lines.push(`Poin: ${points.toLocaleString("id-ID")}`);
    return lines.join("\n");
  }
  const code = state?.error || "invalid_key";
  const lines = [ACCOUNT_ERROR_MESSAGES[code] || "Akun tidak valid."];
  // Kalau paket berakhir, tanggalnya adalah informasi yang paling dicari.
  if (code === "expired" && state?.validUntil) {
    lines.push(`Berakhir ${state.validUntil}.`);
  }
  return lines.join("\n");
}

/**
 * Baris model di blok AI. Disembunyikan kalau server tidak menyebut modelnya,
 * bukan ditulis "Model: -": yang kedua memberi tahu sesuatu yang salah,
 * sedangkan barisnya yang hilang tidak memberi tahu apa pun.
 *
 * Nilainya lewat textContent, bukan innerHTML, karena nama model datang dari
 * server.
 */
function setAiModel(nama) {
  const baris = document.getElementById("aiModel");
  const nilai = document.getElementById("aiModelName");
  if (!baris || !nilai) return;
  const teks = String(nama || "").trim();
  nilai.textContent = teks;
  baris.hidden = !teks;
}

async function refreshAccountStatus(token) {
  if (!globalThis.NeronaWebClient) {
    setAccountStatus("Modul akun tidak dimuat. Muat ulang ekstensi.", "error");
    return { ok: false, error: "invalid_key" };
  }
  setAccountStatus("Memeriksa akun…", "");
  const state = await NeronaWebClient.fetchAccountState(token);
  setAccountStatus(formatAccountStatusMessage(state), state?.ok ? "ok" : "error");
  // Model tetap ditampilkan untuk akun yang kedaluwarsa: yang mati lisensinya,
  // bukan kebenaran soal model mana yang akan dipakai.
  setAiModel(state?.model);
  // Digambar juga saat akunnya tidak aktif: extension basi milik pengguna yang
  // lisensinya habis tetap perlu diperbarui, dan menyembunyikan spanduknya
  // membuat mereka memperpanjang lisensi lalu menemukan masalah yang kedua.
  renderUpdateBanner(state);
  return state;
}

async function loadAccountUi() {
  if (!globalThis.NeronaWebClient) return;
  const token = await NeronaWebClient.getToken();
  if (neronaTokenEl) neronaTokenEl.value = token || "";
  if (!token) {
    setAccountStatus(ACCOUNT_ERROR_MESSAGES.missing_license, "");
    setAiModel("");
    return;
  }
  await refreshAccountStatus(token);
}

connectAccountBtn?.addEventListener("click", async () => {
  try {
    if (!globalThis.NeronaWebClient) {
      throw new Error("Modul akun tidak dimuat. Muat ulang ekstensi.");
    }
    const token = neronaTokenEl?.value?.trim() || "";
    if (!token) {
      setAccountStatus(ACCOUNT_ERROR_MESSAGES.missing_license, "error");
      setStatus(ACCOUNT_ERROR_MESSAGES.missing_license, true);
      return;
    }
    connectAccountBtn.disabled = true;
    setAccountStatus("Menyimpan & memeriksa…", "");
    await NeronaWebClient.setToken(token);
    await NeronaAccess?.clearAccessCache?.();
    const state = await refreshAccountStatus(token);
    if (state?.ok) {
      setStatus("Akun tersambung.");
    } else {
      setStatus(formatAccountStatusMessage(state), true);
    }
  } catch (error) {
    setAccountStatus(error.message || "Gagal menyimpan token.", "error");
    setStatus(error.message || "Gagal menyimpan token.", true);
  } finally {
    connectAccountBtn.disabled = false;
  }
});

// Cache akses berumur 15 menit (cacheTtlMs di access-config.js). Tanpa tombol
// ini, upgrade paket baru terasa sampai seperempat jam kemudian tanpa
// penjelasan apa pun ke pengguna.
refreshAccountBtn?.addEventListener("click", async () => {
  refreshAccountBtn.disabled = true;
  try {
    await NeronaAccess?.clearAccessCache?.();
    const token = await NeronaWebClient.getToken();
    if (!token) {
      setAccountStatus(ACCOUNT_ERROR_MESSAGES.missing_license, "");
      setAiModel("");
      return;
    }
    await refreshAccountStatus(token);
  } finally {
    refreshAccountBtn.disabled = false;
  }
});

forgetTokenBtn?.addEventListener("click", async () => {
  await NeronaWebClient.setToken("");
  await NeronaAccess?.clearAccessCache?.();
  if (neronaTokenEl) neronaTokenEl.value = "";
  setAccountStatus(ACCOUNT_ERROR_MESSAGES.missing_license, "");
  // Tanpa ini nama model tertinggal di layar sesudah akunnya diputus, dan
  // terbaca seolah ekstensi masih siap memakai model itu.
  setAiModel("");
  setStatus("Akun diputuskan.");
});

const SARAN_KEYWORD_KEY = "neronaSaranKeyword";
const saranKeywordEl = document.getElementById("saranKeyword");

/** Default HIDUP: yang belum pernah disimpan berarti belum pernah dimatikan. */
async function loadSaranKeywordToggle() {
  const storage = extensionStorageLocal();
  if (!storage || !saranKeywordEl) return;
  const data = await storage.get([SARAN_KEYWORD_KEY]);
  const v = data?.[SARAN_KEYWORD_KEY];
  saranKeywordEl.checked = typeof v === "boolean" ? v : true;
}

const RISIKO_OTOMATIS_KEY = "neronaRisikoOtomatis";
const risikoOtomatisEl = document.getElementById("risikoOtomatis");

/** Default HIDUP: owner memesan fitur ini otomatis, jadi diam berarti nyala. */
async function loadRisikoOtomatisToggle() {
  const storage = extensionStorageLocal();
  if (!storage || !risikoOtomatisEl) return;
  const data = await storage.get([RISIKO_OTOMATIS_KEY]);
  const v = data?.[RISIKO_OTOMATIS_KEY];
  risikoOtomatisEl.checked = typeof v === "boolean" ? v : true;
}

risikoOtomatisEl?.addEventListener("change", async () => {
  const storage = extensionStorageLocal();
  if (!storage) {
    setStatus("Penyimpanan ekstensi tidak tersedia.", true);
    return;
  }
  const hidup = Boolean(risikoOtomatisEl.checked);
  await storage.set({ [RISIKO_OTOMATIS_KEY]: hidup });
  setStatus(
    hidup
      ? "Pemeriksaan risiko otomatis dinyalakan. Muat ulang tab marketplace."
      : "Pemeriksaan risiko otomatis dimatikan. Muat ulang tab marketplace."
  );
});

saranKeywordEl?.addEventListener("change", async () => {
  const storage = extensionStorageLocal();
  if (!storage) {
    setStatus("Penyimpanan ekstensi tidak tersedia.", true);
    return;
  }
  const hidup = Boolean(saranKeywordEl.checked);
  await storage.set({ [SARAN_KEYWORD_KEY]: hidup });
  // Tab yang sudah terbuka ikut berubah tanpa dimuat ulang: content.js
  // mendengarkan storage.onChanged untuk kunci ini.
  setStatus(
    hidup ? "Saran marketplace dipakai." : "Saran marketplace dimatikan."
  );
});

document.addEventListener("DOMContentLoaded", async () => {
  try {
    const storage = extensionStorageLocal();
    if (!storage) {
      setStatus(
        "Penyimpanan ekstensi tidak tersedia. Buka pengaturan dari ikon Nerona Metadata di toolbar (jangan drag popup.html ke browser). Pastikan manifest memuat izin \"storage\", lalu muat ulang ekstensi.",
        true
      );
      return;
    }

    await loadAccountUi();
    await loadSaranKeywordToggle();
    await loadRisikoOtomatisToggle();
  } catch (err) {
    setStatus(err.message || "Gagal memuat pengaturan AI.", true);
  }
});
