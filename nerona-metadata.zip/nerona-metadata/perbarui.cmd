@echo off
REM Peluncur untuk perbarui.ps1. Klik dua kali berkas ini untuk memperbarui
REM Nerona Metadata ke versi terbaru.
REM
REM -ExecutionPolicy Bypass diberikan di baris perintah, jadi ia HANYA berlaku
REM untuk proses PowerShell ini. Setelan mesin pengguna tidak diubah sama sekali.
REM Tanpa itu, mesin dengan kebijakan bawaan Windows menolak menjalankan .ps1
REM apa pun dan pembaruannya gagal dengan pesan yang tidak menjelaskan apa-apa.
REM
REM "%~dp0" adalah folder tempat berkas ini berada — bukan folder kerja saat
REM diklik. Keduanya bisa berbeda, dan yang benar selalu yang pertama.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0perbarui.ps1"
