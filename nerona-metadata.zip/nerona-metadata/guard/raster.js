/**
 * Ukuran kanvas untuk merasterkan SVG sebelum dikirim ke AI.
 *
 * SVG sering TIDAK punya ukuran intrinsik: ia cuma punya viewBox, dan Chrome
 * melaporkan naturalWidth 0. Angka nol yang diteruskan ke kanvas menghasilkan
 * JPEG kosong, dan model lalu mengarang metadata untuk gambar yang tidak pernah
 * dilihatnya. Itu lebih buruk daripada gagal terang-terangan, karena
 * kontributor tidak punya cara tahu bedanya.
 *
 * MURNI; lihat scripts/guard-raster.test.mjs.
 */
(function () {
  /** Cukup besar supaya detail terbaca model, cukup kecil supaya tidak boros token. */
  const BAWAAN = 1024;

  function angkaSah(n) {
    return typeof n === "number" && Number.isFinite(n) && n > 0;
  }

  function ukuranRasterSvg({ lebar, tinggi, maksSisi, bawaan }) {
    const sisiBawaan = angkaSah(bawaan) ? bawaan : BAWAAN;
    const maks = angkaSah(maksSisi) ? maksSisi : sisiBawaan;

    if (!angkaSah(lebar) || !angkaSah(tinggi)) {
      const sisi = Math.min(sisiBawaan, maks);
      return { lebar: Math.round(sisi), tinggi: Math.round(sisi) };
    }

    // Sisi terpanjang SELALU dipaskan ke batas, naik maupun turun. Berbeda dari
    // gambar raster yang tidak boleh dibesarkan karena cuma menambah piksel
    // kosong, vektor tidak punya resolusi asli: menggambarnya lebih besar
    // benar-benar menambah detail, dan ongkos tokennya sama dengan gambar raster
    // mana pun yang dipotong ke batas yang sama.
    const terpanjang = Math.max(lebar, tinggi);
    const skala = maks / terpanjang;
    return {
      lebar: Math.max(1, Math.round(lebar * skala)),
      tinggi: Math.max(1, Math.round(tinggi * skala))
    };
  }

  globalThis.__NERONA_guardRaster__ = { BAWAAN, ukuranRasterSvg };
})();
