/**
 * Pembaca balasan risiko (fitur C).
 *
 * Badge ini dibaca sekilas sambil kontributor menggulir, jadi warnanya harus
 * bisa dipercaya tanpa dibuka. Dua hal yang dijaga berkas ini:
 *
 * 1. Model yang menjawab tidak konsisten tidak diteruskan apa adanya. "aman"
 *    sambil menyebutkan alasan itu balasan yang nyata terjadi, dan yang menang
 *    selalu alasannya: badge hijau di atas daftar masalah adalah kebohongan.
 * 2. Balasan yang tidak bisa dibaca jadi keadaan GALAT, tidak pernah "aman".
 *    Hijau karena parsing gagal jauh lebih berbahaya daripada badge yang
 *    mengaku gagal, karena kontributor tidak punya cara tahu bedanya.
 *
 * MURNI; lihat scripts/guard-risiko.test.mjs.
 */
(function () {
  const TINGKAT = { aman: "aman", "perlu dilihat": "lihat", berisiko: "risiko" };
  const YAKIN = ["rendah", "sedang", "tinggi"];

  /** Lebih dari tiga alasan tidak terbaca sekilas, dan yang keempat hampir selalu yang paling lemah. */
  const ALASAN_MAKS = 3;

  function galat(sebab) {
    return { tingkat: "galat", alasan: [], butuhRelease: false, galat: sebab };
  }

  function buangPagar(teks) {
    return String(teks)
      .trim()
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/```$/, "")
      .trim();
  }

  function bacaAlasan(daftar) {
    if (!Array.isArray(daftar)) return [];
    const out = [];
    for (const item of daftar) {
      if (!item || typeof item !== "object") continue;
      const sebab = String(item.sebab == null ? "" : item.sebab).trim();
      if (!sebab) continue;
      const yakin = String(item.yakin == null ? "" : item.yakin).trim().toLowerCase();
      out.push({
        sebab,
        yakin: YAKIN.indexOf(yakin) === -1 ? "sedang" : yakin,
        tindakan: String(item.tindakan == null ? "" : item.tindakan).trim()
      });
      if (out.length >= ALASAN_MAKS) break;
    }
    return out;
  }

  globalThis.__NERONA_guardRisiko__ = function bacaRisiko(teks) {
    if (typeof teks !== "string" || !teks.trim()) return galat("Balasan kosong.");

    let muatan;
    try {
      muatan = JSON.parse(buangPagar(teks));
    } catch (_e) {
      return galat("Balasan tidak bisa dibaca.");
    }
    if (!muatan || typeof muatan !== "object" || Array.isArray(muatan)) {
      return galat("Bentuk balasan tidak dikenal.");
    }

    const alasan = bacaAlasan(muatan.alasan);
    const diminta = TINGKAT[String(muatan.risiko == null ? "" : muatan.risiko).trim().toLowerCase()];

    // Daftar alasan yang menentukan, bukan label yang diberikan model. Label
    // bisa asing, bisa bertentangan dengan isinya; daftar alasan tidak bisa.
    let tingkat;
    if (!alasan.length) tingkat = "aman";
    else if (diminta === "risiko") tingkat = "risiko";
    else tingkat = "lihat";

    return { tingkat, alasan, butuhRelease: Boolean(muatan.butuhRelease) };
  };
})();
