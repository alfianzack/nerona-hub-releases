/**
 * Ringkasan satu baris dari laporan penjaga unggahan.
 *
 * Fitur A mengubah metadata tanpa ditanya, dan itu hanya boleh kalau
 * perubahannya selalu terlihat. Berkas ini yang memastikan "diam-diam" tidak
 * pernah terjadi: setiap perbaikan berakhir sebagai kalimat yang dibaca
 * kontributor, dan aturan yang gagal terambil dikatakan apa adanya, bukan
 * dilewatkan seolah semuanya lolos.
 *
 * MURNI; lihat scripts/guard-laporan.test.mjs.
 */
(function () {
  function jumlah(daftar) {
    return Array.isArray(daftar) ? daftar.length : 0;
  }

  function ringkas(penjaga) {
    if (!penjaga) return "";

    if (penjaga.dilewati) {
      return "Penjaga: metadata tidak diperiksa, aturan marketplace belum terambil.";
    }

    const dibetulkan = jumlah(penjaga.perubahan);
    const perluDilihat = jumlah(penjaga.sisa);
    if (!dibetulkan && !perluDilihat) return "";

    const bagian = [];
    if (dibetulkan) bagian.push(dibetulkan + " dibetulkan");
    if (perluDilihat) bagian.push(perluDilihat + " perlu dilihat");
    return "Penjaga: " + bagian.join(", ") + ".";
  }

  /** Nama yang ditampilkan sebelum dipotong. Lebih dari ini tidak terbaca sekilas. */
  const NAMA_MAKS = 5;

  /**
   * Hitungan akhir batch.
   *
   * Status per baris sudah ada, tapi tanpa angka di akhir satu gambar yang
   * terlewat bisa lolos dari mata: kontributor menutup panel, mengira lima
   * puluh gambar terisi, dan menemukan yang kosong sebulan kemudian di
   * marketplace. Inilah yang membuat "tidak ada yang terlewat" bisa
   * DIBUKTIKAN, bukan diharapkan.
   */
  function ringkasBatch({ total, terisi, gagal }) {
    const semua = Number.isFinite(total) && total > 0 ? total : 0;
    if (!semua) return "";

    // `terisi` yang memutuskan, bukan panjang daftar nama. Batch yang berhenti
    // di tengah (poin habis, kuota API, versi kedaluwarsa) meninggalkan gambar
    // yang tidak pernah disentuh dan tidak punya nama kegagalan; menghitungnya
    // dari daftar nama akan melaporkan mereka sebagai berhasil.
    const berhasil = Math.max(0, Math.min(semua, Number.isFinite(terisi) ? terisi : semua));
    if (berhasil >= semua) return semua + " dari " + semua + " gambar terisi.";

    const tidak = semua - berhasil;
    const nama = (Array.isArray(gagal) ? gagal : [])
      .map((x) => String(x == null ? "" : x).trim())
      .filter(Boolean);
    const tampil = nama.slice(0, NAMA_MAKS);
    const sisaNama = nama.length - tampil.length;
    const tanpaNama = Math.max(0, tidak - nama.length);

    let teks = berhasil + " dari " + semua + " terisi. " + tidak + " tidak:";
    if (tampil.length) {
      teks += " " + tampil.join(", ") + (sisaNama > 0 ? ", dan " + sisaNama + " lagi" : "");
    }
    teks += ".";
    if (tanpaNama > 0) teks += " " + tanpaNama + " tidak sempat diproses.";
    return teks;
  }

  globalThis.__NERONA_guardLaporan__ = { ringkas, ringkasBatch };
})();
