/**
 * Ringkasan satu baris dari laporan penjaga unggahan.
 *
 * Fitur A mengubah metadata tanpa ditanya, dan itu hanya boleh kalau
 * perubahannya selalu terlihat. Berkas ini yang memastikan "diam-diam" tidak
 * pernah terjadi: setiap perbaikan berakhir sebagai kalimat yang dibaca
 * kontributor, dan aturan yang gagal terambil dikatakan apa adanya, bukan
 * dilewatkan seolah semuanya lolos.
 *
 * MURNI; lihat scripts/guard-laporan.test.mjs.
 */
(function () {
  function jumlah(daftar) {
    return Array.isArray(daftar) ? daftar.length : 0;
  }

  globalThis.__NERONA_guardLaporan__ = function ringkas(penjaga) {
    if (!penjaga) return "";

    if (penjaga.dilewati) {
      return "Penjaga: metadata tidak diperiksa, aturan marketplace belum terambil.";
    }

    const dibetulkan = jumlah(penjaga.perubahan);
    const perluDilihat = jumlah(penjaga.sisa);
    if (!dibetulkan && !perluDilihat) return "";

    const bagian = [];
    if (dibetulkan) bagian.push(dibetulkan + " dibetulkan");
    if (perluDilihat) bagian.push(perluDilihat + " perlu dilihat");
    return "Penjaga: " + bagian.join(", ") + ".";
  };
})();
