/**
 * Jembatan antara mesin murni penjaga unggahan dan halaman marketplace.
 *
 * Isinya cuma yang TIDAK bisa diuji `node --test`: canvas, chrome.storage, dan
 * pembacaan aturan dari salinan server. Semua keputusan (apa yang dibetulkan,
 * apa yang kembar, berapa skornya) tinggal di guard/*.js yang murni, jadi
 * berkas ini sengaja dangkal. Kalau ada logika yang tumbuh di sini, tempatnya
 * salah.
 */
(function () {
  const sidik = globalThis.__NERONA_guardSidik__;
  const aturanMod = globalThis.__NERONA_guardAturan__;

  /**
   * 9x8, bukan ukuran lain: dHash membandingkan tiap piksel dengan tetangga
   * kanannya, jadi lebar harus satu lebih besar daripada jumlah bit per baris.
   */
  const LEBAR = 9;
  const TINGGI = 8;

  /**
   * Sidik dihitung dari data gambar yang SUDAH diambil untuk panggilan AI,
   * bukan dari elemen di halaman. Dua sebabnya: gambar itu sudah ada di tangan
   * jadi tidak ada pengambilan kedua, dan data URL tidak pernah mencemari
   * canvas, sedangkan gambar marketplace dari CDN lain hampir selalu mencemari.
   */
  async function sidikDariInlineData(inline) {
    try {
      const data = inline && (inline.data || inline.dataBase64);
      const mime = inline && (inline.mimeType || inline.mime);
      if (!data || !mime) return null;

      const gambar = new Image();
      await new Promise((selesai, gagal) => {
        gambar.onload = selesai;
        gambar.onerror = () => gagal(new Error("gambar tidak terbaca"));
        gambar.src = "data:" + mime + ";base64," + data;
      });

      const kanvas = document.createElement("canvas");
      kanvas.width = LEBAR;
      kanvas.height = TINGGI;
      const ctx = kanvas.getContext("2d", { willReadFrequently: true });
      if (!ctx) return null;
      ctx.drawImage(gambar, 0, 0, LEBAR, TINGGI);
      return sidik.dariRgba(ctx.getImageData(0, 0, LEBAR, TINGGI).data, LEBAR, TINGGI);
    } catch (_e) {
      // Tidak punya sidik cuma berarti gambar ini tidak ikut pemeriksaan
      // duplikat. Itu jauh lebih murah daripada menggagalkan generate.
      return null;
    }
  }

  /** Selalu mengembalikan aturan yang bisa dipakai: salinan server kalau ada, bawaan kalau tidak. */
  async function aturanUntuk(marketplaceKey) {
    let dariServer = null;
    try {
      dariServer = await globalThis.NeronaWebClient?.getGuardRules?.();
    } catch (_e) {
      /* abaikan, jatuh ke bawaan */
    }
    return aturanMod.pilih({ marketplaceKey, dariServer });
  }

  /**
   * SVG menjadi JPEG lewat kanvas.
   *
   * Model penglihatan tidak membaca image/svg+xml. Dikirim apa adanya,
   * balasannya jadi prosa bukan JSON, dan generate diam-diam jatuh ke tambalan
   * yang memecah nama berkas. Terbukti 2026-09-17 pada SVG Canva yang
   * menghasilkan keyword "matahari, terbenam, svg, people, stock, photo".
   *
   * Dimuat lewat object URL, bukan URL aslinya: object URL sama-origin, jadi
   * kanvasnya TIDAK tercemar dan toDataURL boleh dipanggil. Memakai URL CDN
   * marketplace langsung mencemari kanvas dan melempar SecurityError, dan
   * itulah sebabnya jalur kanvas yang sudah ada gagal untuk aset Canva.
   *
   * Latar diisi putih lebih dulu karena JPEG tidak punya alfa: tanpa itu, SVG
   * berlatar transparan menjadi gambar berlatar HITAM, dan model menilai gambar
   * yang berbeda dari yang dilihat kontributor.
   */
  async function rasterSvg(blob, maksSisi) {
    if (!blob) return null;
    const objectUrl = URL.createObjectURL(blob);
    try {
      const img = new Image();
      await new Promise((selesai, gagal) => {
        img.onload = selesai;
        img.onerror = () => gagal(new Error("SVG tidak bisa dimuat"));
        img.src = objectUrl;
      });

      const { lebar, tinggi } = globalThis.__NERONA_guardRaster__.ukuranRasterSvg({
        lebar: img.naturalWidth,
        tinggi: img.naturalHeight,
        maksSisi
      });

      const kanvas = document.createElement("canvas");
      kanvas.width = lebar;
      kanvas.height = tinggi;
      const ctx = kanvas.getContext("2d");
      if (!ctx) return null;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, lebar, tinggi);
      ctx.drawImage(img, 0, 0, lebar, tinggi);

      const data = kanvas.toDataURL("image/jpeg", 0.88).split(",")[1] || "";
      return data ? { mimeType: "image/jpeg", data } : null;
    } catch (_e) {
      return null;
    } finally {
      URL.revokeObjectURL(objectUrl);
    }
  }

  globalThis.__NERONA_guardJembatan__ = { sidikDariInlineData, aturanUntuk, rasterSvg };
})();
