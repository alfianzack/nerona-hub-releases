/**
 * Sidik gambar untuk penjaga duplikat (fitur B), memakai dHash.
 *
 * dHash dipilih bukan karena paling canggih, melainkan karena yang dicari di
 * sini persis kekuatannya: dua berkas yang isinya nyaris sama walau beda
 * ukuran, kompresi, atau sedikit terang. Ia membandingkan terang piksel dengan
 * tetangga kanannya, jadi yang tersisa cuma bentuk, bukan nilai mutlaknya.
 *
 * Yang menggambar ke canvas TIDAK ada di sini. Berkas ini menerima piksel RGBA
 * 9x8 yang sudah diperkecil browser, supaya bagian yang menentukan (piksel jadi
 * sidik, dan sidik jadi jarak) bisa dibuktikan `node --test`. Salah di bagian
 * ini artinya menuduh dua gambar berbeda sebagai duplikat, dan tuduhan itu
 * mahal buat kontributor.
 *
 * Lihat scripts/guard-sidik.test.mjs.
 */
(function () {
  /**
   * Jarak Hamming maksimal yang masih disebut mirip, dari 64 bit. 10 itu sekitar
   * 16% bit berbeda: cukup longgar untuk beda kompresi dan pemotongan tipis,
   * cukup ketat supaya dua foto berbeda tidak tertuduh.
   */
  const AMBANG_MIRIP = 10;

  /** Bobot mata manusia, bukan rata-rata tiga kanal: hijau jauh lebih terang daripada biru. */
  function terang(r, g, b) {
    return 0.299 * r + 0.587 * g + 0.114 * b;
  }

  /**
   * RGBA (lebar x tinggi, biasanya 9x8) jadi 64 bit heks. Tiap baris
   * menyumbang 8 bit: piksel dibandingkan dengan tetangga kanannya.
   */
  function dariRgba(rgba, lebar, tinggi) {
    const bit = [];
    for (let y = 0; y < tinggi; y++) {
      for (let x = 0; x < lebar - 1; x++) {
        const i = (y * lebar + x) * 4;
        const j = (y * lebar + x + 1) * 4;
        const kiri = terang(rgba[i], rgba[i + 1], rgba[i + 2]);
        const kanan = terang(rgba[j], rgba[j + 1], rgba[j + 2]);
        bit.push(kiri > kanan ? 1 : 0);
      }
    }
    let heks = "";
    for (let i = 0; i < bit.length; i += 4) {
      heks += ((bit[i] << 3) | (bit[i + 1] << 2) | (bit[i + 2] << 1) | bit[i + 3]).toString(16);
    }
    return heks;
  }

  const JUMLAH_BIT = [0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4];

  /** null kalau tidak bisa dibandingkan; pemanggil harus memperlakukannya sebagai "tidak tahu", bukan "mirip". */
  function jarak(a, b) {
    if (typeof a !== "string" || typeof b !== "string") return null;
    if (a.length !== b.length || !a.length) return null;
    let total = 0;
    for (let i = 0; i < a.length; i++) {
      const x = parseInt(a[i], 16);
      const y = parseInt(b[i], 16);
      if (Number.isNaN(x) || Number.isNaN(y)) return null;
      total += JUMLAH_BIT[x ^ y];
    }
    return total;
  }

  function miripkah(a, b, ambang) {
    const d = jarak(a, b);
    if (d === null) return false;
    return d <= (Number.isFinite(ambang) ? ambang : AMBANG_MIRIP);
  }

  globalThis.__NERONA_guardSidik__ = { AMBANG_MIRIP, dariRgba, jarak, miripkah };
})();
