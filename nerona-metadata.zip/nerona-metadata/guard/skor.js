/**
 * Mesin skor keyword (fitur D).
 *
 * Empat bagian, tapi cuma tiga yang bisa dihitung di browser. Relevansi butuh
 * mata: apakah keyword ini benar-benar ada di gambar hanya bisa dijawab model
 * yang melihat gambarnya. Jadi keyword yang belum dinilai AI dibiarkan kosong,
 * tidak ikut rata-rata, dan ditandai. Menebak angkanya akan membuat skor terasa
 * pasti padahal isinya karangan, dan itu merusak satu-satunya gunanya skor.
 *
 * Kalau BELUM ADA satu pun nilai AI, total tetap dihitung dari tiga bagian
 * lokal dengan bobot dinormalkan ulang, bukan dianggap nol. Nol akan terbaca
 * sebagai "keywordmu jelek", padahal yang benar adalah "belum diperiksa".
 *
 * MURNI dan tanpa DOM; lihat scripts/guard-skor.test.mjs.
 */
(function () {
  const kata = globalThis.__NERONA_guardKata__;

  /** Hukuman per keyword kembar, dikali porsi. 140 supaya separuh daftar kembar sudah menjatuhkan keunikan ke 30. */
  const HUKUM_KEMBAR = 140;
  const HUKUM_TERLARANG = 25;
  const HUKUM_TERLALU_PANJANG = 10;
  const HUKUM_LEBIH_BATAS = 30;

  /**
   * Dipakai kalau aturan tidak menyebutkan batasnya. Angkanya berbeda per
   * marketplace (Adobe 4, Canva 3, Vecteezy 1), jadi yang dipakai selalu yang
   * dari aturan; ini cuma jaring terakhir.
   */
  const KATA_MAKS_BAWAAN = 4;

  /**
   * Pita porsi frasa (2 kata sampai batas marketplace) yang dianggap sehat. Di
   * bawah 0,4 daftarnya kebanyakan head term dan kalah di pencarian spesifik;
   * di atas 0,75 kebanyakan long-tail dan kehilangan pencarian luas.
   */
  const PITA_BAWAH = 0.4;
  const PITA_ATAS = 0.75;

  const AMBANG_KUAT = 70;
  const AMBANG_CUKUP = 45;
  const AMBANG_RELEVANSI_RENDAH = 50;

  function jepit(n) {
    return Math.max(0, Math.min(100, n));
  }

  function adaKataTerlarang(frasa, daftarTerlarang) {
    for (const w of kata.pecahKata(frasa)) {
      if (daftarTerlarang.indexOf(w) !== -1) return w;
    }
    return null;
  }

  function label(total) {
    if (total >= AMBANG_KUAT) return "kuat";
    if (total >= AMBANG_CUKUP) return "cukup";
    return "lemah";
  }

  globalThis.__NERONA_guardSkor__ = function hitungSkor({ keywords, aturan }) {
    const daftar = Array.isArray(keywords) ? keywords : [];
    const terlarang = (aturan && Array.isArray(aturan.kataTerlarang) ? aturan.kataTerlarang : []);
    const bobot = (aturan && aturan.bobot) || { relevansi: 40, keunikan: 20, bentuk: 20, kepatuhan: 20 };

    const kataMaks =
      aturan && Number.isFinite(aturan.kataMaksPerKeyword) && aturan.kataMaksPerKeyword > 0
        ? aturan.kataMaksPerKeyword
        : KATA_MAKS_BAWAAN;

    const kembar = kata.petaKembar(daftar);
    const panjang = daftar.map((x) => kata.pecahKata(x.k).length);

    const dinilai = daftar.filter((x) => x.rel !== null && x.rel !== undefined);
    const relevansi = dinilai.length
      ? Math.round(dinilai.reduce((s, x) => s + x.rel, 0) / dinilai.length)
      : null;

    const n = daftar.length;
    const keunikan = n ? jepit(Math.round(100 - (kembar.size / n) * HUKUM_KEMBAR)) : 0;

    let bentuk = 0;
    if (n && kataMaks <= 1) {
      // Marketplace yang cuma menerima satu kata (Vecteezy) tidak mungkin punya
      // campuran head term dan long-tail. Mengukurnya di sana berarti memberi
      // nilai merah justru karena kontributor mematuhi aturan marketplace.
      bentuk = 100;
    } else if (n) {
      const porsi = panjang.filter((p) => p >= 2 && p <= kataMaks).length / n;
      if (porsi >= PITA_BAWAH && porsi <= PITA_ATAS) bentuk = 100;
      else {
        const jarak = porsi < PITA_BAWAH ? PITA_BAWAH - porsi : porsi - PITA_ATAS;
        bentuk = jepit(Math.round(100 - jarak * 200));
      }
    }

    let kepatuhan = 0;
    if (n) {
      kepatuhan = 100;
      kepatuhan -= daftar.filter((x) => adaKataTerlarang(x.k, terlarang)).length * HUKUM_TERLARANG;
      kepatuhan -= panjang.filter((p) => p > kataMaks).length * HUKUM_TERLALU_PANJANG;
      if (aturan && aturan.keywordMaks && n > aturan.keywordMaks) kepatuhan -= HUKUM_LEBIH_BATAS;
      kepatuhan = jepit(kepatuhan);
    }

    let total = 0;
    if (n) {
      if (relevansi === null) {
        const sisa = bobot.keunikan + bobot.bentuk + bobot.kepatuhan;
        total = sisa
          ? Math.round((keunikan * bobot.keunikan + bentuk * bobot.bentuk + kepatuhan * bobot.kepatuhan) / sisa)
          : 0;
      } else {
        const semua = bobot.relevansi + bobot.keunikan + bobot.bentuk + bobot.kepatuhan;
        total = semua
          ? Math.round(
              (relevansi * bobot.relevansi +
                keunikan * bobot.keunikan +
                bentuk * bobot.bentuk +
                kepatuhan * bobot.kepatuhan) /
                semua
            )
          : 0;
      }
    }

    const perKeyword = daftar.map((x, i) => {
      const sebab = [];
      if (kembar.has(i)) sebab.push('kembar dengan "' + daftar[kembar.get(i)].k + '"');
      const kena = adaKataTerlarang(x.k, terlarang);
      if (kena) sebab.push("kata terlarang: " + kena);
      if (panjang[i] > kataMaks) sebab.push("terlalu panjang, lebih dari " + kataMaks + " kata");
      if (x.rel === null || x.rel === undefined) sebab.push("belum dinilai AI");
      else if (x.rel < AMBANG_RELEVANSI_RENDAH) sebab.push("relevansi rendah menurut AI");
      return { k: x.k, rel: x.rel === undefined ? null : x.rel, sebab };
    });

    return {
      total,
      label: label(total),
      relevansi,
      keunikan,
      bentuk,
      kepatuhan,
      belum: daftar.length - dinilai.length,
      versiAturan: (aturan && aturan.versi) || null,
      perKeyword
    };
  };
})();
