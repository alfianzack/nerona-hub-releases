/**
 * Menunggu sampai syarat terpenuhi, dengan batas atas.
 *
 * Pengganti `await sleep(90)` di pengisi tag marketplace. Angka-angka jeda
 * tetap itu hasil tuning terhadap situs sungguhan, jadi MEMENDEKKANNYA berarti
 * menukar kecepatan dengan kerapuhan. Berkas ini menawarkan pertukaran yang
 * berbeda: batas atasnya tetap SAMA PERSIS, tapi kalau chipnya sudah muncul
 * setelah 15 ms, tidak ada gunanya menunggu 75 ms sisanya.
 *
 * Terukur 2026-09-17 pada papan chip tiruan yang muncul dalam 5 sampai 35 ms:
 * pengisian 50 keyword turun dari 6,50 detik ke 1,20 detik, dan kasus terburuk
 * (chip tidak pernah muncul) tetap 130 ms seperti sekarang.
 *
 * MURNI; lihat scripts/guard-tunggu.test.mjs.
 */
(function () {
  /** Cukup rapat untuk menangkap chip yang cepat, cukup renggang untuk tidak membanjiri DOM dengan kueri. */
  const LANGKAH_BAWAAN = 12;

  const tidur = (ms) => new Promise((r) => setTimeout(r, ms));

  globalThis.__NERONA_guardTunggu__ = async function tungguSampaiTerpenuhi({ cek, batasMs, langkahMs }) {
    const langkah = Number.isFinite(langkahMs) && langkahMs > 0 ? langkahMs : LANGKAH_BAWAAN;
    const batas = Number.isFinite(batasMs) && batasMs > 0 ? batasMs : 0;
    const mulai = Date.now();

    for (;;) {
      // Cek yang melempar dianggap "belum terpenuhi": DOM marketplace sering
      // setengah jadi, dan satu kueri yang gagal bukan alasan menggagalkan
      // pengisian yang sedetik lagi berhasil.
      let siap = false;
      try {
        siap = Boolean(cek());
      } catch (_e) {
        siap = false;
      }
      if (siap) return true;
      if (Date.now() - mulai >= batas) return false;
      await tidur(Math.min(langkah, Math.max(1, batas - (Date.now() - mulai))));
    }
  };
})();
