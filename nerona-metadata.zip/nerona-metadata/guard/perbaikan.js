/**
 * Mesin perbaikan metadata (fitur A).
 *
 * Aturan yang memisahkan "dibetulkan" dari "dilaporkan": mesin hanya
 * membetulkan yang jawabannya cuma satu. Judul yang melebihi batas cuma bisa
 * dipotong; keyword kembar cuma bisa dibuang. Begitu ada lebih dari satu cara
 * membetulkan (deskripsi kosong mau diisi apa, kategori mana yang benar), itu
 * keputusan manusia dan mesin berhenti di memberi tahu.
 *
 * MURNI dan tanpa DOM supaya bisa dibuktikan `node --test`; lihat
 * scripts/guard-perbaikan.test.mjs. Dipanggil dari content.js tepat sebelum
 * `return finalMetadata` di generateMetadataFromImage, jadi satu sisipan
 * melayani semua marketplace.
 */
(function () {
  const kata = globalThis.__NERONA_guardKata__;

  /** Ambil daftar keyword apa pun bentuk masuknya, plus cara mengembalikannya. */
  function bacaKeywords(nilai) {
    if (Array.isArray(nilai)) {
      return { list: nilai.map((x) => String(x).trim()).filter(Boolean), array: true };
    }
    const list = String(nilai == null ? "" : nilai)
      .split(",")
      .map((x) => x.trim())
      .filter(Boolean);
    return { list, array: false };
  }

  function tulisKeywords(list, sebagaiArray) {
    return sebagaiArray ? list.slice() : list.join(", ");
  }

  /**
   * Potong di batas kata terdekat sebelum plafon. Hasilnya selalu awalan persis
   * dari judul asli: tanda baca di ujung sengaja TIDAK dirapikan, karena begitu
   * mesin mulai menyunting isi judul, ia tidak lagi cuma memotong.
   */
  function potongDiBatasKata(teks, maks) {
    const potong = teks.slice(0, maks);
    const spasi = potong.lastIndexOf(" ");
    return spasi > 0 ? potong.slice(0, spasi) : potong;
  }

  function adaKataTerlarang(frasa, daftarTerlarang) {
    const kataFrasa = kata.pecahKata(frasa);
    for (const w of kataFrasa) {
      if (daftarTerlarang.indexOf(w) !== -1) return w;
    }
    return null;
  }

  globalThis.__NERONA_guardPerbaikan__ = function betulkan({ metadata, aturan }) {
    const salinan = Object.assign({}, metadata);

    if (!aturan) {
      return {
        dilewati: true,
        sebab: "Aturan marketplace belum terambil, jadi metadata tidak diperiksa.",
        metadata: salinan,
        perubahan: [],
        sisa: []
      };
    }

    const perubahan = [];
    const sisa = [];
    const terlarang = Array.isArray(aturan.kataTerlarang) ? aturan.kataTerlarang : [];

    const judulAsli = String(salinan.title == null ? "" : salinan.title);
    if (aturan.judulMaks && judulAsli.length > aturan.judulMaks) {
      salinan.title = potongDiBatasKata(judulAsli, aturan.judulMaks);
      perubahan.push(
        "Judul dipotong di batas kata, dari " + judulAsli.length + " ke " + salinan.title.length + " karakter."
      );
      sisa.push("Judul hasil potongan sebaiknya dibaca ulang, kalimatnya bisa terasa menggantung.");
    }

    const { list: masuk, array: sebagaiArray } = bacaKeywords(salinan.keywords);

    const dibuangTerlarang = [];
    let keywords = masuk.filter((k) => {
      const kena = adaKataTerlarang(k, terlarang);
      if (kena) {
        dibuangTerlarang.push(k + " (" + kena + ")");
        return false;
      }
      return true;
    });
    if (dibuangTerlarang.length) {
      perubahan.push("Kata terlarang dibuang: " + dibuangTerlarang.join(", ") + ".");
    }

    const kembar = kata.petaKembar(keywords);
    if (kembar.size) {
      const namaKembar = [];
      keywords = keywords.filter((k, i) => {
        if (kembar.has(i)) {
          namaKembar.push(k + " (kembar dengan " + keywords[kembar.get(i)] + ")");
          return false;
        }
        return true;
      });
      perubahan.push("Keyword kembar dibuang: " + namaKembar.join(", ") + ".");
    }

    if (aturan.keywordMaks && keywords.length > aturan.keywordMaks) {
      const lebih = keywords.length - aturan.keywordMaks;
      // Dipotong dari ekor: keyword diurutkan menurut kepentingan, jadi ekor
      // adalah yang paling murah dikorbankan.
      keywords = keywords.slice(0, aturan.keywordMaks);
      perubahan.push(lebih + " keyword terakhir dibuang, batas marketplace " + aturan.keywordMaks + ".");
    }

    salinan.keywords = tulisKeywords(keywords, sebagaiArray);

    const kategoriAda = String(salinan.category == null ? "" : salinan.category).trim();
    if (!kategoriAda) {
      const usulan = Array.isArray(salinan.categories)
        ? salinan.categories.map((x) => String(x).trim()).filter(Boolean)
        : [];
      if (usulan.length) {
        salinan.category = usulan[0];
        perubahan.push("Kategori kosong diisi dari usulan AI: " + usulan[0] + ".");
      } else {
        sisa.push("Kategori kosong dan AI tidak mengusulkan satu pun, isi sendiri.");
      }
    }

    if (!String(salinan.description == null ? "" : salinan.description).trim()) {
      sisa.push("Deskripsi kosong. Mesin tidak mengarang deskripsi.");
    }

    if (aturan.keywordTarget && keywords.length < aturan.keywordTarget) {
      sisa.push(
        "Keyword cuma " + keywords.length + ", target " + aturan.keywordTarget + ". Tambah sendiri kalau memang kurang."
      );
    }

    return { dilewati: false, metadata: salinan, perubahan, sisa };
  };
})();
