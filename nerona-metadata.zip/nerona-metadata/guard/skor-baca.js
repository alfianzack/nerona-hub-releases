/**
 * Pembaca balasan Skor Gambar (fitur D).
 *
 * Penjaga yang menentukan gunanya panel: relevansi hanya diterima untuk
 * keyword yang BENAR-BENAR ada di form. Model kadang menambah keyword,
 * melewatkan satu, atau membetulkan ejaan sendiri. Diteruskan apa adanya, panel
 * akan menampilkan angka di sebelah kata yang tidak pernah ditulis kontributor,
 * dan skornya menjawab pertanyaan yang tidak ia ajukan.
 *
 * Keyword yang dilewati model TIDAK diberi nol. Nol berarti "tidak relevan",
 * sedangkan yang benar adalah "belum dinilai", dan panel menampilkan keduanya
 * berbeda.
 *
 * MURNI; lihat scripts/guard-skor-baca.test.mjs.
 */
(function () {
  function galat(sebab) {
    return { tujuanKomersial: "", rel: {}, galat: sebab };
  }

  function buangPagar(teks) {
    return String(teks)
      .trim()
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/```$/, "")
      .trim();
  }

  globalThis.__NERONA_guardSkorBaca__ = function bacaSkor(teks, keywordSekarang) {
    if (typeof teks !== "string" || !teks.trim()) return galat("Balasan kosong.");

    let muatan;
    try {
      muatan = JSON.parse(buangPagar(teks));
    } catch (_e) {
      return galat("Balasan tidak bisa dibaca.");
    }
    if (!muatan || typeof muatan !== "object" || Array.isArray(muatan)) {
      return galat("Bentuk balasan tidak dikenal.");
    }

    // Peta dari bentuk yang dinormalkan ke EJAAN FORM. Ejaan form yang menang:
    // itu yang dilihat kontributor dan yang akan dikirim ke marketplace.
    const peta = new Map();
    for (const k of Array.isArray(keywordSekarang) ? keywordSekarang : []) {
      const teksK = String(k == null ? "" : k).trim();
      if (teksK) peta.set(teksK.toLowerCase().replace(/\s+/g, " "), teksK);
    }

    const rel = {};
    if (Array.isArray(muatan.relevansi)) {
      for (const item of muatan.relevansi) {
        if (!item || typeof item !== "object") continue;
        const kunci = String(item.k == null ? "" : item.k).trim().toLowerCase().replace(/\s+/g, " ");
        const asli = peta.get(kunci);
        if (!asli) continue;
        const n = item.rel;
        if (typeof n !== "number" || !Number.isFinite(n)) continue;
        rel[asli] = Math.round(Math.max(0, Math.min(100, n)));
      }
    }

    return {
      tujuanKomersial: String(muatan.tujuanKomersial == null ? "" : muatan.tujuanKomersial).trim(),
      rel
    };
  };
})();
