/**
 * Aturan marketplace untuk penjaga unggahan.
 *
 * Nilai bawaan di berkas ini disalin dari batas yang SUDAH hidup di prompt
 * produksi (nerona-web/src/lib/extension/prompts.ts, bagian "MARKETPLACE
 * LIMITS", plus penambah khusus Vecteezy dan Miricanvas di buildMetadataPrompt).
 * Tidak satu pun dikarang. Kalau prompt itu berubah, scripts/guard-aturan.test.mjs
 * yang pertama memberi tahu bahwa keduanya sudah tidak sejalan.
 *
 * Bawaan ini bukan sumber kebenaran, ia jaring pengaman. Sumber kebenarannya
 * kunci `extension_guard_rules` di Setting nerona-web, karena batas marketplace
 * berubah tanpa memberi tahu siapa pun dan mengejarnya lewat rilis ekstensi
 * berarti menunggu semua kontributor memperbarui.
 *
 * Berkas ini MURNI: yang mengambil dari jaringan dan menyimpan ke
 * chrome.storage tinggal di lapisan UI, supaya pemilihan aturannya bisa
 * dibuktikan `node --test`.
 */
(function () {
  /** Profil Adobe juga dipakai marketplace yang tidak dikenal, persis seperti prompt. */
  const UMUM = {
    judulMaks: 120,
    keywordMaks: 40,
    keywordTarget: 5,
    kataMaksPerKeyword: 4,
    kataTerlarang: []
  };

  const BAWAAN = {
    umum: UMUM,
    perMarketplace: {
      adobe: {},
      shutterstock: {},
      magnific: {},
      dreamstime: {},
      designbundle: {},
      // Canva punya profil sendiri di prompt: judul jauh lebih pendek, tag lebih
      // sedikit, frasa lebih pendek, dan "canva" sendiri dilarang jadi keyword.
      canva: { judulMaks: 64, keywordMaks: 20, kataMaksPerKeyword: 3, kataTerlarang: ["canva"] },
      // Vecteezy menerima tag satu kata saja, jadi frasa apa pun akan ditolak.
      vecteezy: { judulMaks: 200, keywordMaks: 50, kataMaksPerKeyword: 1 },
      miricanvas: { judulMaks: 100, keywordMaks: 25 }
    }
  };

  /** Bobot bawaan: relevansi paling berat karena ia satu-satunya yang melihat gambar. */
  const BOBOT_BAWAAN = { relevansi: 40, keunikan: 20, bentuk: 20, kepatuhan: 20 };

  /** Jarak Hamming maksimal dari 64 bit yang masih disebut duplikat. */
  const DUPLIKAT_AMBANG_BAWAAN = 10;

  /** Sisa poin yang membuat pemeriksaan otomatis menjeda diri. Belum dikalibrasi. */
  const AMBANG_POIN_JEDA_BAWAAN = 200;

  function angkaSah(nilai) {
    return Number.isFinite(nilai) && nilai > 0;
  }

  /**
   * Bobot diterima utuh atau ditolak utuh, tidak sebagian.
   *
   * Menerima sebagian akan mencampur bobot owner dengan bobot bawaan, dan
   * jumlahnya jadi angka yang tidak pernah dimaksudkan siapa pun. Bobot yang
   * semuanya nol juga ditolak: skor nol terbaca "keywordmu jelek", bukan
   * "bobotnya salah".
   */
  function bacaBobot(nilai) {
    if (!nilai || typeof nilai !== "object") return null;
    const out = {};
    let jumlah = 0;
    for (const bidang of ["relevansi", "keunikan", "bentuk", "kepatuhan"]) {
      const v = nilai[bidang];
      if (!Number.isFinite(v) || v < 0) return null;
      out[bidang] = v;
      jumlah += v;
    }
    return jumlah > 0 ? out : null;
  }

  function bersihkanTerlarang(daftar) {
    if (!Array.isArray(daftar)) return null;
    return daftar
      .filter((x) => typeof x === "string" && x.trim())
      .map((x) => x.trim().toLowerCase());
  }

  /** Terima hanya bidang yang dikenal dan nilainya masuk akal; sisanya dibiarkan bawaan. */
  function serap(target, sumber) {
    if (!sumber || typeof sumber !== "object") return;
    for (const bidang of ["judulMaks", "keywordMaks", "keywordTarget", "kataMaksPerKeyword"]) {
      if (angkaSah(sumber[bidang])) target[bidang] = sumber[bidang];
    }
    const terlarang = bersihkanTerlarang(sumber.kataTerlarang);
    if (terlarang) target.kataTerlarang = terlarang;
  }

  function pilih({ marketplaceKey, dariServer }) {
    const kunci = String(marketplaceKey == null ? "" : marketplaceKey).trim().toLowerCase();

    const hasil = Object.assign({}, UMUM, { kataTerlarang: UMUM.kataTerlarang.slice() });
    serap(hasil, BAWAAN.perMarketplace[kunci]);

    const server = dariServer && typeof dariServer === "object" ? dariServer : null;
    if (server) {
      serap(hasil, server.umum);
      if (server.perMarketplace && typeof server.perMarketplace === "object") {
        serap(hasil, server.perMarketplace[kunci]);
      }
    }

    hasil.bobot = Object.assign({}, BOBOT_BAWAAN);
    hasil.duplikatAmbang = DUPLIKAT_AMBANG_BAWAAN;
    hasil.ambangPoinJeda = AMBANG_POIN_JEDA_BAWAAN;
    if (server) {
      const bobot = bacaBobot(server.bobot);
      if (bobot) hasil.bobot = bobot;
      const ambang = server.duplikatAmbang;
      if (Number.isFinite(ambang) && ambang >= 0 && ambang <= 64) hasil.duplikatAmbang = ambang;
      if (angkaSah(server.ambangPoinJeda)) hasil.ambangPoinJeda = server.ambangPoinJeda;
    }

    hasil.sumber = server ? "server" : "bawaan";
    hasil.versi = server && typeof server.versi === "string" && server.versi ? server.versi : "bawaan";
    hasil.marketplaceKey = kunci;
    return hasil;
  }

  globalThis.__NERONA_guardAturan__ = { BAWAAN, pilih };
})();
