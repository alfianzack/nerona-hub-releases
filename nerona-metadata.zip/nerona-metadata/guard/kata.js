/**
 * Dasar kata untuk penjaga unggahan: memecah frasa, dan menemukan keyword
 * kembar.
 *
 * MURNI dan tanpa DOM, mengikuti pola marketplaces/suggestion-merge.js: hanya
 * yang bisa dimuat `node --test` yang bisa dibuktikan benar. Dipakai dua fitur
 * sekaligus, guard/perbaikan.js (membuang yang kembar) dan guard/skor.js
 * (menghukumnya lewat bagian Keunikan), jadi ia berdiri sendiri supaya
 * keduanya tidak punya dua definisi "kembar" yang diam-diam berbeda.
 */
(function () {
  /**
   * Kata sependek dua huruf dibuang sebelum membandingkan. "at", "of", "in"
   * muncul di hampir semua frasa panjang, jadi kalau ikut dihitung, dua keyword
   * yang tidak berhubungan bisa terlihat kembar hanya karena sama-sama memakai
   * kata sambung.
   */
  const PANJANG_KATA_MINIMAL = 3;

  /**
   * Ambang irisan, dibagi himpunan kata yang LEBIH BESAR. Pembagi itu yang
   * penting, bukan angkanya: kalau dibagi yang lebih kecil, "office" menelan
   * "modern office" (1 dari 1 = 100%) dan mesin perbaikan membuang long-tail
   * yang justru berharga.
   *
   * Dengan pembagi yang besar, 0,66 duduk persis di antara dua kasus nyata:
   * "business meeting team" ditelan "business meeting" (2 dari 3 = 0,667, lolos
   * tipis), sedangkan "modern office" lawan "office team" (1 dari 2 = 0,5)
   * tidak. Tes memaku kedua sisinya, jadi menggeser angka ini pasti merah.
   */
  const AMBANG_IRISAN = 0.66;

  function pecahKata(teks) {
    return String(teks == null ? "" : teks)
      .trim()
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean);
  }

  function kataPenting(teks) {
    const set = new Set();
    for (const w of pecahKata(teks)) {
      if (w.length >= PANJANG_KATA_MINIMAL) set.add(w);
    }
    return set;
  }

  /**
   * Mengembalikan Map: indeks keyword kembar -> indeks keyword lebih awal yang
   * ia kembari. Yang ditandai selalu yang belakangan, karena urutan keyword itu
   * urutan kepentingan; yang datang duluan yang berhak tinggal.
   */
  function petaKembar(daftar) {
    const peta = new Map();
    const list = Array.isArray(daftar) ? daftar : [];
    const set = list.map((x) => kataPenting(typeof x === "string" ? x : x && x.k));

    for (let i = 0; i < list.length; i++) {
      if (!set[i].size) continue;
      for (let j = 0; j < i; j++) {
        if (!set[j].size) continue;
        let sama = 0;
        for (const w of set[i]) {
          if (set[j].has(w)) sama++;
        }
        if (sama / Math.max(set[i].size, set[j].size) >= AMBANG_IRISAN) {
          peta.set(i, j);
          break;
        }
      }
    }
    return peta;
  }

  globalThis.__NERONA_guardKata__ = {
    PANJANG_KATA_MINIMAL,
    AMBANG_IRISAN,
    pecahKata,
    kataPenting,
    petaKembar
  };
})();
