/**
 * Antrean satu pekerjaan sekaligus untuk pemeriksaan risiko (fitur C).
 *
 * Konkurensi 1 itu keputusan uang, bukan gaya. Lima puluh gambar yang terlihat
 * sekaligus akan jadi lima puluh panggilan AI serentak: kena batas laju
 * provider, dan kalau poin habis di tengah, yang terbakar seluruh sisanya
 * sekaligus tanpa satu pun sempat dihentikan. Satu per satu berarti saldo yang
 * menipis cuma kehilangan satu panggilan lagi.
 *
 * Berkas ini MURNI: tidak tahu apa-apa soal AI, gambar, maupun poin. Yang
 * dikerjakannya cuma urutan dan rem, dan itu justru bagian yang harus bisa
 * dibuktikan tanpa browser.
 */
(function () {
  globalThis.__NERONA_guardAntrean__ = function buatAntrean(kerjakan) {
    const menunggu = [];
    const pernah = new Set();
    let berjalan = false;
    let dijeda = false;
    let penunggu = [];

    function beritahuSelesai() {
      if (menunggu.length || berjalan) return;
      const daftar = penunggu;
      penunggu = [];
      daftar.forEach((r) => r());
    }

    async function putar() {
      if (berjalan || dijeda) return;
      const item = menunggu.shift();
      if (item === undefined) {
        beritahuSelesai();
        return;
      }
      berjalan = true;
      try {
        await kerjakan(item);
      } catch (_e) {
        // Satu gambar yang gagal tidak boleh menyandera sisa antrean.
      }
      berjalan = false;
      putar();
    }

    return {
      tambah(item) {
        // Gambar yang sama bisa masuk-keluar layar berkali-kali waktu digulir;
        // tanpa penjaga ini, satu gambar dibayar berkali-kali.
        if (pernah.has(item)) return;
        pernah.add(item);
        menunggu.push(item);
        putar();
      },
      jeda() {
        dijeda = true;
      },
      lanjut() {
        dijeda = false;
        putar();
      },
      kosongkan() {
        menunggu.length = 0;
        beritahuSelesai();
      },
      panjang() {
        return menunggu.length;
      },
      selesai() {
        if (!menunggu.length && !berjalan) return Promise.resolve();
        return new Promise((r) => penunggu.push(r));
      }
    };
  };
})();
