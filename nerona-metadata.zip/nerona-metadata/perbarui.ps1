# Pembaru Nerona Metadata.
#
# Dijalankan lewat perbarui.cmd, dari DALAM folder extension yang sudah
# terpasang. Karena ia tinggal di folder itu, tidak ada folder yang bisa salah
# pilih — dan itu justru satu-satunya alasan berkas ini ada. Menimpa folder
# bukan pekerjaan yang sulit; mengingat folder MANA yang harus ditimpa itulah
# yang salah.
#
# Urutannya dipilih supaya kegagalan separuh jalan tidak pernah merusak
# pemasangan yang bekerja: seluruh unduhan dan pemeriksaan terjadi di folder
# temp, dan folder sungguhan baru disentuh setelah semuanya lolos.
#
# Windows saja. Setara untuk macOS sengaja tidak dibuat: .command tanpa tanda
# tangan diblokir Gatekeeper, jadi pengguna Mac tetap memakai jalur manual di
# halaman Unduh.

$ErrorActionPreference = "Stop"

function Selesai($pesan) {
  Write-Host ""
  Write-Host $pesan
  Write-Host ""
  Read-Host "Tekan Enter untuk menutup"
  exit
}

function Gagal($pesan) {
  Write-Host ""
  Write-Host "GAGAL: $pesan" -ForegroundColor Red
  Write-Host ""
  Write-Host "Pemasangan Anda TIDAK diubah. Anda bisa mencoba lagi, atau unduh"
  Write-Host "manual dari halaman Unduh di nerona-web."
  Write-Host ""
  Read-Host "Tekan Enter untuk menutup"
  exit 1
}

$folder = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "Nerona Metadata - pembaru"
Write-Host "Folder: $folder"
Write-Host ""

# ---------------------------------------------------------------- penjaga

# WAJIB, dan bukan sekadar kerapian: langkah terakhir skrip ini MENGHAPUS
# subfolder. Kalau berkas ini tersalin ke tempat lain — Desktop, Downloads,
# folder proyek — tanpa penjaga ini ia akan menghapus isi folder itu.
$manifestPath = Join-Path $folder "manifest.json"
if (-not (Test-Path $manifestPath)) {
  Gagal "Tidak ada manifest.json di folder ini. Berkas perbarui ini harus tetap berada di dalam folder nerona-metadata."
}

try {
  $manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
} catch {
  Gagal "manifest.json tidak bisa dibaca. Pemasangan ini mungkin rusak; pasang ulang dari halaman Unduh."
}

if ($manifest.name -ne "Nerona Metadata") {
  Gagal "Folder ini bukan folder Nerona Metadata (nama di manifest: '$($manifest.name)')."
}

$versiTerpasang = [string]$manifest.version
Write-Host "Versi terpasang : $versiTerpasang"

# ---------------------------------------------------------------- alamat server

# Dibaca dari access-config.js, TIDAK ditulis ulang di sini. Dua tempat berarti
# dua nilai yang bisa berbeda tanpa ada yang tahu mana yang benar — dan yang
# salah di sini membuat pembaru menembak server yang bukan milik pengguna.
$configPath = Join-Path $folder "access\access-config.js"
if (-not (Test-Path $configPath)) {
  Gagal "access\access-config.js tidak ditemukan."
}
$config = Get-Content $configPath -Raw
if ($config -notmatch 'neronaWebBaseUrl\s*:\s*"([^"]+)"') {
  Gagal "Alamat server tidak terbaca dari access-config.js."
}
$base = $Matches[1].TrimEnd('/')

# ---------------------------------------------------------------- versi terbaru

Write-Host "Memeriksa versi terbaru..."
# Invoke-RestMethod MELEMPAR untuk setiap status non-2xx, jadi menangkap semua
# lemparan sebagai satu sebab akan melaporkan "periksa koneksi internet" kepada
# orang yang internetnya baik-baik saja dan servernya menjawab dengan sopan
# bahwa belum ada rilis. Ketiga sebab di bawah menuntut tindakan yang berbeda,
# jadi ketiganya dibedakan.
try {
  $info = Invoke-RestMethod -Uri "$base/api/extension/latest" -TimeoutSec 30
} catch {
  $balasan = $_.Exception.Response
  if ($balasan) {
    $kode = [int]$balasan.StatusCode
    if ($kode -eq 503) {
      Gagal "Server belum menerbitkan versi extension. Coba lagi nanti."
    }
    if ($kode -eq 429) {
      Gagal "Terlalu banyak permintaan dari jaringan ini. Tunggu beberapa menit lalu coba lagi."
    }
    Gagal "Server membalas HTTP $kode. Coba lagi nanti."
  }
  Gagal "Tidak bisa menghubungi $base. Periksa koneksi internet Anda."
}
if (-not $info.ok -or -not $info.versi -or -not $info.url) {
  Gagal "Balasan server tidak lengkap. Coba lagi nanti."
}

$versiBaru = [string]$info.versi
Write-Host "Versi tersedia  : $versiBaru"

# Per ruas angka, bukan perbandingan abjad. Perbandingan abjad bilang "1.10"
# lebih tua dari "1.9", dan itu akan menolak memperbarui orang yang justru
# paling butuh. Aturan yang sama dengan bandingkanVersi di nerona-web.
function BandingkanVersi($a, $b) {
  $ka = @($a -split '\.' | ForEach-Object { [int]($_ -replace '\D.*$', '') })
  $kb = @($b -split '\.' | ForEach-Object { [int]($_ -replace '\D.*$', '') })
  for ($i = 0; $i -lt [Math]::Max($ka.Count, $kb.Count); $i++) {
    $x = if ($i -lt $ka.Count) { $ka[$i] } else { 0 }
    $y = if ($i -lt $kb.Count) { $kb[$i] } else { 0 }
    if ($x -ne $y) { return $x - $y }
  }
  return 0
}

if ((BandingkanVersi $versiTerpasang $versiBaru) -ge 0) {
  Selesai "Sudah versi terbaru. Tidak ada yang perlu dilakukan."
}

# ---------------------------------------------------------------- unduh & periksa

# Semuanya di temp. Folder sungguhan tidak disentuh sampai seluruh pemeriksaan
# di bawah lolos, jadi unduhan yang putus di tengah jalan tidak bisa
# meninggalkan pemasangan yang separuh tertimpa.
$temp = Join-Path $env:TEMP ("nerona-metadata-" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $temp -Force | Out-Null

try {
  $zip = Join-Path $temp "extension.zip"
  Write-Host "Mengunduh $versiBaru..."
  Invoke-WebRequest -Uri $info.url -OutFile $zip -TimeoutSec 300

  $isi = Join-Path $temp "isi"
  Expand-Archive -Path $zip -DestinationPath $isi -Force

  # ZIP-nya membungkus semuanya di folder nerona-metadata/ (dijamin
  # scripts/build-zip.js dan diperiksa ulang di CI).
  $sumber = Join-Path $isi "nerona-metadata"
  if (-not (Test-Path $sumber)) {
    Gagal "Isi ZIP tidak seperti yang diharapkan (folder nerona-metadata tidak ada)."
  }

  $manifestBaru = Join-Path $sumber "manifest.json"
  if (-not (Test-Path $manifestBaru)) {
    Gagal "ZIP tidak memuat manifest.json."
  }
  $cek = Get-Content $manifestBaru -Raw | ConvertFrom-Json
  # Yang diunduh harus benar-benar versi yang dijanjikan server. Kalau tidak,
  # kunci Setting dan aset rilis sudah tidak sinkron — dan memasang sesuatu yang
  # tidak kita ketahui isinya lebih buruk daripada berhenti.
  if ([string]$cek.version -ne $versiBaru) {
    Gagal "ZIP berisi versi $($cek.version), bukan $versiBaru yang dijanjikan server."
  }

  # ------------------------------------------------------------ timpa

  Write-Host "Memasang..."
  # Ketiga subfolder DIHAPUS lebih dulu, bukan sekadar ditimpa: berkas yang
  # dihapus di versi baru akan tertinggal selamanya kalau hanya menimpa.
  foreach ($sub in @("access", "marketplaces", "icons")) {
    $lama = Join-Path $folder $sub
    if (Test-Path $lama) { Remove-Item $lama -Recurse -Force }
  }
  Copy-Item -Path (Join-Path $sumber "*") -Destination $folder -Recurse -Force

} catch {
  Gagal $_.Exception.Message
} finally {
  if (Test-Path $temp) { Remove-Item $temp -Recurse -Force -ErrorAction SilentlyContinue }
}

Selesai @"
Selesai. Terpasang versi $versiBaru.

Satu langkah terakhir: klik ikon Nerona di toolbar Chrome, lalu tekan
tombol "Muat ulang extension" di spanduk kuning.

(Menutup lalu membuka Chrome juga bekerja.)
"@
